#!/usr/bin/env python3
"""Physical Gazebo relocation check using feedback-driven manual positioning.

Requires a normal fresh demo_all scene; no teleport, fake sensors or injected transforms.
"""
import json
import math
import time
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile,DurabilityPolicy
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from tf2_ros import Buffer,TransformListener,TransformException
from gazebo_msgs.srv import GetEntityState
from rclpy.time import Time
from yuyu_bringup.core import dance_space,wrap_angle,point_clear


def main():
    rclpy.init();n=Node('yuyu_reposition_check');tf=Buffer();listener=TransformListener(tf,n)
    values={};states=[];latch=QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL)
    n.create_subscription(String,'/safety_status',lambda m:values.update(safety=json.loads(m.data)),5)
    n.create_subscription(String,'/motion_status',lambda m:values.update(motion=m.data),10)
    n.create_subscription(String,'/dance_status',lambda m:values.update(dance=json.loads(m.data)),latch)
    n.create_subscription(String,'/behavior_state',lambda m:states.append(m.data) if not states or states[-1]!=m.data else None,latch)
    pub=n.create_publisher(String,'/command_text',20);manual=n.create_publisher(Twist,'/teleop_cmd_vel',10)
    def pump(seconds):
        end=time.monotonic()+seconds
        while time.monotonic()<end:rclpy.spin_once(n,timeout_sec=.025)
    def pose():
        p=tf.lookup_transform('map','base_footprint',Time()).transform
        q=p.rotation
        return p.translation.x,p.translation.y,math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))
    def drive(target):
        print('Positioning toward',target,'from',pose(),flush=True)
        deadline=time.monotonic()+40
        while time.monotonic()<deadline:
            pump(.07);p=pose();distance=math.dist(p[:2],target)
            assert values.get('safety',{}).get('ready'),values
            assert not any(values['safety']['edges'].values()),values
            if distance<.008:manual.publish(Twist());pump(.6);return
            angle=wrap_angle(math.atan2(target[1]-p[1],target[0]-p[0])-p[2])
            m=Twist();m.angular.z=max(-.60,min(.60,1.8*angle))
            m.linear.x=min(.03,.8*distance) if abs(angle)<.15 else 0.
            assert point_clear(*p[:2]),p
            manual.publish(m)
        raise AssertionError(('manual positioning timed out',pose(),target,values))
    try:
        deadline=time.monotonic()+40
        while time.monotonic()<deadline:
            pump(.2)
            try:
                pose()
                if values.get('safety',{}).get('ready'):break
            except TransformException:pass
        pub.publish(String(data='恢复说话'));pump(.3)
        # Release first, then press: an earlier explicit stop suppresses a held key.
        manual.publish(Twist());pump(.3)
        for target in [(-.30,.11),(-.368,.11)]:drive(target)
        start=pose();assert not dance_space(start),('not a cramped start',start)
        states.clear();pub.publish(String(data='跳舞'));deadline=time.monotonic()+75
        while time.monotonic()<deadline:
            pump(.15)
            if 'DANCING' in states and states[-1]=='IDLE':break
            if ('PLANNING' in states or 'REPOSITIONING' in states) and states[-1]=='IDLE' and 'DANCING' not in states:
                raise AssertionError(('relocation failed',states,pose()))
        assert 'PLANNING' in states and 'REPOSITIONING' in states and 'DANCING' in states and states[-1]=='IDLE',states
        assert values.get('dance',{}).get('success'),values.get('dance')
        end=pose();assert math.dist(start[:2],end[:2])>.025,(start,end)
        truth=n.create_client(GetEntityState,'/gazebo/get_entity_state')
        assert truth.wait_for_service(timeout_sec=3)
        request=GetEntityState.Request();request.name='yuyu';request.reference_frame='world'
        future=truth.call_async(request);deadline=time.monotonic()+3
        while not future.done() and time.monotonic()<deadline:pump(.03)
        assert future.done() and future.result().success
        actual=future.result().state.pose
        assert math.dist(end[:2],(actual.position.x,actual.position.y))<.05,('map/truth discrepancy',end,actual)
        assert abs(actual.position.x)<.36 and abs(actual.position.y)<.17,actual
        print('PASS: actual positioning at',start,'→ planner → relocation → short dance → idle; final',end,flush=True)
        print('States:',states,flush=True)
    finally:
        manual.publish(Twist());pub.publish(String(data='停下'));pump(.3);n.destroy_node();rclpy.shutdown()

if __name__=='__main__':main()
