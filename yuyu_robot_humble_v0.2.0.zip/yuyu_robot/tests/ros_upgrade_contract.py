#!/usr/bin/env python3
"""Real ROS/HTTP adapter contract with synthetic sensors; NOT a physics or cliff test."""
import json
import os
from pathlib import Path
import tempfile
import threading
import time
import urllib.request
import rclpy
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from rclpy.qos import QoSProfile, DurabilityPolicy, qos_profile_sensor_data
from nav_msgs.msg import Odometry
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Range
from yuyu_bringup.nodes import VoiceEmotion,TTS,BehaviorManager,VelocityMux,ControlPanel,FaceDisplay


def main():
    with tempfile.TemporaryDirectory(prefix='yuyu-contract-') as root:
        os.environ['YUYU_DATA_DIR']=root
        rclpy.init(args=['--ros-args','-p','audio:=false','-p','open_browser:=false','-p','port:=18815'])
        nodes=[VoiceEmotion(),TTS(),BehaviorManager(),VelocityMux(),ControlPanel(),FaceDisplay()]
        voice,tts,behavior,mux,panel,face=nodes
        probe=Node('yuyu_contract_probe');nodes.append(probe)
        values={'acks':[],'texts':[],'velocities':[],'goals':0}
        pub=probe.create_publisher(String,'/command_request',20)
        safety=probe.create_publisher(String,'/safety_status',5)
        odom=probe.create_publisher(Odometry,'/odom',qos_profile_sensor_data)
        near=[probe.create_publisher(Range,'/proximity/'+side,qos_profile_sensor_data) for side in ('front','rear')]
        probe.create_subscription(String,'/command_ack',lambda m:values['acks'].append(json.loads(m.data)),20)
        probe.create_subscription(String,'/face_text',lambda m:values['texts'].append(m.data),20)
        probe.create_subscription(Twist,'/cmd_vel',lambda m:values['velocities'].append((m.linear.x,m.angular.z)),10)
        def heartbeat():
            safety.publish(String(data=json.dumps({'ready':True,'edges':dict.fromkeys(('front_left','front_right','rear_left','rear_right'),False),'pose':[0,0,0]})))
            msg=Odometry();msg.pose.pose.orientation.w=1.;odom.publish(msg)
            for publisher in near:
                value=Range();value.range=float('inf');publisher.publish(value)
        probe.create_timer(.05,heartbeat)
        executor=MultiThreadedExecutor(num_threads=1)
        for n in nodes:executor.add_node(n)
        thread=threading.Thread(target=executor.spin,daemon=True);thread.start()
        def wait_for(check,seconds=5):
            end=time.monotonic()+seconds
            while not check() and time.monotonic()<end:time.sleep(.03)
            assert check(),values
        def command(identity,text):
            pub.publish(String(data=json.dumps({'id':identity,'text':text},ensure_ascii=False)))
            wait_for(lambda:any(a['id']==identity for a in values['acks']))
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        def api(path,body):
            req=urllib.request.Request(panel.url+path,data=json.dumps(body).encode(),headers={'Content-Type':'application/json','X-Yuyu-Token':panel.app.token},method='POST')
            with opener.open(req,timeout=5) as response:return json.load(response)
        try:
            wait_for(lambda:behavior.tasks.ready() and pub.get_subscription_count()>0)
            command('quiet-1','安静');wait_for(lambda:tts.worker.silent and behavior.tasks.quiet)
            command('resume-1','恢复说话');wait_for(lambda:not tts.worker.silent and not behavior.tasks.quiet)
            assert any(x for x in values['texts'] if '陪' in x or '在' in x or '窗外' in x)
            command('come-1','过来');wait_for(lambda:any('已经在你旁边' in t for t in values['texts']))
            pub.publish(String(data=json.dumps({'id':'come-1','text':'过来'})))
            wait_for(lambda:len([a for a in values['acks'] if a['id']=='come-1'])==2)
            assert behavior.tasks.state=='IDLE'
            api('/api/settings',{'volume':41,'motion_speed':.06,'voice_id':'offline_soft'})
            wait_for(lambda:tts.worker.settings['volume']==41 and mux.settings['motion_speed']==.06)
            panel.dispatch('teleop',{'v':.05,'w':0})
            wait_for(lambda:any(v>.035 for v,w in values['velocities']))
            api('/api/command',{'id':'panel-stop','text':'停下'})
            wait_for(lambda:any(a['id']=='panel-stop' for a in values['acks']))
            wait_for(lambda:mux.hold and abs(values['velocities'][-1][0])<.001)
            time.sleep(.5);assert behavior.tasks.state=='IDLE' and all(abs(v)<.001 for v,w in values['velocities'][-5:])
            with opener.open(panel.url+'/api/state') as response:state=json.load(response)
            assert state['settings']['volume']==41 and 'panel-stop' in state['acks']
            print('PASS: actual ROS+HTTP adapters, one-shot resume, command ID dedup, already-at-goal response, settings propagation, manual lease, stop hold; sensors synthetic, audio disabled.',flush=True)
        finally:
            executor.shutdown(timeout_sec=3);thread.join(timeout=3)
            for n in reversed(nodes):n.destroy_node()
            if rclpy.ok():rclpy.shutdown()

if __name__=='__main__':main()
