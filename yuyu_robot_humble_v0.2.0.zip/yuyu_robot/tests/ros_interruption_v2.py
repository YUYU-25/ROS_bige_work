#!/usr/bin/env python3
"""Physical one-shot stop, duplicate goal and quiet-during-dance regression."""
import json,math,time,uuid
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile,DurabilityPolicy
from std_msgs.msg import String
from geometry_msgs.msg import Twist,PoseStamped
from gazebo_msgs.srv import GetEntityState


def main():
    rclpy.init();n=Node('yuyu_interruption_v2');values={};goals=[];velocities=[]
    latch=QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL)
    n.create_subscription(String,'/behavior_state',lambda m:values.update(state=m.data),latch)
    n.create_subscription(String,'/speech_status',lambda m:values.update(speech=json.loads(m.data)),latch)
    n.create_subscription(String,'/safety_status',lambda m:values.update(safety=json.loads(m.data)),5)
    n.create_subscription(Twist,'/cmd_vel',lambda m:velocities.append((time.monotonic(),m.linear.x,m.angular.z)),10)
    n.create_subscription(PoseStamped,'/nav_goal',goals.append,10)
    pub=n.create_publisher(String,'/command_request',20)
    truth=n.create_client(GetEntityState,'/gazebo/get_entity_state')
    def pump(seconds):
        until=time.monotonic()+seconds
        while time.monotonic()<until:rclpy.spin_once(n,timeout_sec=.025)
    def wait(check,seconds=8):
        until=time.monotonic()+seconds
        while not check() and time.monotonic()<until:pump(.03)
        assert check(),values
    def command(text):
        pub.publish(String(data=json.dumps({'id':uuid.uuid4().hex,'text':text},ensure_ascii=False)))
    def pose():
        assert truth.wait_for_service(timeout_sec=3)
        req=GetEntityState.Request();req.name='yuyu';req.reference_frame='world';f=truth.call_async(req)
        until=time.monotonic()+3
        while not f.done() and time.monotonic()<until:pump(.03)
        assert f.done() and f.result().success
        p=f.result().state.pose;q=p.orientation
        return p.position.x,p.position.y,math.atan2(2*q.w*q.z,1-2*q.z*q.z)
    try:
        wait(lambda:values.get('safety',{}).get('ready') and pub.get_subscription_count()>0,40);pump(.3)
        command('过来');wait(lambda:values.get('state')=='NAVIGATING')
        wait(lambda:velocities and (abs(velocities[-1][1])>.005 or abs(velocities[-1][2])>.1))
        pump(.25);sent=time.monotonic();command('停下')
        wait(lambda:values.get('state')=='IDLE' and velocities[-1][0]>sent and abs(velocities[-1][1])+abs(velocities[-1][2])<.001,2)
        delay=velocities[-1][0]-sent
        pump(.9);a=pose();pump(1.2);b=pose()
        assert math.dist(a[:2],b[:2])<.005,(a,b)
        assert all(abs(v)+abs(w)<.001 for t,v,w in velocities if t>sent+.25)
        command('过来');wait(lambda:values.get('state')=='INTERACTING',45);pump(1)
        count=len(goals);a=pose();command('过来');pump(1.5);b=pose()
        assert len(goals)==count,(count,len(goals))
        assert math.dist(a[:2],b[:2])<.005 and abs(math.atan2(math.sin(a[2]-b[2]),math.cos(a[2]-b[2])))<.08,(a,b)
        command('跳舞');wait(lambda:values.get('state')=='DANCING');pump(2)
        sent=time.monotonic();command('安静')
        wait(lambda:values.get('state')=='IDLE' and values.get('speech',{}).get('muted'),2)
        pump(2);assert values['state']=='IDLE'
        assert all(abs(v)+abs(w)<.001 for t,v,w in velocities if t>sent+.3)
        command('恢复说话');wait(lambda:not values.get('speech',{}).get('muted',True))
        print('PASS: single stop, physical hold, already-at-goal duplicate without rotation, quiet interrupts dance without resuming, one resume; stop cmd delay %.3fs.'%delay,flush=True)
    finally:
        command('停下');pump(.3);n.destroy_node();rclpy.shutdown()

if __name__=='__main__':main()
