#!/usr/bin/env python3
"""独立 Humble 图形验证：在专用 ROS_DOMAIN_ID 中启动模型、表情和 RViz。"""
import hashlib
import json
import os
import signal
import subprocess
import tempfile
import time
from pathlib import Path

import rclpy
import xacro
import yaml
from PIL import Image as PILImage, ImageGrab
from ament_index_python.packages import get_package_share_directory
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile
from sensor_msgs.msg import Image, JointState
from std_msgs.msg import String
from visualization_msgs.msg import Marker
from yuyu_bringup.face import find_font, render


def main():
    work = Path(tempfile.mkdtemp(prefix='yuyu-face-rviz-'))
    desc = Path(get_package_share_directory('yuyu_description'))
    robot = xacro.process_file(str(desc/'urdf/yuyu.urdf.xacro')).toxml()
    params = work/'robot.yaml'
    params.write_text(yaml.safe_dump({'/**': {'ros__parameters': {
        'robot_description': robot, 'use_sim_time': False}}}))
    config = yaml.safe_load((desc/'rviz/yuyu_view.rviz').read_text())
    manager = config['Visualization Manager']
    manager['Displays'] = [d for d in manager['Displays'] if d['Name'] in
                           ('Grid', 'RobotModel', 'Face on Robot', 'Face')]
    manager['Views']['Current'].update(Distance=0.37, Yaw=0.0, Pitch=0.12)
    manager['Views']['Current']['Focal Point']['Z'] = 0.09
    config['Window Geometry'] = {'Width': 1280, 'Height': 800}
    rviz_config = work/'face.rviz'
    rviz_config.write_text(yaml.safe_dump(config, sort_keys=False))
    processes, logs = [], []
    commands = [
        ['ros2', 'run', 'robot_state_publisher', 'robot_state_publisher',
         '--ros-args', '--params-file', str(params)],
        ['ros2', 'run', 'yuyu_bringup', 'face_display_node'],
        ['rviz2', '-d', str(rviz_config)],
    ]
    rclpy.init()
    node = Node('yuyu_face_visual_check')
    images, markers, hashes = {}, [], []
    def on_image(msg):
        key = (msg.header.stamp.sec, msg.header.stamp.nanosec)
        images[key] = msg
        while len(images) > 40:
            del images[next(iter(images))]
    node.create_subscription(Image, '/face_image', on_image, 5)
    node.create_subscription(Marker, '/face_screen_marker', markers.append,
                             QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL))
    expression = node.create_publisher(String, '/face_expr', 10)
    text = node.create_publisher(String, '/face_text', 10)
    joints = node.create_publisher(JointState, '/joint_states', 10)
    def pump(seconds):
        deadline = time.monotonic()+seconds
        while time.monotonic() < deadline:
            joint = JointState()
            joint.header.stamp = node.get_clock().now().to_msg()
            joint.name = ['left_wheel_joint', 'right_wheel_joint']
            joint.position = [0.0, 0.0]
            joints.publish(joint)
            rclpy.spin_once(node, timeout_sec=0.03)
    def check_mesh(msg):
        assert msg.frame_locked and msg.header.frame_id == 'face_screen_link'
        assert len(msg.points) == len(msg.colors) and len(msg.points) % 6 == 0
        assert msg.header.stamp.sec == 0 and msg.header.stamp.nanosec == 0, '屏幕应使用最新TF'
        image = next(reversed(images.values()))
        rebuilt = PILImage.new('RGB', (image.width, image.height))
        for start in range(0, len(msg.points), 6):
            points = msg.points[start:start+6]
            x0 = round((min(p.x for p in points)/0.1+0.5)*image.width)
            x1 = round((max(p.x for p in points)/0.1+0.5)*image.width)
            y0 = round((0.5-max(p.y for p in points)/0.06)*image.height)
            y1 = round((0.5-min(p.y for p in points)/0.06)*image.height)
            c = msg.colors[start]
            color = tuple(round(v*255) for v in (c.r, c.g, c.b))
            rebuilt.paste(color, (x0, y0, x1, y1))
        assert any(rebuilt.tobytes() == bytes(frame.data) for frame in images.values()), '三维屏幕与最近原图不同'
        return hashlib.sha256(rebuilt.tobytes()).hexdigest()
    try:
        for index, cmd in enumerate(commands):
            log = (work/('process-%d.log' % index)).open('w')
            logs.append(log)
            processes.append(subprocess.Popen(cmd, stdout=log, stderr=log, start_new_session=True))
        pump(5)
        assert all(p.poll() is None for p in processes), '显示进程提前退出'
        assert markers and images, '没有收到模型屏幕或原始图像'
        for value in ('happy', 'care', 'sleepy', 'curious', 'silent', 'dance'):
            expression.publish(String(data=value))
            pump(0.9)
            hashes.append(check_mesh(markers[-1]))
            if value in ('happy', 'sleepy', 'dance'):
                ImageGrab.grab().save(work/(value+'.png'))
        assert len(set(hashes)) == 6
        expression.publish(String(data='happy'))
        before = hashlib.sha256(render('happy', '', find_font()).tobytes()).hexdigest()
        deadline = time.monotonic()+3.0
        while check_mesh(markers[-1]) != before and time.monotonic() < deadline:
            pump(0.1)
        assert check_mesh(markers[-1]) == before, '切换表情后未收到无字幕的 happy 基准帧'
        text.publish(String(data='你好呀，我是禹禹。'))
        sent_at = time.monotonic()
        deadline = sent_at+3.0
        while check_mesh(markers[-1]) == before and time.monotonic() < deadline:
            pump(0.1)
        with_text = check_mesh(markers[-1])
        assert before != with_text
        pump(0.5)
        ImageGrab.grab().save(work/'chinese.png')
        deadline = sent_at+6.0
        while check_mesh(markers[-1]) != before and time.monotonic() < deadline:
            pump(0.1)
        assert before == check_mesh(markers[-1]), '中文未按长度自动清除'
        cleared_after = time.monotonic()-sent_at
        assert 4.3 <= cleared_after <= 6.0, '中文显示时长异常：%.3f秒' % cleared_after
        pump(0.4)
        ImageGrab.grab().save(work/'cleared.png')
        # RViz 晚于图像生成才加入时，仍需能获取当前三维表情。
        late = []
        sub = node.create_subscription(Marker, '/face_screen_marker', late.append,
                      QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL))
        pump(0.25)
        assert late, '晚启动的订阅者没有获取当前屏幕'
        node.destroy_subscription(sub)
        for log in logs:
            log.flush()
        rviz_log = (work/'process-2.log').read_text()
        assert 'Error' not in rviz_log and 'Failed' not in rviz_log, rviz_log
        report = {'result': 'PASS', 'expressions': 6, 'pixel_exact': True,
                  'chinese_clear_seconds': round(cleared_after, 3), 'late_join': True,
                  'last_mesh_vertices': len(markers[-1].points), 'artifacts': str(work)}
        (work/'result.json').write_text(json.dumps(report, indent=2))
        print(json.dumps(report, ensure_ascii=False))
    finally:
        for process in processes:
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGINT)
        for process in processes:
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
        for log in logs:
            log.close()
        node.destroy_node()
        rclpy.shutdown()
        print('图形验证输出目录：'+str(work))


if __name__ == '__main__':
    main()
