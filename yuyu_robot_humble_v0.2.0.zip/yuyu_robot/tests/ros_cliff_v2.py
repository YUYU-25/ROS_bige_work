#!/usr/bin/env python3
"""Actual cliff sensors, dedicated no-rim fixture. Run one case per fresh scene.

Start: bash tools/start.sh use_slam:=false world:=$PWD/src/yuyu_gazebo/worlds/desk_cliff_test.world
Then: python3 tests/ros_cliff_v2.py --side front (or rear)
The test changes Gazebo truth; restart the scene before normal navigation.
"""
import argparse
import json
import math
import time
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, DurabilityPolicy
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from gazebo_msgs.srv import SetEntityState, GetEntityState


def main():
    args=argparse.ArgumentParser(); args.add_argument('--side',choices=('front','rear'),required=True); side=args.parse_args().side
    rclpy.init();node=Node('yuyu_cliff_v2');data={};samples=[];states=[];outputs=[]
    latch=QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL)
    node.create_subscription(String,'/safety_status',lambda m:(data.update(safety=json.loads(m.data)),samples.append(json.loads(m.data))),5)
    node.create_subscription(String,'/behavior_state',lambda m:states.append(m.data),latch)
    node.create_subscription(Twist,'/cmd_vel',lambda m:outputs.append((m.linear.x,m.angular.z)),10)
    pub=node.create_publisher(String,'/command_text',10)
    clients={name:node.create_client(kind,'/gazebo/'+name) for name,kind in [('set_entity_state',SetEntityState),('get_entity_state',GetEntityState)]}
    def pump(seconds):
        end=time.monotonic()+seconds
        while time.monotonic()<end:rclpy.spin_once(node,timeout_sec=.025)
    def call(name,request,require_success=True):
        client=clients[name];assert client.wait_for_service(timeout_sec=10),name
        future=client.call_async(request);end=time.monotonic()+10
        while not future.done() and time.monotonic()<end:rclpy.spin_once(node,timeout_sec=.025)
        assert future.done() and (future.result().success or not require_success),name
        return future.result()
    def truth():
        req=GetEntityState.Request();req.name='yuyu';req.reference_frame='world'
        return call('get_entity_state',req).state.pose
    try:
        pump(3)
        for rim in ('rim_front','rim_back','rim_left','rim_right'):
            query=GetEntityState.Request();query.name=rim;query.reference_frame='world'
            assert not call('get_entity_state',query,False).success,'请先使用独立 desk_cliff_test.world 场景；正常场景有低挡边，不能运行此布置'
        assert data.get('safety',{}).get('ready'),'传感器尚未就绪'
        pub.publish(String(data='停下'));pump(.5)
        req=SetEntityState.Request();req.state.name='yuyu';req.state.reference_frame='world'
        x=.435 if side=='front' else -.435
        # At rear x=-.435, caster center=-.490: its contact point is still on the table.
        # There is no rim collision volume in this dedicated fixture.
        assert -.5 < x-.055 < .5
        req.state.pose.position.x=x;req.state.pose.position.z=.751;req.state.pose.orientation.w=1.
        states.clear();outputs.clear();samples.clear();call('set_entity_state',req)
        until=time.monotonic()+25;actuals=[]
        while time.monotonic()<until:
            pump(.15);p=truth();actuals.append(p)
            assert p.position.z>.72 and abs(p.orientation.x)<.12 and abs(p.orientation.y)<.12,('模型倾斜或跌落',p)
            if 'FLEEING' in states and states[-1]=='IDLE':break
        else:raise AssertionError(('未完成落差恢复',states))
        opposite='rear' if side=='front' else 'front'
        assert any(s.get('ready') and any(s['edges'][side+'_'+n] for n in ('left','right')) and not any(s['edges'][opposite+'_'+n] for n in ('left','right')) for s in samples),'没有实际收到本侧单独落差，不能以地图防护代替'
        assert any(v<-.005 if side=='front' else v>.005 for v,w in outputs),'没有向桌内恢复'
        assert any(abs(w)>.1 for v,w in outputs),'没有在下视清除后转向'
        p=truth();inward=(x-p.position.x) if side=='front' else (p.position.x-x)
        assert inward>.04,('实际恢复位移不足',inward)
        q=p.orientation;yaw=math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))
        assert abs(math.atan2(math.sin(yaw-math.pi/2),math.cos(yaw-math.pi/2)))<.3,('实际朝向未恢复约90度',yaw)
        pump(.6);assert outputs and all(abs(v)<.001 and abs(w)<.01 for v,w in outputs[-5:]),'完成后未保持停车'
        print('PASS:',side,'真实下视检测、向内恢复、转向、稳定停车；位移%.4fm，朝向%.1f度。完成后重启场景。'%(inward,math.degrees(yaw)))
    finally:
        pub.publish(String(data='停下'));pump(.3);node.destroy_node();rclpy.shutdown()

if __name__=='__main__':main()
