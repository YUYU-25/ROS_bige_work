"""独立检查三维脸部的像素保真、覆盖和三角形方向。"""
import sys
import unittest
from pathlib import Path

from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'src/yuyu_bringup'))
from yuyu_bringup.face import EXPRESSIONS, find_font, render
from yuyu_bringup.face_mesh import build_face_marker, image_rectangles


class FaceMeshTests(unittest.TestCase):
    def test_all_expressions_and_chinese_survive_rectangle_encoding(self):
        font = find_font()
        for expression in EXPRESSIONS:
            with self.subTest(expression=expression):
                image = render(expression, '你好呀，今天也辛苦了。', font, 0.7)
                rebuilt = Image.new('RGB', image.size)
                area = 0
                for x0, y0, x1, y1, rgb in image_rectangles(image):
                    self.assertTrue(0 <= x0 < x1 <= image.width)
                    self.assertTrue(0 <= y0 < y1 <= image.height)
                    rebuilt.paste(rgb, (x0, y0, x1, y1))
                    area += (x1-x0)*(y1-y0)
                self.assertEqual(area, image.width*image.height)
                self.assertEqual(rebuilt.tobytes(), image.tobytes())

    def test_uniform_background_is_one_rectangle(self):
        image = Image.new('RGB', (320, 192), (8, 126, 176))
        self.assertEqual(image_rectangles(image), [[0, 0, 320, 192, (8, 126, 176)]])

    def test_screen_orientation_dimensions_and_attachment(self):
        try:
            from builtin_interfaces.msg import Time
        except ImportError:
            self.skipTest('此项在已加载 Humble 的环境运行')
        image = Image.new('RGB', (2, 2))
        image.putdata([(255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 255)])
        marker = build_face_marker(image, Time(), width=0.16, height=0.08)
        self.assertEqual(marker.header.frame_id, 'face_screen_link')
        self.assertTrue(marker.frame_locked)
        self.assertEqual(marker.pose.orientation.w, 1.0)
        self.assertEqual(len(marker.points), len(marker.colors))
        for offset in range(0, len(marker.points), 3):
            a, b, c = marker.points[offset:offset+3]
            # 正面三角形朝向 +z；屏幕图像不能倒置或镜像。
            self.assertGreater((b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x), 0)
            rgb = marker.colors[offset]
            x, y = (a.x+b.x+c.x)/3, (a.y+b.y+c.y)/3
            if (rgb.r, rgb.g, rgb.b) == (1.0, 0.0, 0.0):
                self.assertLess(x, 0)
                self.assertGreater(y, 0)
            for p in (a, b, c):
                self.assertLessEqual(abs(p.x), 0.08+1e-12)
                self.assertLessEqual(abs(p.y), 0.04+1e-12)
                self.assertGreater(p.z, 0.0005)


if __name__ == '__main__':
    unittest.main(verbosity=2)
