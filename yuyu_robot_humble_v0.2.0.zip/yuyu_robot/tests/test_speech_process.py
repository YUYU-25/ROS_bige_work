"""Real local synthesis/decode tests. Dummy audio device: no speaker-quality claim."""
import os
import shutil
import sys
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src/yuyu_bringup'))
from yuyu_bringup.settings import SettingsStore
from yuyu_bringup.speech import SpeechWorker


@unittest.skipUnless(shutil.which('espeak') and shutil.which('ffplay'),'needs espeak and ffplay')
class SpeechProcessTests(unittest.TestCase):
    def worker(self, root, events, played, finished):
        SettingsStore(root).update({'voice_id':'offline_soft'})
        def event(kind,value):
            events.append((kind,value))
            if kind=='status' and value['state']=='playing':played.set()
            if kind=='status' and value['state']=='idle':finished.set()
        return SpeechWorker(event,root)

    def test_one_resume_synthesizes_and_plays_a_real_wav(self):
        original=shutil.which
        def choose(name):return None if name=='paplay' else original(name)
        with tempfile.TemporaryDirectory() as root, patch.dict(os.environ,{'SDL_AUDIODRIVER':'dummy','SDL_VIDEODRIVER':'dummy'}), patch('yuyu_bringup.speech.shutil.which',side_effect=choose):
            events=[];played=threading.Event();finished=threading.Event()
            worker=self.worker(root,events,played,finished)
            try:
                worker.submit('mute');worker.submit('resume','我回来啦，继续陪你。',identity='one-resume')
                self.assertTrue(played.wait(8),events)
                self.assertTrue(finished.wait(12),events)
                self.assertFalse([value for kind,value in events if kind=='status' and value['state']=='error'])
                self.assertEqual(len(list((Path(root)/'speech_cache').glob('*.wav'))),1)
            finally:worker.close()

    def test_mute_terminates_real_playback_without_later_resume(self):
        original=shutil.which
        def choose(name):return None if name=='paplay' else original(name)
        with tempfile.TemporaryDirectory() as root, patch.dict(os.environ,{'SDL_AUDIODRIVER':'dummy','SDL_VIDEODRIVER':'dummy'}), patch('yuyu_bringup.speech.shutil.which',side_effect=choose):
            events=[];played=threading.Event();finished=threading.Event()
            worker=self.worker(root,events,played,finished)
            try:
                worker.submit('speak','今天也想陪你待一会儿。'*5)
                self.assertTrue(played.wait(8),events)
                time.sleep(.2);worker.submit('mute','安静陪伴中')
                deadline=time.monotonic()+2
                while worker.process is not None and time.monotonic()<deadline:time.sleep(.03)
                self.assertIsNone(worker.process,events)
                self.assertTrue(worker.silent);self.assertFalse(worker.queue);self.assertFalse(finished.is_set())
            finally:worker.close()

if __name__=='__main__':unittest.main(verbosity=2)
