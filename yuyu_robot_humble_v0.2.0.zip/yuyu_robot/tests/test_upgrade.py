"""Regressions for command semantics, cancellation, motion and persistent controls."""
import base64
import io
import json
import math
from pathlib import Path
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from unittest.mock import patch
import wave

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'src/yuyu_bringup'))
from yuyu_bringup.behavior import TaskCoordinator
from yuyu_bringup.core import CLIFF_NAMES, arrival_text, dance_space, safe_velocity, interpret, scan_without_body
from yuyu_bringup.dance import BEATS, DURATION
from yuyu_bringup.panel import PanelApplication, start_server
from yuyu_bringup.settings import SettingsStore, VoiceCatalog, validated_settings
from yuyu_bringup.speech import SpeechWorker
from yuyu_bringup import voice_backend


def wav_bytes(seconds=3):
    data = io.BytesIO()
    with wave.open(data, 'wb') as out:
        out.setparams((1, 2, 16000, 0, 'NONE', 'not compressed'))
        import struct
        out.writeframes(b''.join(struct.pack('<h', round(3000*math.sin(i*.08))) for i in range(16000*seconds)))
    return data.getvalue()


class CoordinatorTests(unittest.TestCase):
    def setUp(self):
        self.now, self.events = 100.0, []
        self.tasks = TaskCoordinator(lambda k, v: self.events.append((k, v)), now=lambda: self.now)
        self.safe((-.18, .08, 0))

    def safe(self, pose, **edge):
        self.tasks.odom, self.tasks.odom_at = pose, self.now
        self.tasks.set_safety({'ready': True, 'pose': pose, 'edges': {**dict.fromkeys(CLIFF_NAMES, False), **edge}})

    def effects(self, kind):
        return [v for k, v in self.events if k == kind]

    def test_duplicate_does_not_cancel_navigation_or_spin(self):
        self.tasks.request('come')
        token = self.tasks.generation
        count = len(self.effects('navigation'))
        self.tasks.request('come')
        self.assertEqual(self.tasks.generation, token)
        self.assertEqual(len(self.effects('navigation')), count)
        self.assertIn('正在过来', self.effects('speech')[-1])
        self.safe((0, 0, math.pi))
        self.tasks.navigation_result(token, True)
        self.tasks.request('come')
        self.assertEqual(len(self.effects('navigation')), count)
        self.assertIn('已经在你旁边', self.effects('speech')[-1])

    def test_return_and_come_distinct_arrival(self):
        self.assertNotEqual(arrival_text('come'), arrival_text('return'))
        self.safe((0, 0, 0))
        self.tasks.request('return')
        token = self.tasks.generation
        self.safe((-.18, .08, 1))
        self.tasks.navigation_result(token, True)
        self.assertIn('待命', self.effects('speech')[-1])

    def test_stale_navigation_result_after_stop_never_resumes(self):
        self.tasks.request('come')
        token = self.tasks.generation
        self.tasks.request('stop')
        self.tasks.navigation_result(token, True)
        self.assertEqual(self.tasks.state, 'IDLE')
        self.assertTrue(self.effects('hold')[-1])
        self.tasks.manual_override()
        self.assertFalse(self.effects('hold')[-1])

    def test_dance_plans_reachable_space_before_moving(self):
        self.safe((-.36, .12, 0))
        self.assertFalse(dance_space(self.tasks.pose))
        self.tasks.request('dance')
        self.assertEqual(self.tasks.state, 'PLANNING')
        first = self.effects('path_request')[-1]
        self.tasks.path_result(first['token'], first['target'], [])
        second = self.effects('path_request')[-1]
        self.assertNotEqual(first['target'], second['target'])
        self.tasks.path_result(first['token'], first['target'], [first['target']])
        self.assertEqual(self.tasks.state, 'PLANNING')
        self.tasks.path_result(second['token'], second['target'], [self.tasks.pose[:2], second['target']])
        self.assertEqual(self.tasks.state, 'REPOSITIONING')
        self.safe((*second['target'], 0))
        self.tasks.navigation_result(second['token'], True)
        self.assertEqual(self.tasks.state, 'DANCING')
        self.assertEqual(self.effects('dance_request')[-1]['action'], 'start')

    def test_quiet_cancels_planner_and_late_dance(self):
        self.safe((-.36, .12, 0)); self.tasks.request('dance')
        req = self.effects('path_request')[-1]
        self.tasks.set_emotion('silent')
        self.tasks.path_result(req['token'], req['target'], [req['target']])
        self.assertEqual(self.tasks.state, 'IDLE')
        self.assertTrue(self.tasks.quiet)
        self.assertEqual(self.effects('dance_request')[-1]['action'], 'stop')

    def test_each_candidate_gets_its_own_planning_deadline(self):
        self.safe((-.36, .12, 0)); self.tasks.request('dance')
        self.now += 5.1; self.safe((-.36, .12, 0)); self.tasks.tick()
        count = len(self.effects('path_request'))
        self.now += .1; self.safe((-.36, .12, 0)); self.tasks.tick()
        self.assertEqual(len(self.effects('path_request')), count)

    def test_rear_edge_moves_forward_and_stop_suppresses_current_episode(self):
        self.safe((-.435, 0, 0), rear_left=True, rear_right=True)
        self.tasks.tick()
        self.assertGreater(self.effects('velocity')[-1][0], 0)
        self.tasks.request('stop')
        self.safe((-.435, 0, 0), rear_left=True, rear_right=True)
        self.assertEqual(self.tasks.state, 'IDLE')
        self.safe((0, 0, 0)); self.now += .4; self.safe((0, 0, 0))
        self.safe((.435, 0, 0), front_left=True)
        self.assertEqual(self.tasks.state, 'FLEEING')
        self.tasks.tick(); self.assertLess(self.effects('velocity')[-1][0], 0)

    def test_watchdog_stops_even_if_sim_time_pauses(self):
        self.tasks.request('come'); self.now += .8; self.tasks.tick()
        self.assertEqual(self.tasks.state, 'IDLE')
        self.assertEqual(self.effects('velocity')[-1], (0, 0))

    def test_short_dance_balanced_translation_and_turns(self):
        self.assertLess(DURATION, 16)
        self.assertAlmostEqual(sum(d*v for d,v,w,_ in BEATS), 0)
        self.assertAlmostEqual(sum(d*w for d,v,w,_ in BEATS), 0)
        self.assertTrue(all(abs(w) <= .85 for d,v,w,_ in BEATS))

    def test_invalid_pose_and_near_obstacle_stop(self):
        s = {'ready': True, 'edges': dict.fromkeys(CLIFF_NAMES, False), 'pose': (math.nan, 0, 0)}
        self.assertEqual(safe_velocity(.05, 0, s, 0), (0, 0))
        s['pose'] = (0, 0, 0)
        self.assertEqual(safe_velocity(.065, 0, s, 0, front=.055), (0, 0))

    def test_negative_voice_phrases_never_start_opposite_action(self):
        for text in ('别跳舞了', '不要跳', '不要回去', '别动', '停下，别过来'):
            self.assertEqual(interpret(text)[0], 'stop', text)
        self.assertEqual(interpret('不要过来')[0], 'back')
        self.assertEqual(interpret('不要说话'), ('stop','silent'))

    def test_scan_mask_preserves_external_ranges_and_beam_indices(self):
        raw=[.078, .13, .15, .6, 4.8, math.nan, math.inf, 6.0]
        result=scan_without_body(raw,5.0)
        self.assertEqual(len(result),len(raw))
        self.assertEqual(result[2:5],raw[2:5])
        self.assertTrue(all(math.isinf(result[i]) for i in (0,1,5,6,7)))


class SpeechTests(unittest.TestCase):
    def test_first_resume_speaks_and_duplicate_id_is_idempotent(self):
        played, ready = [], threading.Event()
        def player(value, job, settings, cancel):
            played.append(job['text']); ready.set()
        with tempfile.TemporaryDirectory() as root:
            worker = SpeechWorker(lambda *a: None, root, renderer=lambda *a: {'audio':'unused'}, player=player)
            try:
                worker.submit('mute', '安静')
                worker.submit('speak', '不能播报')
                worker.submit('resume', '一次恢复', identity='resume-1')
                self.assertTrue(ready.wait(1)); self.assertEqual(played, ['一次恢复'])
                worker.submit('resume', '一次恢复', identity='resume-1')
                time.sleep(.05); self.assertEqual(played, ['一次恢复'])
            finally: worker.close()

    def test_mute_interrupts_generation_and_clears_queued_speech(self):
        started, played = threading.Event(), []
        def render(job, settings, cancel):
            started.set(); cancel.wait(1); return {'audio':'unused'}
        with tempfile.TemporaryDirectory() as root:
            worker = SpeechWorker(lambda *a: None, root, renderer=render, player=lambda *a: played.append(1))
            try:
                worker.submit('speak', '等待生成'); self.assertTrue(started.wait(1))
                worker.submit('speak', '排队'); worker.submit('mute', '安静')
                time.sleep(.08); self.assertFalse(played); self.assertFalse(worker.queue)
            finally: worker.close()

    def test_preview_does_not_unmute_robot(self):
        ready = threading.Event()
        with tempfile.TemporaryDirectory() as root:
            worker = SpeechWorker(lambda *a: None, root, renderer=lambda *a: {'audio':'unused'}, player=lambda *a: ready.set())
            try:
                worker.submit('mute'); worker.submit('preview', '试听')
                self.assertTrue(ready.wait(1)); self.assertTrue(worker.silent)
            finally: worker.close()


class PreferencesTests(unittest.TestCase):
    def test_model_installer_and_panel_do_not_overwrite_each_others_preferences(self):
        with tempfile.TemporaryDirectory() as root:
            panel, installer = SettingsStore(root), SettingsStore(root)
            panel.update({'volume': 43})
            installer.update({'asr_model_path': '/tmp/chinese-model'})
            self.assertEqual(panel.get()['volume'],43)
            self.assertEqual(panel.get()['asr_model_path'],'/tmp/chinese-model')

    def test_restart_persists_and_nan_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            SettingsStore(root).update({'volume': 43, 'motion_speed': .06})
            self.assertEqual(SettingsStore(root).get()['volume'], 43)
        for key in ('volume', 'motion_speed', 'speech_rate'):
            with self.assertRaises(ValueError): validated_settings({key: math.nan})
        with self.assertRaises(ValueError): validated_settings({'local_voice_url':'https://example.com:443'})

    def test_multiple_references_survive_restart_and_path_escape_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            catalog = VoiceCatalog(root)
            one = catalog.add_reference('声音一', '你好呀', wav_bytes())
            two = catalog.add_reference('声音二', '今天开心', wav_bytes())
            fresh = VoiceCatalog(root)
            self.assertEqual(len(fresh.list()), 8)
            self.assertTrue(fresh.reference_path(one['id']).is_file())
            with self.assertRaises(ValueError): fresh.reference_path('../settings')
            fresh.delete(two['id']); self.assertEqual(len(fresh.list()), 7)

    def test_deleting_builtin_does_not_change_selection(self):
        with tempfile.TemporaryDirectory() as root:
            app = PanelApplication(lambda *a: None, root)
            with self.assertRaises(ValueError): app.handle('/api/voices/delete', {'voice_id':'xiaoxiao'})
            self.assertEqual(app.store.get()['revision'], 0)

    def test_local_cosyvoice_request_and_pcm_conversion(self):
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        requests = []
        class Engine(BaseHTTPRequestHandler):
            def log_message(self, *args): pass
            def do_POST(self):
                requests.append((self.path, self.rfile.read(int(self.headers['Content-Length']))))
                self.send_response(200); self.send_header('Content-Type', 'application/octet-stream'); self.end_headers()
                self.wfile.write(b'\x04\x00'*24000)
        server=ThreadingHTTPServer(('127.0.0.1', 0), Engine)
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with tempfile.TemporaryDirectory() as root:
                cat=VoiceCatalog(root); voice=cat.add_reference('我的声音', '你好呀', wav_bytes())
                settings=validated_settings({'local_voice_url':'http://127.0.0.1:'+str(server.server_port)})
                out=Path(root)/'result.wav'; voice_backend.cosyvoice('新的一句话',voice,settings,cat,out)
                self.assertTrue(voice_backend.valid_wav(out))
                self.assertEqual(requests[0][0], '/inference_zero_shot')
                self.assertIn('新的一句话'.encode(), requests[0][1]); self.assertIn(b'prompt_wav',requests[0][1])
        finally: server.shutdown(); server.server_close()

    def test_failed_natural_voice_not_cached_as_success(self):
        with tempfile.TemporaryDirectory() as root:
            VoiceCatalog(root)
            job={'root':root,'settings':validated_settings({}),'voice_id':'xiaoxiao','text':'你好'}
            def offline(text, profile, rate, output): output.write_bytes(wav_bytes())
            with patch.object(voice_backend,'edge',side_effect=RuntimeError('offline')) as edge, patch.object(voice_backend,'offline',side_effect=offline):
                value=voice_backend.synthesize(job,root)
                self.assertTrue(value['fallback']); self.assertTrue(Path(value['audio']).name.startswith('fallback-'))
            (Path(root)/'speech_cache/retry-edge.json').unlink()
            with patch.object(voice_backend,'edge',side_effect=lambda text, profile, rate, output: output.write_bytes(wav_bytes())) as edge:
                value=voice_backend.synthesize(job,root)
                self.assertFalse(value['fallback']); self.assertEqual(edge.call_count,1)

    def test_local_engine_redirect_rejected_before_forwarding_recording(self):
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        forwarded = []
        class Redirect(BaseHTTPRequestHandler):
            def log_message(self, *args): pass
            def do_POST(self):
                self.rfile.read(int(self.headers['Content-Length']))
                self.send_response(307); self.send_header('Location', '/should-not-receive'); self.end_headers()
            def do_GET(self):
                forwarded.append(self.path); self.send_response(200); self.end_headers()
        server=ThreadingHTTPServer(('127.0.0.1',0),Redirect)
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with tempfile.TemporaryDirectory() as root:
                cat=VoiceCatalog(root);profile=cat.add_reference('我的声音','你好',wav_bytes())
                settings=validated_settings({'local_voice_url':'http://127.0.0.1:'+str(server.server_port)})
                with self.assertRaises(RuntimeError): voice_backend.cosyvoice('新话',profile,settings,cat,Path(root)/'out.wav')
                self.assertEqual(forwarded,[])
        finally: server.shutdown();server.server_close()

    def test_http_controls_require_token_and_persist(self):
        with tempfile.TemporaryDirectory() as root:
            effects=[]; app=PanelApplication(lambda *a: effects.append(a),root)
            server=start_server(app,Path(__file__).resolve().parents[1]/'src/yuyu_bringup/web',port=18765)
            base='http://127.0.0.1:'+str(server.server_port)
            opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
            try:
                with opener.open(base) as r: self.assertIn(app.token.encode(),r.read())
                request=urllib.request.Request(base+'/api/settings',data=b'{"volume":37}',headers={'Content-Type':'application/json'},method='POST')
                with self.assertRaises(urllib.error.HTTPError) as err: opener.open(request)
                self.assertEqual(err.exception.code,403)
                request.add_header('X-Yuyu-Token',app.token)
                with opener.open(request) as r: self.assertEqual(json.load(r)['settings']['volume'],37)
                self.assertEqual(SettingsStore(root).get()['volume'],37)
                app.handle('/api/command',{'text':'过来','id':'same'}); app.state.message('robot','收到')
                app.handle('/api/command',{'text':'过来','id':'same'})
                self.assertEqual(len([m for m in app.state.snapshot()['messages'] if m['role']=='user']),1)
            finally: server.shutdown(); server.server_close()


if __name__ == '__main__': unittest.main(verbosity=2)
