"""Read-only 30-second sample of safety status and laser reception."""
import json
import time
import rclpy
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String

rclpy.init()
node = rclpy.create_node('yuyu_health_observe')
counts = {'保护状态': 0, '雷达': 0}
last, gaps = {}, {'保护状态': 0.0, '雷达': 0.0}
bad = {'未就绪': 0, '桌沿事件': 0, '格式异常': 0}

def received(name):
    now = time.monotonic()
    if name in last:
        gaps[name] = max(gaps[name], now-last[name])
    last[name] = now
    counts[name] += 1

def safety(msg):
    received('保护状态')
    try:
        data = json.loads(msg.data)
        bad['未就绪'] += int(not data['ready'])
        bad['桌沿事件'] += int(any(data['edges'].values()))
    except (ValueError, TypeError, KeyError, AttributeError):
        bad['格式异常'] += 1

subscriptions = [
    node.create_subscription(String, '/safety_status', safety, 10),
    node.create_subscription(LaserScan, '/scan', lambda msg: received('雷达'),
                             qos_profile_sensor_data),
]
try:
    print('只读观察 30 秒；请保持主程序运行、机器人停放，结束后自动汇总。', flush=True)
    deadline = time.monotonic()+30
    while time.monotonic() < deadline:
        rclpy.spin_once(node, timeout_sec=0.05)
    now = time.monotonic()
    for name in counts:
        if name not in last:
            print(name, '未收到数据')
        else:
            gap = max(gaps[name], now-last[name])
            print(name, '收到 %d 条，最长接收间隔 %.3f 秒' % (counts[name], gap))
    print('异常计数：', bad)
finally:
    node.destroy_node()
    rclpy.shutdown()
