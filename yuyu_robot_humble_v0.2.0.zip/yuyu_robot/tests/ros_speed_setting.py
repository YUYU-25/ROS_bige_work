#!/usr/bin/env python3
"""Physical high-speed setting and stop; start near the desk center, panel enabled."""
import json,re,time,urllib.request
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
rclpy.init();n=Node('yuyu_speed_setting_check');values={};samples=[]
n.create_subscription(Odometry,'/odom',lambda m:samples.append(m.twist.twist.linear.x),qos_profile_sensor_data)
n.create_subscription(String,'/safety_status',lambda m:values.update(safety=json.loads(m.data)),5)
pub=n.create_publisher(Twist,'/teleop_cmd_vel',10)
command=n.create_publisher(String,'/command_text',20)
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));base='http://127.0.0.1:8765'
with opener.open(base) as response:page=response.read().decode()
token=re.search(r'name="csrf-token" content="([^"]+)"',page).group(1)
def api(path,value):
 req=urllib.request.Request(base+path,data=json.dumps(value).encode(),headers={'Content-Type':'application/json','X-Yuyu-Token':token},method='POST')
 with opener.open(req) as response:return json.load(response)
def pump(t):
 end=time.monotonic()+t
 while time.monotonic()<end:rclpy.spin_once(n,timeout_sec=.02)
try:
 end=time.monotonic()+30
 while (not values.get('safety',{}).get('ready') or pub.get_subscription_count()<1) and time.monotonic()<end:pump(.1)
 assert values.get('safety',{}).get('ready'),values
 assert abs(values['safety']['pose'][0])<.025 and abs(values['safety']['pose'][1])<.025,'start this test near the center in a fresh scene'
 api('/api/settings',{'motion_speed':.065});pump(.3)
 pub.publish(Twist());pump(.3);samples.clear()
 for i in range(12):
  m=Twist();m.linear.x=.065;pub.publish(m);pump(.07)
 pub.publish(Twist());api('/api/command',{'text':'停下','id':'speed-check-stop'});pump(1)
 assert max(samples)>.055,samples
 assert max(samples)<.072,samples
 assert abs(samples[-1])<.004,samples[-5:]
 assert values['safety']['ready'] and not any(values['safety']['edges'].values()),values
 print('PASS: HTTP speed setting → physical feedback peak %.4f m/s → stop; final %.5f m/s.'%(max(samples),samples[-1]))
finally:
 pub.publish(Twist());api('/api/settings',{'motion_speed':.05});command.publish(String(data='停下'));pump(.3);n.destroy_node();rclpy.shutdown()
