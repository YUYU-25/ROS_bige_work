# 0.2.0 测试流程

不要同时启动两个主程序；新增控制面板可直接发送指令。所有实际结果记入[本版验证](VALIDATION_V2.md)，此前版本结果保留在[历史验证](VALIDATION.md)。

```bash
cd ~/yuyu_robot
source tools/env.sh
python3 -m unittest discover -s tests -p 'test_*.py' -v
```

启动后按顺序检查：

1. 过来、回去分别到达，屏幕和声音文案不同。途中再次“过来”不重启路线，已在目标位置再次“过来”不转圈。
2. 行动途中发一次“停下”，应停车且不自动续走。重发新动作才能继续。键盘或面板手动控制接管后不自动恢复旧动作。
3. “安静”一次停车并无声；发开心文字仍无声；“恢复说话”只发一次就能听到恢复回应。请确认Ubuntu声音输出、面板音量和音色状态。
4. 空间宽敞时跳舞；粉色泡泡、爱心眼睛和字幕同时出现。舞蹈中途“停下”/“安静”立即取消，不能稍后自行续跳。
5. 用手动控制移至桌内较窄位置，叫它跳舞；应给出寻找位置反馈，找到Nav2可达位置后移过去再跳。途中停下后不会到达再开始。没有可达候选时应解释并停车。
6. 设置音量、语速、音色和速度，重启后仍保存。录制/导入至少两份本地参考录音，重启后原录音仍可播放；本机CosyVoice服务运行后试听新句子。无服务时须明确提示备用声音。
7. 中文Vosk模型准备好且虚拟机麦克风可用后测试“语音”按钮；识别结果确认发送。不是自由聊天LLM。

实际传感器、运动与任务回归（会移动模型，需保持桌面安全起点）：

```bash
python3 tests/ros_smoke.py
python3 tests/ros_motion_check.py
python3 tests/ros_behavior_test.py
# 从中心附近新场景开始，验证自动换位（会主动移动）
python3 tests/ros_reposition_check.py
# 从待命点附近开始，验证单次停车/重复目标/安静打断
python3 tests/ros_interruption_v2.py
# 新场景中心、控制面板启用时，验证最高速度设置与停车
python3 tests/ros_speed_setting.py
```

建议每个运动测试从新场景开始，避免前一测试改变位置影响后一测试。速度反馈按本版0.05m/s验证，不只观察动画。

真实落差恢复使用独立无挡边场景，避免旧后轮支撑球与挡边初始穿插：

```bash
# 主程序终端，每个方向单独从新场景开始
bash tools/start.sh use_slam:=false world:=$PWD/src/yuyu_gazebo/worlds/desk_cliff_test.world
# 指令终端二选一，每次测试后重启场景
python3 tests/ros_cliff_v2.py --side front
python3 tests/ros_cliff_v2.py --side rear
```

脚本先检查没有rim模型，再验证真实本侧下视落差信号、向内真值位移、姿态、转向和停车。预检会查询应当不存在的rim实体，因此Gazebo可能打印 `entity[rim_front] does not exist` 等信息；这些是预期的否定查询，仍应以测试最终结果判定。不能以预置地图拦截代替实际落差检测。四方向、角落、不同负载与实体制动仍需专项验收。
