"""Cancellable-process speech renderer: Edge neural voices, local CosyVoice, offline fallback."""
import argparse
import asyncio
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import urllib.request
import uuid
import wave
from .settings import VoiceCatalog, local_engine_url


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise RuntimeError('本地音色服务不应重定向')


def valid_wav(path):
    try:
        with wave.open(str(path), 'rb') as stream:
            return stream.getnframes() > 0 and stream.getsampwidth() == 2
    except (OSError, wave.Error, EOFError):
        return False


def offline(text, profile, rate, output):
    engine = shutil.which('espeak-ng') or shutil.which('espeak')
    if not engine:
        raise RuntimeError('离线语音引擎尚未安装')
    voice = 'cmn' if Path(engine).name == 'espeak-ng' else 'zh'
    subprocess.run([engine, '-v', voice, '-s', str(round(profile.get('speed', 155)*rate)),
                    '-p', str(profile.get('pitch', 58)), '-w', str(output), '--', text],
                   check=True, timeout=20, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def edge(text, profile, rate, output):
    import edge_tts
    converter = shutil.which('ffmpeg')
    if not converter:
        raise RuntimeError('请安装 ffmpeg 后使用自然音色')
    mp3 = output.with_suffix('.mp3')
    async def render():
        speech = edge_tts.Communicate(text, profile['voice'], rate='%+d%%' % round((rate-1)*100),
             proxy=os.environ.get('HTTPS_PROXY') or os.environ.get('https_proxy'))
        await asyncio.wait_for(speech.save(str(mp3)), timeout=8)
    asyncio.run(render())
    subprocess.run([converter, '-nostdin', '-v', 'error', '-i', str(mp3), '-ac', '1',
                    '-ar', '24000', '-c:a', 'pcm_s16le', str(output)],
                   check=True, timeout=8, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def cosyvoice(text, profile, settings, catalog, output):
    boundary = 'yuyu-'+uuid.uuid4().hex
    parts = []
    for key, value in [('tts_text', text), ('prompt_text', profile['prompt'])]:
        parts.append(('--%s\r\nContent-Disposition: form-data; name="%s"\r\n\r\n%s\r\n'
                      % (boundary, key, value)).encode('utf-8'))
    parts.append(('--%s\r\nContent-Disposition: form-data; name="prompt_wav"; filename="voice.wav"'
                  '\r\nContent-Type: audio/wav\r\n\r\n' % boundary).encode())
    parts += [catalog.reference_path(profile['id']).read_bytes(), b'\r\n',
              ('--%s--\r\n' % boundary).encode()]
    url = local_engine_url(settings['local_voice_url'])+'/inference_zero_shot'
    request = urllib.request.Request(url, data=b''.join(parts),
              headers={'Content-Type': 'multipart/form-data; boundary='+boundary}, method='POST')
    # Only explicitly configured loopback service receives a reference recording.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    with opener.open(request, timeout=45) as response:
        if response.geturl() != url:
            raise RuntimeError('本地音色服务发生了意外重定向')
        audio = response.read(16*1024*1024+1)
        content_type = response.headers.get('Content-Type', '').lower()
    if not audio or len(audio) > 16*1024*1024:
        raise RuntimeError('本地音色服务返回的音频无效或过大')
    if audio.startswith(b'RIFF'):
        with wave.open(io.BytesIO(audio), 'rb') as stream:
            if stream.getsampwidth() != 2 or not stream.getnframes():
                raise RuntimeError('本地音色服务须返回16位WAV或PCM音频')
        output.write_bytes(audio)
    else:
        if (len(audio) % 2 or len(audio) < 200 or 'json' in content_type
                or 'text/' in content_type or audio.lstrip().startswith((b'{', b'['))):
            raise RuntimeError('本地音色服务须返回16位单声道PCM')
        with wave.open(str(output), 'wb') as stream:
            stream.setparams((1, 2, settings['local_voice_sample_rate'], 0, 'NONE', 'not compressed'))
            stream.writeframes(audio)


def synthesize(job, directory):
    root, settings = Path(job['root']), job['settings']
    catalog = VoiceCatalog(root)
    profile = catalog.get(job['voice_id'])
    text = str(job['text'])[:500]
    cache = root/'speech_cache'
    cache.mkdir(parents=True, exist_ok=True, mode=0o700)
    material = json.dumps([text, profile, settings['speech_rate'], settings['local_voice_url'],
                           settings['local_voice_sample_rate']], sort_keys=True, ensure_ascii=False)
    target = cache/(hashlib.sha256(material.encode()).hexdigest()+'.wav')
    if valid_wav(target):
        return {'audio': str(target), 'fallback': False, 'detail': ''}
    audio = Path(directory)/'speech.wav'
    fallback, detail = False, ''
    retry_file = cache/('retry-'+profile['kind']+'.json')
    try:
        if profile['kind'] == 'edge':
            try:
                retry_at = json.loads(retry_file.read_text())['retry_at']
            except (OSError, ValueError, KeyError):
                retry_at = 0
            if time.time() < retry_at and not job.get('preview'):
                raise RuntimeError('联网音色暂时不可达')
        if profile['kind'] == 'edge':
            edge(text, profile, settings['speech_rate'], audio)
        elif profile['kind'] == 'cosyvoice':
            cosyvoice(text, profile, settings, catalog, audio)
        else:
            offline(text, profile, settings['speech_rate'], audio)
        if not valid_wav(audio):
            raise RuntimeError('语音引擎没有生成有效音频')
        retry_file.unlink(missing_ok=True)
    except Exception:
        if profile['kind'] == 'offline':
            raise
        fallback, detail = True, ('本地音色引擎暂不可用，已用离线备用播报'
                                  if profile['kind'] == 'cosyvoice' else '联网音色暂不可用，已用离线备用播报')
        if profile['kind'] == 'edge':
            retry_file.write_text(json.dumps({'retry_at': time.time()+30}))
        audio.unlink(missing_ok=True)
        offline(text, catalog.get('offline_soft'), settings['speech_rate'], audio)
        # Never save a fallback under the requested neural/reference voice's cache key.
        target = cache/('fallback-'+hashlib.sha256((text+str(settings['speech_rate'])).encode()).hexdigest()+'.wav')
    if not valid_wav(audio):
        raise RuntimeError('语音没有生成成功，请检查离线引擎')
    os.replace(audio, target)
    target.chmod(0o600)
    files = sorted(cache.glob('*.wav'), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in files[300:]:
        try:
            old.unlink()
        except OSError:
            pass
    return {'audio': str(target), 'fallback': fallback, 'detail': detail}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--job', required=True)
    parser.add_argument('--result', required=True)
    args = parser.parse_args()
    result = Path(args.result)
    try:
        job = json.loads(Path(args.job).read_text(encoding='utf-8'))
        value = synthesize(job, result.parent)
    except Exception as exc:
        value = {'error': str(exc)[:240] or '语音生成失败'}
    result.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')


if __name__ == '__main__':
    main()
