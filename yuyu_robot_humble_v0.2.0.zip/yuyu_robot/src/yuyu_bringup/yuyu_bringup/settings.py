"""Persistent user preferences and local reference-voice library (no ROS)."""
import array
import copy
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import threading
from urllib.parse import urlsplit
import uuid
import wave

BUILTIN_VOICES = (
    {'id': 'xiaoxiao', 'name': '晓晓 · 温柔陪伴', 'kind': 'edge', 'voice': 'zh-CN-XiaoxiaoNeural'},
    {'id': 'xiaoyi', 'name': '晓伊 · 轻快元气', 'kind': 'edge', 'voice': 'zh-CN-XiaoyiNeural'},
    {'id': 'yunxi', 'name': '云希 · 清朗少年', 'kind': 'edge', 'voice': 'zh-CN-YunxiNeural'},
    {'id': 'yunjian', 'name': '云健 · 沉稳温暖', 'kind': 'edge', 'voice': 'zh-CN-YunjianNeural'},
    {'id': 'offline_soft', 'name': '离线备用 · 轻柔', 'kind': 'offline', 'pitch': 58, 'speed': 155},
    {'id': 'offline_bright', 'name': '离线备用 · 明快', 'kind': 'offline', 'pitch': 72, 'speed': 170},
)
DEFAULTS = {'volume': 70, 'voice_id': 'xiaoxiao', 'speech_rate': 1.0,
            'motion_speed': 0.05, 'local_voice_url': 'http://127.0.0.1:50000',
            'local_voice_sample_rate': 24000, 'asr_model_path': '', 'revision': 0}
MAX_UPLOAD = 12*1024*1024


def data_directory():
    return Path(os.environ.get('YUYU_DATA_DIR', Path.home()/'.local/share/yuyu')).expanduser()


def local_engine_url(value):
    value = str(value).strip().rstrip('/')
    parts = urlsplit(value)
    if (parts.scheme not in ('http', 'https') or parts.hostname not in ('localhost', '127.0.0.1', '::1')
            or parts.username or parts.password or parts.query or parts.fragment
            or parts.path not in ('', '/') or not parts.port):
        raise ValueError('音色引擎地址须是本机地址，例如 http://127.0.0.1:50000')
    return value


def validated_settings(values):
    out = dict(DEFAULTS)
    for key in DEFAULTS:
        if key in values:
            out[key] = values[key]
    for key, low, high in [('volume', 0, 100), ('speech_rate', 0.7, 1.3), ('motion_speed', 0.02, 0.065)]:
        value = float(out[key])
        if not math.isfinite(value):
            raise ValueError('设置数值必须是有限数字')
        out[key] = max(low, min(high, value))
    out['volume'] = int(out['volume'])
    out['local_voice_url'] = local_engine_url(out['local_voice_url'])
    out['local_voice_sample_rate'] = int(out['local_voice_sample_rate'])
    if out['local_voice_sample_rate'] not in (16000, 22050, 24000, 44100, 48000):
        raise ValueError('请选择有效的音色引擎采样率')
    if not re.fullmatch(r'[a-z0-9_-]{1,64}', str(out['voice_id'])):
        raise ValueError('无效的音色编号')
    out['asr_model_path'] = str(out['asr_model_path']).strip()[:1024]
    out['revision'] = max(0, int(out['revision']))
    return out


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temp = tempfile.mkstemp(prefix='.write-', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


class SettingsStore:
    def __init__(self, root=None):
        self.root = Path(root) if root is not None else data_directory()
        self.path = self.root/'settings.json'
        self.lock = threading.RLock()
        try:
            self.value = validated_settings(json.loads(self.path.read_text(encoding='utf-8')))
        except (OSError, ValueError, TypeError):
            self.value = dict(DEFAULTS)

    def get(self):
        with self.lock:
            self.refresh()
            return copy.deepcopy(self.value)

    def refresh(self):
        # The optional model installer and the panel share this file.
        try:
            self.value = validated_settings(json.loads(self.path.read_text(encoding='utf-8')))
        except (OSError, ValueError, TypeError):
            pass

    def update(self, changes):
        with self.lock:
            self.refresh()
            unknown = set(changes)-set(DEFAULTS)
            if unknown:
                raise ValueError('未知设置：'+', '.join(sorted(unknown)))
            result = validated_settings({**self.value, **changes})
            result['revision'] = self.value['revision']+1
            atomic_json(self.path, result)
            self.value = result
            return self.get()


class VoiceCatalog:
    def __init__(self, root=None):
        self.root = Path(root) if root is not None else data_directory()
        self.directory = self.root/'voices'
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.index = self.directory/'catalog.json'
        self.lock = threading.RLock()

    def custom(self):
        try:
            records = json.loads(self.index.read_text(encoding='utf-8'))
            if not isinstance(records, list):
                return []
            return [r for r in records if isinstance(r, dict)
                    and re.fullmatch(r'local_[a-f0-9]{32}', str(r.get('id', '')))]
        except (OSError, ValueError, TypeError):
            return []

    def list(self):
        with self.lock:
            return copy.deepcopy(list(BUILTIN_VOICES)+self.custom())

    def get(self, identity):
        for profile in self.list():
            if profile['id'] == identity:
                return profile
        raise ValueError('没有找到这个音色')

    def reference_path(self, identity):
        profile = self.get(identity)
        if profile['kind'] != 'cosyvoice':
            raise ValueError('这个音色没有参考录音')
        path = self.directory/(identity+'.wav')
        if path.is_symlink() or path.resolve().parent != self.directory.resolve() or not path.is_file():
            raise ValueError('参考录音不存在')
        return path

    def add_reference(self, name, prompt, payload, suffix='.wav'):
        name, prompt = str(name).strip(), str(prompt).strip()
        if not 1 <= len(name) <= 30 or not 1 <= len(prompt) <= 200:
            raise ValueError('请填写音色名称（最多30字）和录音对应文字（最多200字）')
        if not isinstance(payload, bytes) or not 44 <= len(payload) <= MAX_UPLOAD:
            raise ValueError('请选择不超过12MB的有效录音')
        if suffix.lower() not in ('.wav', '.webm', '.mp3', '.m4a', '.ogg', '.flac', '.mp4'):
            raise ValueError('支持 WAV、WebM、MP3、M4A、OGG 或 FLAC 音频')
        identity = 'local_'+uuid.uuid4().hex
        target = self.directory/(identity+'.wav')
        with tempfile.TemporaryDirectory(prefix='import-', dir=str(self.directory)) as temp:
            incoming = Path(temp)/('input'+suffix.lower())
            converted = Path(temp)/'voice.wav'
            incoming.write_bytes(payload)
            converter = shutil.which('ffmpeg')
            if converter:
                result = subprocess.run([converter, '-nostdin', '-v', 'error', '-protocol_whitelist',
                    'file,pipe', '-i', str(incoming), '-vn', '-ac', '1', '-ar', '16000',
                    '-t', '25.1', '-c:a', 'pcm_s16le', str(converted)],
                    capture_output=True, timeout=20)
                if result.returncode:
                    raise ValueError('无法解码录音，请换一个有效音频文件')
            else:
                converted.write_bytes(payload)
            try:
                with wave.open(str(converted), 'rb') as wav:
                    if (wav.getnchannels(), wav.getsampwidth(), wav.getframerate()) != (1, 2, 16000):
                        raise ValueError('请安装 ffmpeg，或导入16kHz单声道16位WAV')
                    duration = wav.getnframes()/wav.getframerate()
                    pcm = array.array('h', wav.readframes(wav.getnframes()))
                    if not 2 <= duration <= 25:
                        raise ValueError('参考录音需要2～25秒，建议清晰录制5～15秒')
                    if not pcm or max(abs(x) for x in pcm) < 40:
                        raise ValueError('录音接近无声，请检查麦克风后重录')
            except (wave.Error, EOFError) as exc:
                raise ValueError('无法读取录音；请安装 ffmpeg 后重试') from exc
            with self.lock:
                records = self.custom()
                if len(records) >= 30:
                    raise ValueError('最多保存30个本地参考音色，请先删除不需要的音色')
                profile = {'id': identity, 'name': name, 'kind': 'cosyvoice',
                           'prompt': prompt, 'duration': round(duration, 2)}
                shutil.copyfile(converted, target)
                target.chmod(0o600)
                try:
                    atomic_json(self.index, records+[profile])
                except Exception:
                    target.unlink(missing_ok=True)
                    raise
                return profile

    def delete(self, identity):
        with self.lock:
            path = self.reference_path(identity)
            records = [r for r in self.custom() if r['id'] != identity]
            atomic_json(self.index, records)
            path.unlink(missing_ok=True)
