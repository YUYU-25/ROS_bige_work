"""Atomic speech controls and interruptible synthesis/playback outside ROS callbacks."""
from collections import deque
import json
import os
from pathlib import Path
import signal
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from .settings import SettingsStore, VoiceCatalog, validated_settings


class CancelledSpeech(Exception):
    pass


class SpeechWorker:
    def __init__(self, event, root=None, audio=True, renderer=None, player=None):
        self.store, self.catalog = SettingsStore(root), VoiceCatalog(root)
        self.settings = self.store.get()
        self.event, self.audio = event, audio
        self.renderer, self.player = renderer or self.render, player or self.play
        self.condition = threading.Condition(threading.RLock())
        self.queue, self.seen = deque(), deque(maxlen=128)
        self.silent, self.closed, self.version = False, False, 0
        self.cancelled, self.process = threading.Event(), None
        self.thread = threading.Thread(target=self.run, name='yuyu-speech', daemon=True)
        self.thread.start()

    def status(self, state, **extra):
        self.event('status', {'state': state, 'muted': self.silent, **extra})

    def set_settings(self, settings):
        value = validated_settings(settings)
        with self.condition:
            if value['revision'] >= self.settings['revision']:
                self.settings = value

    def kill_process(self):
        process = self.process
        if process and process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except (ProcessLookupError, PermissionError):
                pass

    def submit(self, action, text='', voice_id=None, identity=None):
        text = str(text).strip()[:500]
        with self.condition:
            if self.closed or identity and identity in self.seen:
                return
            if identity:
                self.seen.append(identity)
            if action in ('mute', 'resume', 'cancel'):
                self.version += 1
                self.cancelled.set()
                self.kill_process()
                self.queue.clear()
            if action == 'mute':
                self.silent = True
            elif action == 'resume':
                self.silent = False
            self.event('text', text) if text else None
            if action == 'mute' or self.silent and action != 'preview':
                self.status('muted')
                self.event('done', True)
                return
            if not text:
                self.event('done', True)
                return
            while len(self.queue) >= 3:
                self.queue.popleft()
            self.queue.append({'text': text, 'voice_id': voice_id or self.settings['voice_id'],
                               'version': self.version, 'preview': action == 'preview'})
            self.event('done', False)
            self.status('queued')
            self.condition.notify_all()

    def active(self, job, cancel):
        return not cancel.is_set() and not self.closed and job['version'] == self.version

    def wait_process(self, process, job, cancel, timeout):
        deadline = time.monotonic()+timeout
        while process.poll() is None:
            if not self.active(job, cancel):
                self.kill_process()
                try:
                    process.wait(timeout=0.7)
                except subprocess.TimeoutExpired:
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    process.wait(timeout=1)
                raise CancelledSpeech()
            if time.monotonic() > deadline:
                self.kill_process()
                try:
                    process.wait(timeout=0.7)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=1)
                raise RuntimeError('语音处理超时，请检查当前音色引擎')
            time.sleep(0.03)
        if process.returncode:
            raise RuntimeError('语音进程未能完成，请检查音频设备')

    def render(self, job, settings, cancel):
        jobs = self.store.root/'jobs'
        jobs.mkdir(parents=True, exist_ok=True, mode=0o700)
        with tempfile.TemporaryDirectory(prefix='speech-', dir=str(jobs)) as folder:
            request, result = Path(folder)/'job.json', Path(folder)/'result.json'
            request.write_text(json.dumps({**job, 'settings': settings, 'root': str(self.store.root)},
                                          ensure_ascii=False), encoding='utf-8')
            request.chmod(0o600)
            process = subprocess.Popen([os.environ.get('YUYU_SPEECH_PYTHON', sys.executable), '-m', 'yuyu_bringup.voice_backend',
                '--job', str(request), '--result', str(result)], start_new_session=True,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            with self.condition:
                self.process = process
            self.wait_process(process, job, cancel, 55)
            value = json.loads(result.read_text(encoding='utf-8'))
            if value.get('error'):
                raise RuntimeError(value['error'])
            path = Path(value['audio']).resolve()
            if path.parent != (self.store.root/'speech_cache').resolve() or not path.is_file():
                raise RuntimeError('语音缓存文件无效')
            return value

    def live_volume(self, process, volume):
        pactl = shutil.which('pactl')
        if not pactl:
            return
        try:
            result = subprocess.run([pactl, '-f', 'json', 'list', 'sink-inputs'],
                                    capture_output=True, timeout=0.4)
            for stream in json.loads(result.stdout or b'[]'):
                props = stream.get('properties', {})
                if (str(props.get('application.process.id')) == str(process.pid)
                        or props.get('media.name') == 'YUYU_speech'):
                    subprocess.run([pactl, 'set-sink-input-volume', str(stream['index']),
                                    str(volume)+'%'], capture_output=True, timeout=0.4)
        except (OSError, ValueError, subprocess.TimeoutExpired):
            pass

    def play(self, value, job, settings, cancel):
        volume = self.settings['volume']
        path = value['audio']
        if shutil.which('paplay'):
            args = ['paplay', '--client-name=YUYU', '--stream-name=YUYU_speech',
                    '--volume='+str(round(volume*65536/100)), path]
        elif shutil.which('ffplay'):
            args = ['ffplay', '-nodisp', '-autoexit', '-loglevel', 'quiet', '-volume', str(volume), path]
        else:
            raise RuntimeError('没有可用的音频播放器，请安装 pulseaudio-utils 或 ffmpeg')
        process = subprocess.Popen(args, start_new_session=True, stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL)
        with self.condition:
            self.process = process
        deadline = time.monotonic()+120
        while process.poll() is None:
            if not self.active(job, cancel):
                self.kill_process()
                try:
                    process.wait(timeout=0.7)
                except subprocess.TimeoutExpired:
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    process.wait(timeout=1)
                raise CancelledSpeech()
            if self.settings['volume'] != volume:
                volume = self.settings['volume']
                self.live_volume(process, volume)
            if time.monotonic() > deadline:
                self.kill_process()
                try:
                    process.wait(timeout=0.7)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=1)
                raise RuntimeError('播放超时，已停止当前音频')
            time.sleep(0.04)
        process.wait()
        if process.returncode:
            raise RuntimeError('音频播放失败，请检查 Ubuntu 声音输出')

    def run(self):
        while True:
            with self.condition:
                self.condition.wait_for(lambda: self.closed or self.queue)
                if self.closed:
                    return
                job = self.queue.popleft()
                cancel = self.cancelled = threading.Event()
                settings = dict(self.settings)
            try:
                if not self.active(job, cancel):
                    continue
                if not self.audio or not settings['volume']:
                    self.status('text_only', detail='当前为文字模式' if not self.audio else '音量为0')
                    continue
                self.status('generating', voice_id=job['voice_id'])
                value = self.renderer(job, settings, cancel)
                if not self.active(job, cancel):
                    continue
                self.status('playing', voice_id=job['voice_id'], fallback=value.get('fallback', False),
                            detail=value.get('detail', ''))
                self.player(value, job, settings, cancel)
                if self.active(job, cancel):
                    self.status('idle')
            except CancelledSpeech:
                pass
            except Exception as exc:
                if self.active(job, cancel):
                    self.status('error', detail=str(exc)[:240])
            finally:
                with self.condition:
                    self.process = None
                    idle = not self.queue
                if idle and not self.closed:
                    self.event('done', True)

    def close(self):
        with self.condition:
            self.closed = True
            self.cancelled.set()
            self.kill_process()
            self.queue.clear()
            self.condition.notify_all()
        self.thread.join(timeout=2)
