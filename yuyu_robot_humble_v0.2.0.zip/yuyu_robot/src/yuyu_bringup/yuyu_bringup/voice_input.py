"""Optional, local-only push-to-talk recognition using a separately installed Vosk model."""
import base64
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import threading
import wave

_models = {}
_lock = threading.Lock()


def recognize_upload(body, settings, root):
    model_path = Path(settings.get('asr_model_path', '')).expanduser()
    if not (model_path/'am/final.mdl').is_file():
        raise ValueError('离线语音识别模型尚未安装，请在语音输入设置中完成准备')
    try:
        import vosk
    except ImportError as exc:
        raise ValueError('请先安装语音输入依赖 vosk') from exc
    encoded = body.get('audio', '')
    if not isinstance(encoded, str) or len(encoded) > 8*1024*1024:
        raise ValueError('录音过大，请控制在15秒以内')
    try:
        payload = base64.b64decode(encoded, validate=True)
    except ValueError as exc:
        raise ValueError('录音数据不完整') from exc
    suffix = Path(str(body.get('filename', 'input.webm'))).suffix.lower()
    if suffix not in ('.wav', '.webm', '.ogg', '.mp3', '.m4a'):
        raise ValueError('不支持这种录音格式')
    temporary = Path(root)/'asr_jobs'
    temporary.mkdir(parents=True, exist_ok=True, mode=0o700)
    with tempfile.TemporaryDirectory(dir=str(temporary)) as folder:
        incoming, converted = Path(folder)/('input'+suffix), Path(folder)/'input.wav'
        incoming.write_bytes(payload)
        converter = shutil.which('ffmpeg')
        if converter:
            result = subprocess.run([converter, '-nostdin', '-v', 'error', '-protocol_whitelist',
                'file,pipe', '-i', str(incoming), '-ac', '1', '-ar', '16000', '-t', '16',
                '-c:a', 'pcm_s16le', str(converted)], capture_output=True, timeout=15)
            if result.returncode:
                raise ValueError('无法读取录音，请检查麦克风后重试')
        else:
            converted.write_bytes(payload)
        try:
            with wave.open(str(converted), 'rb') as stream:
                if (stream.getnchannels(), stream.getsampwidth(), stream.getframerate()) != (1, 2, 16000):
                    raise ValueError('请安装 ffmpeg 以处理麦克风录音')
                with _lock:
                    key = str(model_path.resolve())
                    if key not in _models:
                        _models.clear()
                        _models[key] = vosk.Model(key)
                    recognizer = vosk.KaldiRecognizer(_models[key], 16000)
                texts = []
                while True:
                    chunk = stream.readframes(4000)
                    if not chunk:
                        break
                    if recognizer.AcceptWaveform(chunk):
                        texts.append(json.loads(recognizer.Result()).get('text', ''))
                texts.append(json.loads(recognizer.FinalResult()).get('text', ''))
        except (wave.Error, EOFError) as exc:
            raise ValueError('无法读取录音，请安装 ffmpeg 后重试') from exc
    text = ''.join(texts).replace(' ', '').strip()
    if not text:
        raise ValueError('这次没有听清，请靠近麦克风再说一次')
    return text
