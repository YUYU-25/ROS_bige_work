"""Shared ROS helpers. Watchdogs use steady time even when Gazebo is paused."""
import math
from rclpy.clock import Clock, ClockType
from rclpy.time import Time
from rclpy.qos import QoSProfile, DurabilityPolicy
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from tf2_ros import TransformException

LATCH = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL)


def string(value):
    return String(data=str(value))


def twist(v=0.0, w=0.0):
    value = Twist()
    value.linear.x, value.angular.z = float(v), float(w)
    return value


def wall_timer(node, period, callback):
    if not hasattr(node, '_yuyu_wall_clock'):
        node._yuyu_wall_clock = Clock(clock_type=ClockType.STEADY_TIME)
    return node.create_timer(period, callback, clock=node._yuyu_wall_clock)


def pose_of(msg):
    p, q = msg.pose.pose.position, msg.pose.pose.orientation
    return p.x, p.y, math.atan2(2*(q.w*q.z+q.x*q.y), 1-2*(q.y*q.y+q.z*q.z))


def pose_in_map(buffer, now):
    transform = buffer.lookup_transform('map', 'base_footprint', Time())
    stamp = transform.header.stamp
    age = (now.nanoseconds-stamp.sec*1000000000-stamp.nanosec)/1e9
    if age > 0.7 or age < -1.5:
        raise TransformException('map位姿时间不一致或已过期')
    p, q = transform.transform.translation, transform.transform.rotation
    return p.x, p.y, math.atan2(2*(q.w*q.z+q.x*q.y), 1-2*(q.y*q.y+q.z*q.z))
