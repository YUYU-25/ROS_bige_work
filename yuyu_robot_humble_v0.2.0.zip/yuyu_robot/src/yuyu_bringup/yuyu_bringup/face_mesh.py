"""把同一张表情图像转成 RViz 可显示的彩色屏幕网格，不依赖 Gazebo 插件。"""


def image_rectangles(image):
    """无损合并同色像素，避免给每个像素单独创建一个 Marker。"""
    image = image if image.mode == 'RGB' else image.convert('RGB')
    width, height = image.size
    pixels = list(image.getdata())
    active, rectangles = {}, []
    for row in range(height):
        current = {}
        left = 0
        while left < width:
            color = pixels[row*width+left]
            right = left+1
            while right < width and pixels[row*width+right] == color:
                right += 1
            key = (left, right, color)
            # 同一条水平色带连续出现时，沿纵向合并为一个矩形。
            rectangle = active.pop(key, None)
            if rectangle is None:
                rectangle = [left, row, right, row+1, color]
            else:
                rectangle[3] = row+1
            current[key] = rectangle
            left = right
        rectangles.extend(active.values())
        active = current
    rectangles.extend(active.values())
    return rectangles


def build_face_marker(image, stamp, width=0.10, height=0.06):
    """局部 z 指向屏幕外；图像上方映射到局部 +y，保持正面文字可读。"""
    from geometry_msgs.msg import Point
    from std_msgs.msg import ColorRGBA
    from visualization_msgs.msg import Marker

    if width <= 0 or height <= 0:
        raise ValueError('屏幕宽高必须大于零')
    marker = Marker()
    marker.header.frame_id = 'face_screen_link'
    marker.header.stamp = stamp
    marker.ns, marker.id = 'yuyu_face_screen', 0
    marker.type, marker.action = Marker.TRIANGLE_LIST, Marker.ADD
    marker.pose.orientation.w = 1.0
    marker.scale.x = marker.scale.y = marker.scale.z = 1.0
    marker.color = ColorRGBA(r=1.0, g=1.0, b=1.0, a=1.0)
    # 即使表情没有改变，机器人移动后也必须跟随 face_screen_link 的最新 TF。
    marker.frame_locked = True
    points, colors, palette = [], [], {}
    for left, top, right, bottom, rgb in image_rectangles(image):
        x0, x1 = width*(left/image.width-0.5), width*(right/image.width-0.5)
        y0, y1 = height*(0.5-bottom/image.height), height*(0.5-top/image.height)
        # URDF 屏幕厚 1 mm，前表面为 z=0.0005；稍前移以免深度冲突。
        z = 0.0007
        corners = [(x0, y0), (x1, y0), (x1, y1),
                   (x0, y0), (x1, y1), (x0, y1)]
        points.extend(Point(x=float(x), y=float(y), z=z) for x, y in corners)
        if rgb not in palette:
            palette[rgb] = ColorRGBA(r=rgb[0]/255.0, g=rgb[1]/255.0,
                                    b=rgb[2]/255.0, a=1.0)
        colors.extend([palette[rgb]]*6)
    marker.points, marker.colors = points, colors
    return marker
