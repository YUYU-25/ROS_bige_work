"""A short differential-drive dance; no fictitious arm or pitch joints."""
import math
from .core import wrap_angle

# Duration, forward m/s, yaw rad/s, caption. Symmetric swings close each beat.
BEATS = (
    (0.8, 0.0, 0.65, '给你比个小心心'),
    (1.6, 0.0, -0.65, '给你比个小心心'),
    (0.8, 0.0, 0.65, '开心正在冒泡泡'),
    (0.6, 0.032, 0.0, '向你靠近一点点'),
    (1.2, -0.032, 0.0, '快乐摇一摇'),
    (0.6, 0.032, 0.0, '快乐摇一摇'),
    (0.9, 0.0, 0.75, '这颗心心送给你'),
    (1.8, 0.0, -0.75, '这颗心心送给你'),
    (0.9, 0.0, 0.75, '今天也想陪着你'),
    (0.8, 0.02, 0.0, '一起把开心存起来'),
    (0.8, -0.02, 0.0, '一起把开心存起来'),
    (0.8, 0.0, 0.4, '你笑起来真好看'),
    (0.8, 0.0, -0.4, '你笑起来真好看'),
)
DURATION = sum(b[0] for b in BEATS)


def beat_at(elapsed):
    for duration, v, w, caption in BEATS:
        if elapsed < duration:
            return v, w, caption
        elapsed -= duration
    return 0.0, 0.0, ''


def final_yaw_velocity(pose, origin):
    error = wrap_angle(origin[2]-pose[2])
    return max(-0.45, min(0.45, 1.4*error)) if abs(error) > 0.08 else 0.0


def displacement(pose, origin):
    return math.hypot(pose[0]-origin[0], pose[1]-origin[1])
