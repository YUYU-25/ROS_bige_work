"""Pillow 表情画布；图像坐标与 Gazebo 屏幕宽高一致。"""
import math
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

EXPRESSIONS = ('happy', 'care', 'sleepy', 'curious', 'silent', 'dance')


def find_font(requested=''):
    candidates = [requested, '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc',
                  '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
                  '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc']
    for path in candidates:
        if path and Path(path).is_file():
            return path
    raise FileNotFoundError('缺少中文字体，请安装 fonts-noto-cjk 或设置 font_path 参数')


def render(expression='happy', text='', font_path='', phase=0.0):
    expression = expression if expression in EXPRESSIONS else 'happy'
    phase = phase if math.isfinite(phase) else 0.0
    if expression == 'dance' and not text:
        text = ('给你比个小心心', '开心正在冒泡泡', '把快乐轻轻送给你', '今天也想陪着你')[int(phase/4) % 4]
    bg = dict(happy='#087eb0', care='#8d79ab', sleepy='#4a505b',
              curious='#b28b08', silent='#101c40', dance='#fff1f6')[expression]
    img = Image.new('RGB', (320, 192), bg)
    d = ImageDraw.Draw(img)
    white = '#e5fcff'
    if expression == 'dance':
        white = '#cc4078'
        for i in range(8):
            radius = 6+(i*3) % 9
            x = 20+i*40+math.sin(phase*0.8+i)*7
            y = 210-(phase*21+i*29) % 245
            color = ('#f8ccdc', '#f2b4cd', '#f9dce7')[i % 3]
            d.ellipse((x-radius, y-radius, x+radius, y+radius), fill=color,
                      outline='#eaa0bd', width=2)
            d.ellipse((x-radius/2, y-radius/2, x-radius/2+3, y-radius/2+3), fill='#ffffff')
        d.rounded_rectangle((12, 109, 308, 188), 16, fill='#ffe3ee')
    # 有文字时把表情上移，预留三行中文区域。
    cy = 55 if text else 82
    for cx in (106, 214):
        if expression == 'happy':
            d.rounded_rectangle((cx-19, cy-21, cx+19, cy+17), 9, fill=white)
        elif expression == 'care':
            d.ellipse((cx-9, cy-8, cx+9, cy+10), fill=white)
            tilt = -1 if cx < 160 else 1
            d.line((cx-15, cy-22+tilt*5, cx+15, cy-22-tilt*5), fill=white, width=4)
        elif expression == 'sleepy':
            d.line((cx-20, cy, cx+20, cy), fill=white, width=5)
        elif expression in ('curious', 'silent'):
            d.rounded_rectangle((cx-19, cy-22, cx+19, cy+20), 16,
                                outline=white, width=4)
        elif expression == 'dance':
            points = []
            pulse = 1+0.06*math.sin(phase*4)
            for i in range(48):
                a = i*math.pi/24
                points.append((cx+1.35*pulse*16*math.sin(a)**3,
                    cy-1.35*pulse*(13*math.cos(a)-5*math.cos(2*a)
                                  -2*math.cos(3*a)-math.cos(4*a))))
            d.polygon(points, fill=white)
    if expression in ('happy', 'care', 'dance'):
        d.arc((140, cy+12, 180, cy+39), 0, 180, fill=white, width=4)
    elif expression == 'curious':
        d.ellipse((152, cy+27, 168, cy+43), outline=white, width=3)
    elif expression == 'sleepy':
        d.text((148, cy+16), 'Zz', fill=white,
               font=ImageFont.truetype(find_font(font_path), 22))
    if text:
        # 一行最多 15 字；超长消息完整轮播到下一页，由节点负责分页。
        lines = [text[i:i+15] for i in range(0, len(text), 15)][:3]
        font = ImageFont.truetype(find_font(font_path), 19)
        for i, line in enumerate(lines):
            box = d.textbbox((0, 0), line, font=font)
            d.text(((320-(box[2]-box[0]))/2, 115+i*24), line,
                   fill='#a83062' if expression == 'dance' else 'white', font=font, stroke_width=0)
    return img
