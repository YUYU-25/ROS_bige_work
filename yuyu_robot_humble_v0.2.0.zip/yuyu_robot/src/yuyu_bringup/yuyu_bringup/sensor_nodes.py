"""Display, sensor normalization, safety diagnostics and the single velocity outlet."""
import array
import json
import math
import struct
import time
from functools import partial
from rclpy.node import Node
from rclpy.serialization import deserialize_message
from rclpy.time import Time
from rclpy.qos import qos_profile_sensor_data
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry, OccupancyGrid
from sensor_msgs.msg import Image, Imu, LaserScan, Range
from std_msgs.msg import Bool, String
from tf2_ros import Buffer, TransformListener, TransformException
from visualization_msgs.msg import Marker
from .core import CLIFF_NAMES, cliff_state, safe_velocity, scan_without_body, SCAN_SELF_RADIUS
from .face import EXPRESSIONS, find_font, render
from .face_mesh import build_face_marker
from .ros_utils import LATCH, pose_in_map, pose_of, string, twist, wall_timer
from .settings import SettingsStore, validated_settings


class FaceDisplay(Node):
    def __init__(self):
        super().__init__('face_display')
        self.declare_parameter('font_path', '')
        self.declare_parameter('screen_width', 0.10)
        self.declare_parameter('screen_height', 0.06)
        self.font = find_font(self.get_parameter('font_path').value)
        self.width, self.height = (float(self.get_parameter(k).value)
                                   for k in ('screen_width', 'screen_height'))
        self.expr, self.text, self.text_at = 'happy', '', 0.0
        self.pub = self.create_publisher(Image, '/face_image', 2)
        self.screen_pub = self.create_publisher(Marker, '/face_screen_marker', LATCH)
        self.marker, self.pixels, self.screen_at = None, None, -math.inf
        self.create_subscription(String, '/face_expr', self.on_expr, 10)
        self.create_subscription(String, '/face_text', self.on_text, 10)
        wall_timer(self, 0.125, self.tick)

    def on_expr(self, msg):
        if msg.data in EXPRESSIONS:
            self.expr = msg.data

    def on_text(self, msg):
        self.text, self.text_at = msg.data.replace('\n', ' ')[:500], time.monotonic()

    def tick(self):
        now = time.monotonic()
        duration = min(12.0, max(4.5, len(self.text)*0.15))
        elapsed = now-self.text_at
        text = ''
        if self.text and elapsed < duration:
            pages = math.ceil(len(self.text)/45)
            page = min(pages-1, int(elapsed/duration*pages))
            text = self.text[page*45:(page+1)*45]
        image = render(self.expr, text, self.font, now)
        pixels = image.tobytes()
        msg = Image()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'face_screen_link'
        msg.width, msg.height = image.size
        msg.encoding, msg.step, msg.data = 'rgb8', image.width*3, pixels
        self.pub.publish(msg)
        changed = pixels != self.pixels
        if changed and now-self.screen_at >= 0.2:
            self.marker = build_face_marker(image, Time().to_msg(), self.width, self.height)
            self.pixels = pixels
        if self.marker is not None and (changed and now-self.screen_at >= 0.2 or now-self.screen_at >= 1):
            self.screen_pub.publish(self.marker)
            self.screen_at = now


class RangeAdapter(Node):
    def __init__(self):
        super().__init__('range_adapter')
        self.scan = self.create_publisher(LaserScan, '/scan', qos_profile_sensor_data)
        self.create_subscription(LaserScan, '/raw/scan', self.convert_scan, qos_profile_sensor_data)
        self.outputs = {}
        topics = ['/cliff/'+n for n in CLIFF_NAMES]+['/proximity/front', '/proximity/rear']
        for topic in topics:
            self.outputs[topic] = self.create_publisher(Range, topic, qos_profile_sensor_data)
            self.create_subscription(Range, '/raw'+topic, partial(self.convert, topic),
                                     qos_profile_sensor_data, raw=True)

    def convert_scan(self, msg):
        msg.ranges = array.array('f', scan_without_body(msg.ranges, msg.range_max))
        msg.range_min = max(msg.range_min, SCAN_SELF_RADIUS)
        self.scan.publish(msg)

    def convert(self, topic, payload):
        if len(payload) < 8:
            return
        data = bytearray(payload)
        endian = '<' if data[1] & 1 else '>'
        if struct.unpack(endian+'f', data[-4:])[0] > 1e30:
            data[-4:] = struct.pack(endian+'f', math.inf)
        try:
            value = deserialize_message(bytes(data), Range)
        except (RuntimeError, ValueError, AssertionError):
            return
        self.outputs[topic].publish(value)


class EdgeGuard(Node):
    def __init__(self):
        super().__init__('edge_guard')
        self.declare_parameter('safety_frame', 'odom')
        self.declare_parameter('require_slam_map', False)
        self.use_map = self.get_parameter('safety_frame').value == 'map'
        self.require_slam = bool(self.get_parameter('require_slam_map').value)
        self.map_at = 0.0
        self.samples, self.pose, self.odom_at, self.scan_at = {}, (0.0, 0.0, 0.0), 0.0, 0.0
        self.wheel_at = self.imu_at = 0.0
        self.tf = Buffer()
        self.listener = TransformListener(self.tf, self)
        self.pub = self.create_publisher(Bool, '/edge_detected', LATCH)
        self.status = self.create_publisher(String, '/safety_status', 5)
        self.create_subscription(Odometry, '/odom', self.on_odom, qos_profile_sensor_data)
        self.create_subscription(Odometry, '/wheel/odom',
            lambda m: setattr(self, 'wheel_at', time.monotonic()), qos_profile_sensor_data)
        self.create_subscription(Imu, '/imu/data',
            lambda m: setattr(self, 'imu_at', time.monotonic()), qos_profile_sensor_data)
        self.create_subscription(OccupancyGrid, '/map', self.on_map, LATCH)
        self.create_subscription(LaserScan, '/scan', self.on_scan, qos_profile_sensor_data)
        for name in CLIFF_NAMES:
            self.create_subscription(Range, '/cliff/'+name, partial(self.on_range, name), qos_profile_sensor_data)
        wall_timer(self, 0.05, self.tick)

    def on_range(self, name, msg):
        self.samples[name] = msg.range, time.monotonic()

    def on_odom(self, msg):
        self.odom_at = time.monotonic()
        if not self.use_map:
            self.pose = pose_of(msg)

    def on_scan(self, msg):
        self.scan_at = time.monotonic()

    def on_map(self, msg):
        if msg.info.width > 0 and msg.info.height > 0 and msg.data:
            self.map_at = time.monotonic()

    def tick(self):
        now = time.monotonic()
        ready, edges = cliff_state(self.samples, now)
        missing = [n for n in CLIFF_NAMES if n not in self.samples or now-self.samples[n][1] > 0.7]
        for name, stamp in [('odom', self.odom_at), ('scan', self.scan_at),
                            ('wheel_odom', self.wheel_at), ('imu', self.imu_at)]:
            if now-stamp > 0.7:
                missing.append(name)
        if self.require_slam and now-self.map_at > 3.0:
            missing.append('slam_map')
        pose_error = ''
        if self.use_map:
            try:
                self.pose = pose_in_map(self.tf, self.get_clock().now())
            except TransformException as exc:
                pose_error = str(exc)[:160]
                missing.append('map_pose')
        if not all(math.isfinite(v) for v in self.pose):
            self.pose = (0.0, 0.0, 0.0)
            missing.append('finite_pose')
        ready = bool(ready and not missing)
        self.pub.publish(Bool(data=not ready or any(edges.values())))
        self.status.publish(string(json.dumps({'ready': ready, 'edges': edges, 'pose': self.pose,
             'missing': missing, 'pose_error': pose_error}, ensure_ascii=False)))


class VelocityMux(Node):
    def __init__(self):
        super().__init__('velocity_mux')
        self.mode, self.commands = 'idle', {}
        self.manual_at, self.manual_source = 0.0, 'teleop'
        self.status, self.status_at = {}, 0.0
        self.near = {'front': (0.0, 0.0), 'rear': (0.0, 0.0)}
        self.hold, self.gated, self.generation = True, False, -1
        self.released = {'teleop': True, 'panel': True}
        self.settings = SettingsStore().get()
        self.pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.report = self.create_publisher(String, '/motion_status', 10)
        self.manual = self.create_publisher(Bool, '/manual_override', 10)
        self.create_subscription(String, '/motion_mode', self.on_mode, LATCH)
        self.create_subscription(String, '/motion_gate', self.on_gate, LATCH)
        self.create_subscription(String, '/user_settings', self.on_settings, LATCH)
        self.create_subscription(String, '/safety_status', self.on_status, 5)
        for source in ('teleop', 'panel', 'nav', 'behavior', 'dance'):
            self.create_subscription(Twist, '/'+source+'_cmd_vel', partial(self.on_cmd, source), 10)
        for side in ('front', 'rear'):
            self.create_subscription(Range, '/proximity/'+side, partial(self.on_near, side), qos_profile_sensor_data)
        wall_timer(self, 0.05, self.tick)

    def on_mode(self, msg):
        if not self.gated:
            self.mode, self.hold = msg.data, False

    def on_gate(self, msg):
        try:
            value = json.loads(msg.data)
            mode, hold, generation = value['mode'], bool(value['hold']), int(value['generation'])
        except (ValueError, TypeError, KeyError):
            return
        self.gated = True
        if generation != self.generation or mode != self.mode:
            for source in ('nav', 'dance', 'behavior'):
                self.commands.pop(source, None)
        if hold and not self.hold:
            self.released = dict.fromkeys(self.released, False)
            self.manual_at = 0.0
            self.commands.clear()
            self.pub.publish(Twist())
        self.mode, self.hold, self.generation = mode, hold, generation

    def on_settings(self, msg):
        try:
            value = validated_settings(json.loads(msg.data))
            if value['revision'] >= self.settings['revision']:
                self.settings = value
        except (ValueError, TypeError):
            pass

    def on_status(self, msg):
        try:
            self.status, self.status_at = json.loads(msg.data), time.monotonic()
        except (ValueError, TypeError):
            pass

    def on_cmd(self, source, msg):
        self.commands[source] = msg, time.monotonic()
        if source not in self.released:
            return
        nonzero = abs(msg.linear.x) > 1e-5 or abs(msg.angular.z) > 1e-5
        if not nonzero:
            self.released[source] = True
            return
        if self.hold and not self.released[source]:
            return
        self.hold = False
        self.manual_at, self.manual_source = time.monotonic(), source
        self.manual.publish(Bool(data=True))

    def on_near(self, side, msg):
        self.near[side] = msg.range, time.monotonic()

    def tick(self):
        now = time.monotonic()
        source = self.manual_source if now-self.manual_at < 0.35 else self.mode
        msg, stamp = self.commands.get(source, (Twist(), 0.0))
        v, w = (msg.linear.x, msg.angular.z) if now-stamp < 0.35 and not self.hold else (0.0, 0.0)
        if not math.isfinite(v) or not math.isfinite(w):
            v, w = 0.0, 0.0
        v = max(-self.settings['motion_speed'], min(self.settings['motion_speed'], v))
        w = max(-0.85, min(0.85, w))
        ranges = {side: distance if now-at < 0.7 else 0.0
                  for side, (distance, at) in self.near.items()}
        v, w = safe_velocity(v, w, self.status, now-self.status_at, ranges['front'], ranges['rear'])
        self.pub.publish(twist(v, w))
        self.report.publish(string('%s v=%.3f w=%.3f' % (source, v, w)))
