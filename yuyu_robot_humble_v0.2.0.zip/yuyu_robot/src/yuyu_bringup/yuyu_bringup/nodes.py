"""Public executable entry points; implementations live in focused modules."""
import rclpy
from .sensor_nodes import FaceDisplay, RangeAdapter, EdgeGuard, VelocityMux
from .interaction_nodes import VoiceEmotion, TTS, BehaviorManager, Dance
from .control_node import ControlPanel


def run(cls):
    rclpy.init()
    node = cls()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


def voice_main():
    run(VoiceEmotion)


def face_main():
    run(FaceDisplay)


def tts_main():
    run(TTS)


def edge_main():
    run(EdgeGuard)


def range_main():
    run(RangeAdapter)


def mux_main():
    run(VelocityMux)


def behavior_main():
    run(BehaviorManager)


def dance_main():
    run(Dance)


def panel_main():
    run(ControlPanel)
