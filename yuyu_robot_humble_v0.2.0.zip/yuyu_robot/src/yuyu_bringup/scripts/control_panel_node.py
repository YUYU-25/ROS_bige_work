#!/usr/bin/env python3
"""Installed executable: ros2 run yuyu_bringup control_panel_node."""
from yuyu_bringup.nodes import panel_main

if __name__ == '__main__':
    panel_main()
