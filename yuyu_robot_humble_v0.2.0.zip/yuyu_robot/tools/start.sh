#!/usr/bin/env bash
# 用途：在“主程序”终端一键启动，退出时在这个终端按 Ctrl+C。
set -eo pipefail
project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$project_dir/tools/env.sh"
if [[ ! -f "$project_dir/install/setup.bash" ]]; then
  echo '尚未编译，请先在项目目录运行 colcon build --symlink-install。' >&2
  exit 1
fi
# Keep the descriptor open for the lifetime of the launch process.
exec 9>"${XDG_RUNTIME_DIR:-/tmp}/yuyu-${UID}-${ROS_DOMAIN_ID}.lock"
if ! flock -n 9; then
  echo '禹禹已在运行。请先在原来的主程序终端按 Ctrl+C，再重新启动。' >&2
  exit 1
fi
exec ros2 launch yuyu_gazebo demo_all.launch.py "$@"
