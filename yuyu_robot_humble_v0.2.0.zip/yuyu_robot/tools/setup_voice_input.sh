#!/usr/bin/env bash
# Optional offline Chinese recognition model; run in Ubuntu, not Windows.
set -euo pipefail
project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$project_dir/tools/env.sh"
if ! python3 -c 'import vosk' 2>/dev/null; then
  echo '请先运行 bash tools/install_dependencies.sh 安装语音依赖。' >&2
  exit 1
fi
python3 - <<'PY'
from pathlib import Path
import shutil
import tempfile
import urllib.request
import zipfile
from yuyu_bringup.settings import SettingsStore
store = SettingsStore()
destination = store.root/'models/vosk-model-small-cn-0.22'
if not (destination/'am/final.mdl').is_file():
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=destination.parent) as folder:
        archive = Path(folder)/'model.zip'
        print('正在从 Vosk 官方站点下载中文识别模型……', flush=True)
        with urllib.request.urlopen('https://alphacephei.com/vosk/models/vosk-model-small-cn-0.22.zip', timeout=30) as response, archive.open('wb') as output:
            total=0
            while True:
                chunk=response.read(1024*1024)
                if not chunk: break
                total+=len(chunk)
                if total > 100*1024*1024: raise RuntimeError('模型下载大小超出预期')
                output.write(chunk)
        extracted=Path(folder)/'extracted'
        with zipfile.ZipFile(archive) as z:
            if sum(i.file_size for i in z.infolist()) > 180*1024*1024: raise RuntimeError('模型大小超出预期')
            for item in z.infolist():
                target=(extracted/item.filename).resolve()
                if extracted.resolve() not in target.parents: raise RuntimeError('模型路径无效')
            z.extractall(extracted)
        model=extracted/'vosk-model-small-cn-0.22'
        if not (model/'am/final.mdl').is_file(): raise RuntimeError('模型内容不完整')
        if destination.exists(): raise RuntimeError('已有同名但不完整的模型目录，请先检查：'+str(destination))
        shutil.move(str(model),destination)
store.update({'asr_model_path':str(destination)})
print('识别模型已准备：'+str(destination))
print('控制面板会自动加载模型目录；也可在“语音输入”页确认上述路径。')
PY
