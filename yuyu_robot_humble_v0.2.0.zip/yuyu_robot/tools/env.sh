#!/usr/bin/env bash
# source this in the command terminal; start.sh uses the same environment.
yuyu_project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source /opt/ros/humble/setup.bash
if [[ -f "$yuyu_project_dir/install/setup.bash" ]]; then
  source "$yuyu_project_dir/install/setup.bash"
fi
export ROS_DOMAIN_ID="${ROS_DOMAIN_ID:-23}"
export ROS_LOCALHOST_ONLY="${ROS_LOCALHOST_ONLY:-0}"
export FASTRTPS_DEFAULT_PROFILES_FILE="${FASTRTPS_DEFAULT_PROFILES_FILE:-$yuyu_project_dir/tools/udp_only.xml}"
if [[ -f "$yuyu_project_dir/.venv/lib/python3.10/site-packages/edge_tts/__init__.py" ]]; then
  export PYTHONPATH="$yuyu_project_dir/.venv/lib/python3.10/site-packages:${PYTHONPATH:-}"
fi
unset yuyu_project_dir
