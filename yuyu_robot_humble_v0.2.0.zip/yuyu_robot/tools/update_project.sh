#!/usr/bin/env bash
# Run from the newly extracted update folder, e.g. ~/Downloads/yuyu_robot.
set -eo pipefail
new_project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
target_project="${1:-$HOME/yuyu_robot}"
if command -v pgrep >/dev/null && pgrep -u "$UID" -f '(^|/)ros2 launch yuyu_gazebo demo_all.launch.py' >/dev/null; then
  echo '检测到禹禹主程序仍在运行，请先在主程序终端按 Ctrl+C 关闭场景。' >&2
  exit 1
fi
if [[ "$target_project" != /* ]]; then
  echo '目标目录请使用绝对路径，例如 ~/yuyu_robot。' >&2
  exit 1
fi
if [[ -f "${XDG_RUNTIME_DIR:-/tmp}/yuyu-${UID}-${ROS_DOMAIN_ID:-23}.lock" ]]; then
  exec 8>"${XDG_RUNTIME_DIR:-/tmp}/yuyu-${UID}-${ROS_DOMAIN_ID:-23}.lock"
  if ! flock -n 8; then
    echo '请先在主程序终端按 Ctrl+C 关闭旧场景，再运行更新。' >&2
    exit 1
  fi
fi
if [[ "$(realpath -m "$target_project")" == "$new_project" ]]; then
  echo '当前目录已经是目标项目。请从下载目录中的新版文件夹执行更新，以便保留旧版备份。' >&2
  exit 1
fi
case "$(realpath -m "$target_project")" in
  /|/home|"$HOME"|/tmp|/workspace)
    echo '目标必须是独立的禹禹项目目录，不能是系统目录或用户主目录。' >&2; exit 1 ;;
esac
if [[ -L "$target_project" ]] || [[ "$new_project/" == "$(realpath -m "$target_project")/"* ]]; then
  echo '请将新版解压到独立下载目录；目标不能是符号链接或包含新版的父目录。' >&2
  exit 1
fi
if [[ -d "$target_project" && ! -d "$target_project/src/yuyu_bringup" ]]; then
  echo '目标目录不是已识别的禹禹工程，请检查目标路径。' >&2
  exit 1
fi
if [[ ! -f "$new_project/src/yuyu_bringup/yuyu_bringup/behavior.py" ]]; then
  echo '更新文件不完整，请重新解压完整项目包。' >&2
  exit 1
fi
backup_dir="${YUYU_BACKUP_ROOT:-$HOME/yuyu_backups}/$(date +%Y%m%d-%H%M%S)-$$"
mkdir -p "$backup_dir"
if [[ -e "$target_project" ]]; then
  mv "$target_project" "$backup_dir/project"
fi
mkdir -p "$target_project"
rollback() {
  mv "$target_project" "$backup_dir/failed-update"
  if [[ -d "$backup_dir/project" ]]; then mv "$backup_dir/project" "$target_project"; fi
  echo "更新未完成，已恢复原项目。失败版本及日志保留在：$backup_dir" >&2
}
trap rollback ERR
# No old build products, virtual environments or recordings are carried into source.
tar -C "$new_project" --exclude=.git --exclude=build --exclude=install --exclude=log \
  --exclude=.venv --exclude=__pycache__ -cf - . | tar -C "$target_project" -xf -
cd "$target_project"
bash tools/install_dependencies.sh
source tools/env.sh
colcon build --symlink-install
trap - ERR
printf '更新完成。旧项目备份：%s\n' "$backup_dir/project"
printf '启动：cd %q && bash tools/start.sh\n' "$target_project"
echo '设置与本地录音位于 ~/.local/share/yuyu，更新不会删除。旧工程中的额外自改文件仍在备份中。'
