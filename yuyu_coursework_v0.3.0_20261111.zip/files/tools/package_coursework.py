#!/usr/bin/env python3
"""Package a hash-checked offline update against the installed study-v1 source."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parents[1]
BASE='895719a'
NAME='yuyu_coursework_v0.3.0_20261111.zip'


def git(*args,check=True):
    return subprocess.run(['git',*args],cwd=ROOT,check=check,stdout=subprocess.PIPE,stderr=subprocess.PIPE)


def sha(data):return hashlib.sha256(data).hexdigest()


def package(output):
    names=set(git('diff','--name-only',BASE).stdout.decode().splitlines())
    names.update(git('ls-files','--others','--exclude-standard').stdout.decode().splitlines())
    names=sorted(n for n in names if n.split('/')[0] in ('src','tools','tests','docs','README.md'))
    manifest={'version':'coursework-0.3.0-20261111','base_commit':git('rev-parse',BASE).stdout.decode().strip(),
              'required_files':['src/yuyu_description/meshes/study/room.dae'],'files':[]}
    for name in names:
        old=git('show',BASE+':'+name,check=False)
        manifest['files'].append({'path':name,'sha256':sha((ROOT/name).read_bytes()),
                                  'before_sha256':sha(old.stdout) if old.returncode==0 else None})
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        archive.write(ROOT/'tools/install_coursework_update.py','install_update.py')
        archive.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
        archive.write(ROOT/'docs/09_coursework_update.md','README.md')
        for name in names:archive.write(ROOT/name,'files/'+name)
    checksum=sha(output.read_bytes())
    output.with_suffix('.zip.sha256').write_text(checksum+'  '+output.name+'\n')
    return {'file':str(output),'bytes':output.stat().st_size,'sha256':checksum,'payload_files':len(names)}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,default=ROOT.parent/NAME)
    args=parser.parse_args();print(json.dumps(package(args.output),indent=2))


if __name__=='__main__':main()
