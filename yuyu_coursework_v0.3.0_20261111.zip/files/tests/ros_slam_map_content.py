#!/usr/bin/env python3
"""Verify changing SLAM map content during a real Nav2 goal; start from a non-return pose."""
import rclpy,time,json,hashlib
from pathlib import Path
from rclpy.node import Node
from nav_msgs.msg import OccupancyGrid
from std_msgs.msg import String
from yuyu_bringup.ros_utils import LATCH


def main():
    rclpy.init();n=Node('live_map_content_check');maps=[];state=[''];states=[]
    def m(msg):maps.append((time.monotonic(),hashlib.sha256(bytes(v+1 for v in msg.data)).hexdigest(),sum(v>=65 for v in msg.data)))
    n.create_subscription(OccupancyGrid,'/map',m,LATCH)
    n.create_subscription(String,'/behavior_state',lambda msg:(state.__setitem__(0,msg.data),states.append(msg.data)),LATCH)
    p=n.create_publisher(String,'/command_text',10)
    end=time.monotonic()+3
    while time.monotonic()<end:rclpy.spin_once(n,timeout_sec=.05)
    p.publish(String(data='回去'));start=time.monotonic();end=start+65
    while time.monotonic()<end:
     rclpy.spin_once(n,timeout_sec=.05)
     if 'NAVIGATING' in states and state[0]=='INTERACTING':break
    assert state[0]=='INTERACTING',states
    updates=[row for row in maps if row[0]>=start];unique={row[1] for row in updates}
    assert len(unique)>1,updates
    result={'maps_during_navigation':len(updates),'distinct_map_contents':len(unique),'occupied_cells_start':updates[0][2],'occupied_cells_end':updates[-1][2]}
    print('PASS:',json.dumps(result),flush=True)
    open(Path(__file__).resolve().parents[1]/'docs/coursework-map-content-results.json','w').write(json.dumps(result,indent=2)+'\n')
    p.publish(String(data='停下'));rclpy.spin_once(n,timeout_sec=.1);n.destroy_node();rclpy.shutdown()


if __name__=='__main__':main()
