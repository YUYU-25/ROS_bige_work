#!/usr/bin/env python3
"""Real Gazebo regression: live SLAM, Nav2, distance and camera-triggered stop.

Truth/target placement are test-only services; product controllers never use them.
Run with coursework.launch.py already running, from a fresh simulation.
"""
import json
import math
from pathlib import Path
import time
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from nav_msgs.msg import OccupancyGrid, Odometry
from sensor_msgs.msg import Image
from gazebo_msgs.srv import GetEntityState, SpawnEntity, DeleteEntity
from tf2_ros import Buffer, TransformListener
from rclpy.time import Time
from PIL import Image as PILImage
from yuyu_bringup.ros_utils import LATCH

ROOT=Path(__file__).resolve().parents[1]

def main():
    rclpy.init();node=Node('coursework_physical_validation')
    values, states, maps, cmds, distance_reports = {}, [], [], [], []
    tf=Buffer();listener=TransformListener(tf,node)
    def status(key,m):values[key]=json.loads(m.data)
    for key,topic in [('safety','/safety_status'),('vision','/vision_status')]:
        node.create_subscription(String,topic,lambda m,k=key:status(k,m),LATCH if key=='vision' else 10)
    def distance(m):
        values['distance']=json.loads(m.data);distance_reports.append(values['distance'])
    node.create_subscription(String,'/distance_status',distance,LATCH)
    node.create_subscription(String,'/behavior_state',lambda m:(values.update(state=m.data),states.append(m.data)),LATCH)
    node.create_subscription(OccupancyGrid,'/map',lambda m:maps.append(m),LATCH)
    node.create_subscription(Twist,'/cmd_vel',lambda m:cmds.append((time.monotonic(),m.linear.x,m.angular.z)),10)
    node.create_subscription(Odometry,'/odom',lambda m:values.update(odom=m),qos_profile_sensor_data)
    node.create_subscription(Image,'/camera/image_raw',lambda m:values.update(camera=m),qos_profile_sensor_data)
    text=node.create_publisher(String,'/command_text',10)
    dist=node.create_publisher(String,'/distance_request',10)
    vision=node.create_publisher(String,'/vision_request',10)
    manual=node.create_publisher(Twist,'/teleop_cmd_vel',10)
    truth=node.create_client(GetEntityState,'/gazebo/get_entity_state')
    spawn=node.create_client(SpawnEntity,'/spawn_entity');delete=node.create_client(DeleteEntity,'/delete_entity')
    report={'checks':[],'limits':'independent cloud simulation; user VMware still requires installation'}
    def pump(seconds):
        until=time.monotonic()+seconds
        while time.monotonic()<until:rclpy.spin_once(node,timeout_sec=.02)
    def wait(predicate,seconds,description):
        until=time.monotonic()+seconds
        while time.monotonic()<until:
            pump(.05)
            if predicate():return
        raise AssertionError(description+' '+str(values.get('safety'))+' '+str(values.get('distance')))
    def service(client,request):
        assert client.wait_for_service(timeout_sec=15)
        future=client.call_async(request);wait(future.done,20,'service timeout');result=future.result()
        assert result.success,result.status_message
        return result
    def position():
        request=GetEntityState.Request();request.name='yuyu';return service(truth,request).state.pose
    def check_map_error():
        p=position();q=p.orientation
        yaw=math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))
        t=tf.lookup_transform('map','base_footprint',Time()).transform
        mq=t.rotation;myaw=math.atan2(2*(mq.w*mq.z+mq.x*mq.y),1-2*(mq.y*mq.y+mq.z*mq.z))
        error=math.hypot(p.position.x-t.translation.x,p.position.y-t.translation.y)
        a=abs(math.atan2(math.sin(yaw-myaw),math.cos(yaw-myaw)))
        print('POSE ERROR',error,a,flush=True)
        assert error<.04 and a<.18,(error,a)
        return error,a
    def move(amount,identity):
        before=position();dist.publish(String(data=json.dumps({'id':identity,'distance_m':amount})))
        wait(lambda:values.get('distance',{}).get('id')==identity and values['distance']['state']=='finished',30,'distance incomplete')
        after=position();actual=math.hypot(after.position.x-before.position.x,after.position.y-before.position.y)
        assert values['distance']['success'] and abs(actual-abs(amount))<.015,(actual,amount,values['distance'])
        pump(.5);assert all(abs(v)<.002 for _,v,w in cmds[-5:])
        check_map_error();report['checks'].append({'distance_command_m':amount,'actual_m':actual})
    def navigate(command,goal):
        states.clear();count=len(maps);text.publish(String(data=command))
        wait(lambda:'NAVIGATING' in states and values.get('state')=='INTERACTING',100,'Nav2 did not arrive')
        p=position();error=math.hypot(p.position.x-goal[0],p.position.y-goal[1])
        assert error<.06,(error,p);check_map_error()
        report['checks'].append({'navigation':command,'goal_error_m':error,'maps_during_navigation':len(maps)-count})
    try:
        wait(lambda:values.get('safety',{}).get('ready') and len(maps)>=3 and 'camera' in values,60,'startup not ready')
        print('READY map cells',len(maps[-1].data),'maps',len(maps),flush=True)
        check_map_error();move(.08,'forward-8cm');move(-.08,'backward-8cm')
        assert sum(v>=65 for v in maps[-1].data)>20, 'no occupied cells after actual movement'
        navigate('回去',(-.18,.08));navigate('过来',(0.,0.))
        # Face an uncluttered direction using actual teleop and odometry feedback.
        target_yaw=math.pi/2
        until=time.monotonic()+12
        while time.monotonic()<until:
            p=position();q=p.orientation;yaw=math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))
            error=math.atan2(math.sin(target_yaw-yaw),math.cos(target_yaw-yaw))
            if abs(error)<.08:break
            msg=Twist();msg.angular.z=max(-.4,min(.4,error));manual.publish(msg);pump(.08)
        manual.publish(Twist());pump(.5)
        vision.publish(String(data=json.dumps({'enabled':True})))
        wait(lambda:values.get('vision',{}).get('enabled') and values['vision']['ready'],8,'camera not clear')
        p=position();q=p.orientation;yaw=math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))
        dist.publish(String(data=json.dumps({'id':'camera-interrupted','distance_m':.10})))
        wait(lambda:values.get('state')=='MOVING',3,'distance did not start for vision test')
        request=SpawnEntity.Request();request.name='coursework_red_marker'
        request.xml='<sdf version="1.6"><model name="red_marker"><static>true</static><link name="card"><visual name="red"><geometry><box><size>.035 .035 .09</size></box></geometry><material><ambient>1 0 0 1</ambient><diffuse>1 0 0 1</diffuse></material></visual></link></model></sdf>'
        request.initial_pose.position.x=p.position.x+.22*math.cos(yaw)
        request.initial_pose.position.y=p.position.y+.22*math.sin(yaw)
        request.initial_pose.position.z=.88
        service(spawn,request)
        wait(lambda:values.get('vision',{}).get('blocked') and values.get('state')=='IDLE',5,'real camera did not stop robot')
        pump(.5);assert all(abs(v)<.002 and abs(w)<.002 for _,v,w in cmds[-5:])
        image=values['camera'];PILImage.frombytes('RGB',(image.width,image.height),bytes(image.data),'raw','RGB',image.step).save(str(ROOT/'docs/previews/coursework-camera-stop.png'))
        req=DeleteEntity.Request();req.name=request.name;service(delete,req)
        wait(lambda:values.get('vision',{}).get('ready'),5,'red removal not observed')
        pump(1);assert values.get('state')=='IDLE' and not values['distance']['success']
        report['checks'].append({'vision':'real rendered red marker stopped physical movement; no automatic resume'})
        report['map_updates']=len(maps);report['last_map_resolution']=maps[-1].info.resolution
        image=maps[-1];out=PILImage.new('L',(image.info.width,image.info.height));out.putdata([205 if v<0 else round(254*(100-v)/100) for v in image.data]);out.transpose(PILImage.FLIP_TOP_BOTTOM).save(str(ROOT/'docs/previews/coursework-slam-map.png'))
        print('PASS',json.dumps(report,ensure_ascii=False),flush=True)
        (ROOT/'docs/coursework-physical-results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
    finally:
        text.publish(String(data='停下'));vision.publish(String(data='{"enabled":false}'));manual.publish(Twist());pump(.4)
        node.destroy_node();rclpy.shutdown()


if __name__=='__main__':main()
