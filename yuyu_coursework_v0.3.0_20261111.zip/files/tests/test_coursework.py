"""Coursework gaps: actual pixel perception, odometry distance and safety cancellation."""
import math
from pathlib import Path
import sys
import tempfile
import unittest
from PIL import Image, ImageDraw
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src/yuyu_bringup'))
from yuyu_bringup.vision import red_region, VisionGate
from yuyu_bringup.behavior import TaskCoordinator
from yuyu_bringup.core import CLIFF_NAMES
from yuyu_bringup.panel import PanelApplication
from yuyu_bringup.map_display import occupancy_rectangles


class PerceptionTests(unittest.TestCase):
    def test_map_display_preserves_each_measured_cell_and_axis(self):
        values=[-1,0,0,100, 0,100,50,-1, 100,100,0,0]
        rectangles=occupancy_rectangles(values,4,3)
        cells={}
        for x0,y0,x1,y1,color in rectangles:
            for y in range(y0,y1):
                for x in range(x0,x1):
                    self.assertNotIn((x,y),cells)
                    cells[(x,y)]=color[0]
        self.assertEqual(len(cells),12)
        self.assertEqual([cells[(i%4,i//4)] for i in range(12)],
                         [185,245,245,35,245,35,135,185,35,35,245,245])
        with self.assertRaises(ValueError):occupancy_rectangles(values,4,4)

    def test_pixel_region_noise_stride_and_channel_order(self):
        image=Image.new('RGB',(160,120),'white');draw=ImageDraw.Draw(image)
        draw.rectangle((45,25,110,90),fill=(180,15,20))
        raw=b''.join(image.tobytes()[i*480:(i+1)*480]+b'PAD!' for i in range(120))
        result=red_region(raw,160,120,484)
        self.assertTrue(result['detected']);self.assertGreater(result['red_ratio'],.20)
        bgr=image.tobytes('raw','BGR')
        self.assertAlmostEqual(red_region(bgr,160,120,480,'bgr8')['red_ratio'],result['red_ratio'],places=2)
        image=Image.new('RGB',(160,120),'blue');draw=ImageDraw.Draw(image)
        for i in range(0,160,5):draw.point((i,40),fill='red')
        self.assertFalse(red_region(image.tobytes(),160,120,480)['detected'])
        with self.assertRaises(ValueError):red_region(raw[:40],160,120,484)

    def test_debounce_freshness_and_reenable(self):
        gate=VisionGate();gate.enable(True)
        self.assertFalse(gate.status(1)['ready'])
        yes={'detected':True,'red_ratio':.1,'bbox':[.1,.1,.3,.3]}
        for t in (1,1.1):gate.observe(yes,t)
        self.assertFalse(gate.blocked)
        gate.observe(yes,1.2);self.assertTrue(gate.blocked)
        no={'detected':False,'red_ratio':0.,'bbox':None}
        for t in (1.3,1.4,1.5,1.6,1.7):gate.observe(no,t)
        self.assertTrue(gate.status(1.7)['ready'])
        self.assertFalse(gate.status(2.6)['ready'])
        gate.enable(False);self.assertTrue(gate.status(3)['ready'])
        gate.enable(True);self.assertFalse(gate.status(3)['ready'])
        gate.observe(yes,3);gate.observe(yes,5);gate.observe(yes,5.1)
        self.assertFalse(gate.blocked)


class DistanceTests(unittest.TestCase):
    def setUp(self):
        self.now,self.events=100.,[]
        self.task=TaskCoordinator(lambda k,v:self.events.append((k,v)),now=lambda:self.now)
        self.feedback(0.)

    def feedback(self,x,y=0,yaw=0,**edges):
        self.task.odom,self.task.odom_at=(x,y,yaw),self.now
        self.task.set_safety({'ready':True,'pose':(x,y,yaw),'edges':{**dict.fromkeys(CLIFF_NAMES,False),**edges}})

    def emitted(self,key):return [v for k,v in self.events if k==key]

    def test_forward_backward_finish_from_feedback_not_elapsed_time(self):
        for sign in (1,-1):
            self.feedback(0);self.task.move_distance(sign*.08,'move'+str(sign));self.task.tick()
            self.assertEqual(self.task.state,'MOVING')
            self.assertGreater(sign*self.emitted('velocity')[-1][0],0)
            self.now+=.1;self.feedback(sign*.035);self.task.tick()
            self.assertEqual(self.task.state,'MOVING')
            self.now+=.1;self.feedback(sign*.079);self.task.tick()
            self.assertEqual(self.task.state,'IDLE')
            self.assertTrue(self.emitted('distance_status')[-1]['success'])
            self.assertEqual(self.emitted('velocity')[-1],(0.,0.))

    def test_duplicate_manual_stop_and_blocked_motion(self):
        self.task.move_distance(.1,'same');gen=self.task.generation
        self.task.move_distance(.1,'same');self.assertEqual(gen,self.task.generation)
        self.task.manual_override();self.assertEqual(self.task.state,'IDLE')
        self.task.move_distance(.1,'stalled')
        self.now+=3.2;self.feedback(0);self.task.tick()
        self.assertEqual(self.task.state,'IDLE');self.assertFalse(self.emitted('distance_status')[-1]['success'])
        self.task.move_distance(.1,'stop');self.task.request('stop');self.now+=.1;self.feedback(.03);self.task.tick()
        self.assertEqual(self.task.state,'IDLE')

    def test_vision_stop_prevents_restart_until_clear_and_new_command(self):
        self.task.move_distance(.1,'move')
        self.task.set_vision({'enabled':True,'blocked':True,'ready':False})
        self.assertEqual(self.task.state,'IDLE');self.assertTrue(self.emitted('hold')[-1])
        self.task.move_distance(.1,'blocked');self.assertEqual(self.emitted('distance_status')[-1]['state'],'rejected')
        self.task.set_vision({'enabled':True,'blocked':False,'ready':True})
        self.task.tick();self.assertEqual(self.task.state,'IDLE')
        self.task.move_distance(.08,'new');self.assertEqual(self.task.state,'MOVING')
        self.now+=.9;self.feedback(.01);self.task.tick();self.assertEqual(self.task.state,'IDLE')

    def test_edge_and_stale_odom_override_distance(self):
        self.task.move_distance(.1,'edge');self.feedback(.02,front_left=True)
        self.assertNotEqual(self.task.state,'MOVING')
        self.assertFalse(self.emitted('distance_status')[-1]['success'])
        self.now+=1.;self.feedback(0);self.task.odom_at=self.now-1
        self.task.move_distance(.1,'stale');self.assertEqual(self.emitted('distance_status')[-1]['state'],'rejected')


class CourseworkIntegrationContracts(unittest.TestCase):
    def test_online_map_reaches_both_costmaps(self):
        d=yaml.safe_load((ROOT/'src/yuyu_bringup/config/nav2_slam.yaml').read_text())
        for scope in ['global_costmap','local_costmap']:
            p=d[scope][scope]['ros__parameters']
            self.assertIn('slam_layer',p['plugins']);self.assertEqual(p['slam_layer']['map_topic'],'/map')
            self.assertTrue(p['rolling_window']);self.assertTrue(p['desk_layer']['use_maximum'])

    def test_api_rejects_invalid_distance_and_dispatches_perception(self):
        with tempfile.TemporaryDirectory() as root:
            calls=[];app=PanelApplication(lambda *v:calls.append(v),root)
            for v in [0, .4, float('nan'), float('inf')]:
                with self.assertRaises(ValueError):app.handle('/api/distance',{'distance_m':v})
            app.handle('/api/distance',{'distance_m':-.08,'id':'a'})
            self.assertEqual(calls[-1],('distance',{'distance_m':-.08,'id':'a'}))
            with self.assertRaises(ValueError):app.handle('/api/vision',{'enabled':'true'})
            app.handle('/api/vision',{'enabled':True});self.assertEqual(calls[-1],('vision',{'enabled':True}))


if __name__=='__main__':unittest.main()
