"""Course demonstration: online SLAM + Nav2 + camera/range motion control."""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
    gz = get_package_share_directory('yuyu_gazebo')
    bringup = get_package_share_directory('yuyu_bringup')
    desc = get_package_share_directory('yuyu_description')
    defaults = {'gui': 'true', 'rviz': 'true', 'keyboard': 'true', 'audio': 'true',
                'ui': 'true', 'open_browser': 'true', 'panel_port': '8765'}
    return LaunchDescription([
        *[DeclareLaunchArgument(k, default_value=v) for k, v in defaults.items()],
        IncludeLaunchDescription(PythonLaunchDescriptionSource(os.path.join(gz, 'launch/demo_all.launch.py')),
            launch_arguments={**{k: LaunchConfiguration(k) for k in defaults}, 'use_slam': 'true',
                'world': os.path.join(gz, 'worlds/study_slam.world'),
                'nav2_params': os.path.join(bringup, 'config/nav2_slam.yaml'),
                'rviz_config': os.path.join(desc, 'rviz/yuyu_coursework.rviz')}.items())])
