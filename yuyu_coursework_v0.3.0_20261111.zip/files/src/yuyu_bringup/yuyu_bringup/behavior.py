"""Task state machine. ROS adapters execute the emitted effects asynchronously."""
import math
import time
from .core import (arrival_text, dance_candidates, dance_space, point_clear,
                   wrap_angle)


class TaskCoordinator:
    def __init__(self, emit, now=time.monotonic):
        self.emit, self.now = emit, now
        self.state, self.command, self.generation = 'IDLE', None, 0
        self.pose, self.pose_at = (0.0, 0.0, 0.0), -math.inf
        self.odom, self.odom_at = self.pose, -math.inf
        self.safety, self.safety_at = {}, -math.inf
        self.entered = self.now()
        self.edge_episode = self.edge_suppressed = False
        self.clear_since = None
        self.quiet, self.sleep_sent = False, False
        self.pending_spots = []
        self.planning_target = None
        self.dance_rechecks = 0
        self.stage, self.direction, self.target_distance = '', -1, 0.16
        self.speed = 0.05
        self.last_note, self.last_note_at = '', -math.inf
        self.last_progress, self.progress_value = self.now(), 0.0
        self.start_pose = self.pose
        self.vision = {'enabled': False}
        self.vision_at, self.vision_episode = -math.inf, False
        self.distance_ids = {}
        self.distance_result = None
        self.set_state('IDLE', force=True)

    def set_state(self, state, detail='', force=False):
        if state != self.state or force:
            self.state, self.entered, self.sleep_sent = state, self.now(), False
            self.emit('state', state)
        mode = {'NAVIGATING': 'nav', 'REPOSITIONING': 'nav',
                'DANCING': 'dance', 'FLEEING': 'behavior', 'MOVING': 'behavior'}.get(state, 'idle')
        self.emit('mode', mode)
        self.emit('status', {'state': state, 'command': self.command,
                             'detail': detail, 'generation': self.generation})

    def say(self, text):
        if text == self.last_note and self.now()-self.last_note_at < 2:
            return
        self.last_note, self.last_note_at = text, self.now()
        self.emit('speech', text)

    def stop(self, user=False):
        if self.state == 'MOVING' and self.distance_result.get('state') != 'finished':
            self.distance_result = {**self.distance_result, 'state': 'cancelled', 'success': False}
            self.emit('distance_status', self.distance_result)
        self.generation += 1
        self.emit('cancel_navigation', None)
        self.emit('cancel_plan', None)
        self.emit('dance_request', {'action': 'stop', 'id': str(self.generation)})
        self.emit('velocity', (0.0, 0.0))
        self.pending_spots = []
        self.planning_target = None
        self.command = None
        if user:
            self.emit('hold', True)
            if any(self.safety.get('edges', {}).values()):
                self.edge_suppressed = True
        self.set_state('IDLE', '已停车' if user else '')

    def manual_override(self):
        if self.state != 'IDLE':
            self.stop()
            self.set_state('IDLE', '正在手动控制')
        self.emit('hold', False)

    def set_emotion(self, emotion):
        if emotion == 'silent':
            self.quiet = True
            self.stop(user=True)
        elif emotion == 'none':
            self.quiet = False
        if self.state != 'DANCING':
            self.emit('face', {'annoyed': 'care', 'tired': 'sleepy',
                              'silent': 'silent', 'none': 'happy'}.get(emotion, 'happy'))

    def set_safety(self, value):
        self.safety, self.safety_at = value, self.now()
        valid = (value.get('ready', False) and len(value.get('pose', ())) == 3
                 and all(math.isfinite(v) for v in value['pose']))
        if valid:
            self.pose, self.pose_at = tuple(value['pose']), self.now()
        if not valid:
            if self.state != 'IDLE':
                self.stop()
                self.say('定位或传感器暂时没有就绪，我先停稳。')
            return
        edges = value.get('edges', {})
        danger = any(edges.values())
        if not danger:
            if self.clear_since is None:
                self.clear_since = self.now()
            if self.now()-self.clear_since >= 0.35:
                self.edge_episode = self.edge_suppressed = False
            return
        self.clear_since = None
        if self.edge_suppressed:
            return
        if self.state == 'FLEEING' and self.stage in ('retreat_edge', 'turn'):
            return
        if self.edge_episode:
            return
        self.edge_episode = True
        self.stop()
        front = edges.get('front_left') or edges.get('front_right')
        rear = edges.get('rear_left') or edges.get('rear_right')
        if bool(front) == bool(rear):
            self.edge_suppressed = True
            self.say('前后都靠近桌沿，我先保持不动，请帮我移回安全位置。')
            return
        self.emit('hold', False)
        self.direction, self.target_distance = (-1 if front else 1), 0.06
        self.stage, self.start_pose = 'retreat_edge', self.odom
        self.last_progress, self.progress_value = self.now(), 0.0
        self.set_state('FLEEING', '正在向桌内退让')

    def ready(self):
        return (self.safety.get('ready', False)
                and self.now()-self.safety_at < 0.7
                and self.now()-self.pose_at < 0.7
                and (not self.vision.get('enabled') or
                     self.now()-self.vision_at < 0.8 and self.vision.get('ready', False)))

    def set_vision(self, value):
        self.vision, self.vision_at = value, self.now()
        blocked = value.get('enabled') and not value.get('ready', False)
        if blocked and self.state != 'IDLE': self.stop(user=True)
        if value.get('enabled') and value.get('blocked'):
            if not self.vision_episode:
                self.stop(user=True)
                self.emit('face', 'care')
                self.say('我看见前面的红色物体了，先停下来，等你确认后再走。')
            self.vision_episode = True
        else:
            self.vision_episode = False

    def move_distance(self, distance, identity):
        if identity in self.distance_ids: return
        if not math.isfinite(distance) or not 0.02 <= abs(distance) <= 0.30:
            raise ValueError('行驶距离为正负2～30厘米')
        self.distance_ids[identity] = distance
        while len(self.distance_ids) > 80: self.distance_ids.pop(next(iter(self.distance_ids)))
        if (not self.ready() or self.now()-self.odom_at > 0.7 or
                not all(math.isfinite(v) for v in self.odom) or any(self.safety.get('edges', {}).values())):
            self.emit('distance_status', {'id': identity, 'state': 'rejected', 'success': False,
                                         'detail': '定位、视觉或传感器未就绪，保持停车'})
            return
        self.stop()
        self.command, self.target_distance = 'distance', abs(distance)
        self.direction, self.start_pose = (1 if distance > 0 else -1), self.odom
        self.last_progress, self.progress_value = self.now(), 0.0
        self.distance_result = {'id': identity, 'target_m': distance, 'travelled_m': 0.0,
                                'state': 'moving', 'success': False}
        self.emit('hold', False)
        self.set_state('MOVING', '正在按设定距离行驶')
        self.emit('distance_status', self.distance_result)

    def distance_tick(self):
        now = self.now()
        dx, dy = self.odom[0]-self.start_pose[0], self.odom[1]-self.start_pose[1]
        yaw = self.start_pose[2]
        moved = self.direction*(dx*math.cos(yaw)+dy*math.sin(yaw))
        self.distance_result['travelled_m'] = round(self.direction*moved, 4)
        remaining = self.target_distance-moved
        if remaining <= 0.003:
            result = {**self.distance_result, 'state': 'finished', 'success': True}
            self.distance_result = result
            self.stop()
            self.distance_result = result
            self.emit('distance_status', result)
            self.say('已经走完设定的距离，我停好啦。')
            return
        if moved-self.progress_value > 0.002:
            self.last_progress, self.progress_value = now, moved
        if (now-self.odom_at > 0.7 or now-self.last_progress > 3.0 or
                now-self.entered > self.target_distance/max(0.01, self.speed)*3+8 or
                abs(dx*math.sin(yaw)-dy*math.cos(yaw)) > 0.025 or
                abs(wrap_angle(self.odom[2]-yaw)) > 0.35):
            self.stop(user=True)
            self.say('前方受阻或运动反馈异常，我先停在这里。')
            return
        v = self.direction*min(self.speed, max(0.006, remaining*1.2))
        w = max(-0.25, min(0.25, 2.0*wrap_angle(yaw-self.odom[2])))
        self.emit('velocity', (v, w))
        self.emit('distance_status', dict(self.distance_result))

    def request(self, command):
        if command == 'stop':
            self.stop(user=True)
            return
        if command == self.command and self.state in ('NAVIGATING', 'REPOSITIONING', 'PLANNING'):
            self.say(arrival_text(command, 'busy') if command != 'dance'
                     else '正在准备表演的位置，找到后就跳给你看。')
            return
        if command == 'dance' and self.state == 'DANCING':
            self.say('正在给你表演呢，小心心马上送到。')
            return
        if not self.ready():
            self.say('定位或传感器还在准备，我先停在这里。')
            return
        edges = self.safety.get('edges', {})
        if any(edges.values()):
            self.say('现在离桌沿太近，先回到安全位置再活动。')
            return
        if command not in ('come', 'return', 'dance', 'back'):
            return
        if command in ('come', 'return'):
            target = (0.0, 0.0) if command == 'come' else (-0.18, 0.08)
            if math.hypot(target[0]-self.pose[0], target[1]-self.pose[1]) <= 0.035:
                if self.state != 'IDLE':
                    self.stop()
                self.say(arrival_text(command, 'already'))
                return
        self.stop()
        self.command = command
        self.emit('hold', False)
        if command in ('come', 'return'):
            self.say('好，我来陪你。' if command == 'come' else '好，我回去等你。')
            self.navigate(target, 'NAVIGATING')
        elif command == 'dance':
            self.dance_rechecks = 0
            if dance_space(self.pose):
                self.start_dance()
            else:
                self.pending_spots = dance_candidates(self.pose)
                self.say('这里活动不开，我找个宽敞的位置，过去跳给你看。')
                self.plan_next()
        else:
            self.say('好，我往后退一点，给你留点空间。')
            self.direction, self.target_distance = -1, 0.16
            self.stage, self.start_pose = 'back', self.odom
            self.last_progress, self.progress_value = self.now(), 0.0
            self.set_state('FLEEING', '正在后退')

    def navigate(self, target, state):
        yaw = math.atan2(target[1]-self.pose[1], target[0]-self.pose[0])
        self.entered = self.now()
        self.set_state(state, '正在换表演位置' if state == 'REPOSITIONING' else '正在前往目标')
        self.emit('navigation', {'target': (*target, yaw), 'token': self.generation})

    def plan_next(self):
        if not self.pending_spots:
            self.stop()
            self.say('暂时没有找到可安全到达的表演位置，我先停在这里。')
            return
        target = self.pending_spots.pop(0)
        self.planning_target = target
        self.entered = self.now()
        self.set_state('PLANNING', '正在寻找可到达的表演位置')
        self.emit('path_request', {'target': target, 'token': self.generation})

    def path_result(self, token, target, points):
        if (token != self.generation or self.state != 'PLANNING'
                or tuple(target) != tuple(self.planning_target or ())):
            return
        # Validate segments as well as waypoints, and require the path to reach the candidate.
        valid = (points and math.dist(points[0], self.pose[:2]) < 0.05
                 and math.dist(points[-1], target) < 0.035
                 and all(point_clear(a[0]+(b[0]-a[0])*t/5, a[1]+(b[1]-a[1])*t/5)
                         for a, b in zip(points, points[1:]) for t in range(6)))
        if self.ready() and valid:
            self.navigate(target, 'REPOSITIONING')
        else:
            self.plan_next()

    def navigation_result(self, token, success):
        if token != self.generation or self.state not in ('NAVIGATING', 'REPOSITIONING'):
            return
        relocating = self.state == 'REPOSITIONING'
        if not success:
            if relocating:
                self.plan_next()
            else:
                self.stop()
                self.say('这次没能到达目标，我先停稳，等你下一条指令。')
            return
        if relocating:
            if self.ready() and dance_space(self.pose):
                self.say('位置找好啦，给你送一颗小心心。')
                self.start_dance()
            else:
                self.plan_next()
        else:
            text = arrival_text(self.command)
            self.set_state('INTERACTING', '已到达')
            self.emit('face', 'curious')
            self.say(text)

    def start_dance(self):
        self.set_state('DANCING', '正在开心摇摆')
        self.emit('face', 'dance')
        self.emit('dance_request', {'action': 'start', 'id': str(self.generation)})

    def dance_result(self, identity, success, reason=''):
        if identity != str(self.generation) or self.state != 'DANCING':
            return
        if not success and reason == 'space_changed':
            self.dance_rechecks += 1
            if self.dance_rechecks > 2:
                self.stop()
                self.say('实际可用空间一直不稳定，我先停稳，等位置合适再表演。')
                return
            self.pending_spots = self.pending_spots or dance_candidates(self.pose)
            self.say('这里比预计的挤一些，我再检查一个表演位置。')
            self.plan_next()
            return
        self.set_state('IDLE', '表演结束' if success else '表演已停止')
        self.emit('face', 'silent' if self.quiet else 'happy')
        if reason:
            self.say(reason)

    def failed_recovery(self, text):
        self.edge_suppressed = self.stage != 'back'
        self.stop()
        self.say(text)

    def tick(self):
        now = self.now()
        if self.state != 'IDLE' and not self.ready():
            self.stop()
            self.say('数据暂时没有跟上，我先停稳。')
            return
        if self.state == 'MOVING':
            self.distance_tick()
        elif self.state == 'FLEEING':
            if now-self.odom_at > 0.7 or now-self.entered > 25:
                self.failed_recovery('退让没有顺利完成，我先保持停车。')
                return
            moved = math.hypot(self.odom[0]-self.start_pose[0], self.odom[1]-self.start_pose[1])
            if self.stage in ('back', 'retreat_edge'):
                edges_clear = not any(self.safety.get('edges', {}).values())
                remaining = moved < self.target_distance or (self.stage == 'retreat_edge' and not edges_clear)
                if remaining:
                    if moved-self.progress_value > 0.002:
                        self.last_progress, self.progress_value = now, moved
                    if now-self.last_progress > 3 or (moved > 0.10 and self.stage == 'retreat_edge'):
                        self.failed_recovery('退让方向可能被挡住了，我先停在这里。')
                        return
                    self.emit('velocity', (self.direction*min(self.speed, 0.035), 0.0))
                elif self.stage == 'retreat_edge':
                    self.stage, self.start_pose = 'turn', self.odom
                    self.emit('velocity', (0.0, 0.0))
                else:
                    self.stop()
                    self.say('我退到这里啦，需要我时再叫我。')
            elif any(self.safety.get('edges', {}).values()):
                self.failed_recovery('仍然靠近桌沿，我先保持停车。')
            elif abs(wrap_angle(self.odom[2]-self.start_pose[2])) < math.pi/2-0.06:
                self.emit('velocity', (0.0, 0.55))
            else:
                self.stop()
        elif self.state in ('NAVIGATING', 'REPOSITIONING') and now-self.entered > 60:
            self.stop()
            self.say('这次走得太久了，我先停在这里。')
        elif self.state == 'PLANNING' and now-self.entered > 5:
            self.emit('cancel_plan', None)
            self.plan_next()
        elif self.state == 'INTERACTING' and now-self.entered > 4:
            self.set_state('IDLE')
        elif self.state == 'IDLE' and now-self.entered > 60 and not self.quiet and not self.sleep_sent:
            self.emit('face', 'sleepy')
            self.sleep_sent = True
