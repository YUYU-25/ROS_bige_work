"""Small RGB red-region detector; the decision uses camera pixels, never world poses."""
from PIL import Image


def red_region(data, width, height, step, encoding='rgb8'):
    if encoding not in ('rgb8', 'bgr8', 'rgba8', 'bgra8'):
        raise ValueError('摄像头图像编码不受支持')
    channels = 4 if 'a8' in encoding else 3
    if not (0 < width <= 1920 and 0 < height <= 1080 and
            width*channels <= step <= width*channels+8192 and len(data) >= height*step):
        raise ValueError('摄像头图像尺寸或步长无效')
    image = Image.frombytes('RGB' if channels == 3 else 'RGBA', (width, height),
                            bytes(data), 'raw', encoding[:-1].upper(), step).convert('RGB')
    image.thumbnail((80, 60))
    w, h = image.size
    mask = {i for i, (r, g, b) in enumerate(image.getdata())
            if r >= 70 and r >= g*1.55 and r >= b*1.55 and r-min(g, b) >= 40}
    largest = []
    while mask:
        seed = mask.pop()
        component, pending = [seed], [seed]
        while pending:
            i = pending.pop()
            neighbors = [i-w, i+w]
            if i % w: neighbors.append(i-1)
            if i % w < w-1: neighbors.append(i+1)
            for j in neighbors:
                if j in mask:
                    mask.remove(j); component.append(j); pending.append(j)
        if len(component) > len(largest): largest = component
    ratio = len(largest)/(w*h)
    bbox = None
    if largest:
        xs, ys = [i % w for i in largest], [i//w for i in largest]
        bbox = [min(xs)/w, min(ys)/h, (max(xs)+1)/w, (max(ys)+1)/h]
    return {'detected': ratio >= 0.015, 'red_ratio': round(ratio, 5), 'bbox': bbox}


class VisionGate:
    """Three positive frames engage; five negative frames clear. No auto-resume."""
    def __init__(self):
        self.enabled, self.blocked = False, False
        self.positive = self.negative = 0
        self.frame_at = None
        self.result = {'detected': False, 'red_ratio': 0.0, 'bbox': None}

    def enable(self, value):
        if not isinstance(value, bool): raise ValueError('视觉开关必须为布尔值')
        self.enabled, self.blocked = value, False
        self.positive = self.negative = 0
        self.frame_at = None  # Require new frames after enabling.

    def observe(self, result, now):
        if self.frame_at is None or now-self.frame_at > 0.8:
            self.positive = self.negative = 0
        self.result, self.frame_at = result, now
        self.positive = self.positive+1 if result['detected'] else 0
        self.negative = 0 if result['detected'] else self.negative+1
        if self.positive >= 3: self.blocked = True
        if self.negative >= 5: self.blocked = False

    def status(self, now):
        fresh = self.frame_at is not None and 0 <= now-self.frame_at <= 0.8
        ready = not self.enabled or fresh and not self.blocked
        detail = ('视觉停车未启用' if not self.enabled else
                  '等待新鲜摄像头图像，保持停车' if not fresh else
                  '识别到红色物体，已请求停车' if self.blocked else '视觉监测中，未发现红色目标')
        return {**self.result, 'enabled': self.enabled, 'blocked': self.blocked,
                'fresh': fresh, 'ready': bool(ready), 'detail': detail}
