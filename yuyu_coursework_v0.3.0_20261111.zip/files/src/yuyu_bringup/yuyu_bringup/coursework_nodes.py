"""Camera perception and measurable coursework diagnostics."""
import json
import time
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image
from nav_msgs.msg import OccupancyGrid
from visualization_msgs.msg import Marker
from std_msgs.msg import String
from .ros_utils import LATCH, string, wall_timer
from .vision import red_region, VisionGate
from .map_display import build_map_marker


class OnlineMapDisplay(Node):
    def __init__(self):
        super().__init__('online_map_display')
        self.pub = self.create_publisher(Marker, '/online_map_marker', LATCH)
        self.create_subscription(OccupancyGrid, '/map', self.map_image, LATCH)

    def map_image(self, msg):
        try: self.pub.publish(build_map_marker(msg))
        except ValueError as error: self.get_logger().warning(str(error))


class VisionControl(Node):
    def __init__(self):
        super().__init__('vision_control')
        self.gate = VisionGate()
        self.last_processed = -1.0
        self.pub = self.create_publisher(String, '/vision_status', LATCH)
        self.create_subscription(Image, '/camera/image_raw', self.image, qos_profile_sensor_data)
        self.create_subscription(String, '/vision_request', self.request, 10)
        wall_timer(self, 0.1, self.tick)

    def request(self, msg):
        try:
            value = json.loads(msg.data)
            self.gate.enable(value['enabled'])
            self.tick()
        except (ValueError, TypeError, KeyError):
            self.get_logger().warning('忽略无效视觉开关请求')

    def image(self, msg):
        now = time.monotonic()
        if not self.gate.enabled or now-self.last_processed < 0.09: return
        stamp = msg.header.stamp
        age = (self.get_clock().now().nanoseconds-stamp.sec*10**9-stamp.nanosec)/1e9
        if not -0.1 <= age <= 0.8: return
        try:
            result = red_region(msg.data, msg.width, msg.height, msg.step, msg.encoding)
            self.gate.observe(result, now)
            self.last_processed = now
            self.tick()
        except (ValueError, OSError):
            pass  # Invalid frames cannot refresh the camera watchdog.

    def tick(self):
        self.pub.publish(string(json.dumps(self.gate.status(time.monotonic()), ensure_ascii=False)))
