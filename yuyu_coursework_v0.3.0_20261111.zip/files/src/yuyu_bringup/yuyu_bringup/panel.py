"""Loopback-only control panel, persistent preferences, recording and voice library."""
import base64
import copy
import importlib.util
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import secrets
import shutil
import threading
import urllib.error
import urllib.parse
import urllib.request
from .settings import MAX_UPLOAD, SettingsStore, VoiceCatalog, local_engine_url


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError('本地音色服务不应跳转到其他地址')


class PanelState:
    def __init__(self):
        self.lock = threading.RLock()
        self.value = {'behavior': 'IDLE', 'task': {}, 'safety': {}, 'speech': {},
                      'motion': '', 'messages': [], 'acks': {}, 'connected': False}
        self.face = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=')
        self.camera = self.face

    def update(self, key, value):
        with self.lock:
            self.value[key] = value

    def message(self, role, text, identity=None):
        if not text:
            return
        with self.lock:
            rows = self.value['messages']
            if identity and any(row['id'] == identity for row in rows):
                return
            if rows and rows[-1]['role'] == role and rows[-1]['text'] == text:
                return
            rows.append({'role': role, 'text': str(text)[:500], 'id': identity or secrets.token_hex(8)})
            self.value['messages'] = rows[-60:]

    def snapshot(self):
        with self.lock:
            return copy.deepcopy(self.value)


class PanelApplication:
    def __init__(self, dispatch, root=None, state=None):
        self.store, self.catalog = SettingsStore(root), VoiceCatalog(root)
        self.state = state or PanelState()
        self.dispatch = dispatch
        self.token = secrets.token_urlsafe(32)

    def snapshot(self):
        return {**self.state.snapshot(), 'settings': self.store.get(), 'voices': self.catalog.list(),
                'capabilities': {'natural_voice': importlib.util.find_spec('edge_tts') is not None,
                  'offline_voice': bool(shutil.which('espeak-ng') or shutil.which('espeak')),
                  'audio_import': bool(shutil.which('ffmpeg')),
                  'asr_package': importlib.util.find_spec('vosk') is not None,
                  'asr_model': (Path(self.store.get()['asr_model_path']).expanduser()/'am/final.mdl').is_file()}}

    def handle(self, route, body):
        if route == '/api/distance':
            import math
            distance = float(body.get('distance_m', 0))
            if not math.isfinite(distance) or not 0.02 <= abs(distance) <= 0.30:
                raise ValueError('请输入2～30厘米的行驶距离')
            identity = str(body.get('id') or secrets.token_hex(16))
            if not identity or len(identity) > 80: raise ValueError('指令编号无效')
            self.dispatch('distance', {'distance_m': distance, 'id': identity})
            return {'submitted': True, 'id': identity}
        if route == '/api/vision':
            enabled = body.get('enabled')
            if not isinstance(enabled, bool): raise ValueError('视觉开关无效')
            self.dispatch('vision', {'enabled': enabled})
            return {'submitted': True}
        if route == '/api/command':
            text = body.get('text', '')
            if not isinstance(text, str) or not text.strip() or len(text) > 160:
                raise ValueError('请输入1～160字的指令')
            identity = str(body.get('id') or secrets.token_hex(16))
            if len(identity) > 80:
                raise ValueError('指令编号过长')
            self.dispatch('command', {'id': identity, 'text': text.strip()})
            self.state.message('user', text.strip(), identity)
            return {'submitted': True, 'id': identity}
        if route == '/api/settings':
            if 'voice_id' in body:
                self.catalog.get(body['voice_id'])
            value = self.store.update(body)
            self.dispatch('settings', value)
            return {'settings': value}
        if route == '/api/teleop':
            import math
            v, w = float(body.get('v', 0)), float(body.get('w', 0))
            if not math.isfinite(v) or not math.isfinite(w):
                raise ValueError('无效的移动指令')
            v = max(-self.store.get()['motion_speed'], min(self.store.get()['motion_speed'], v))
            self.dispatch('teleop', {'v': v, 'w': max(-0.75, min(0.75, w))})
            return {'submitted': True}
        if route == '/api/preview':
            profile = self.catalog.get(str(body.get('voice_id', '')))
            self.dispatch('speech', {'action': 'preview', 'voice_id': profile['id'],
                'id': secrets.token_hex(16), 'text': '你好呀，我是禹禹，今天也想陪你一会儿。'})
            return {'submitted': True}
        if route == '/api/voices/import':
            encoded = body.get('audio', '')
            if not isinstance(encoded, str) or len(encoded) > (MAX_UPLOAD*4//3+8):
                raise ValueError('录音过大，最多12MB')
            try:
                payload = base64.b64decode(encoded, validate=True)
            except ValueError as exc:
                raise ValueError('录音数据不完整，请重新选择文件') from exc
            suffix = Path(str(body.get('filename', 'voice.wav'))).suffix.lower()
            profile = self.catalog.add_reference(body.get('name', ''), body.get('prompt', ''), payload, suffix)
            return {'voice': profile, 'detail': '参考录音已保存在本地，连接本地音色引擎后可用于合成新句子。'}
        if route == '/api/voices/delete':
            identity = str(body.get('voice_id', ''))
            if self.catalog.get(identity)['kind'] != 'cosyvoice':
                raise ValueError('内置音色不能删除')
            self.catalog.delete(identity)
            if self.store.get()['voice_id'] == identity:
                value = self.store.update({'voice_id': 'xiaoxiao'})
                self.dispatch('settings', value)
            return {'deleted': True}
        if route == '/api/engine/check':
            url = local_engine_url(self.store.get()['local_voice_url'])+'/openapi.json'
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
            try:
                with opener.open(url, timeout=2) as response:
                    raw = response.read(1024*1024+1)
                if len(raw) > 1024*1024:
                    raise ValueError('服务响应过大')
                schema = json.loads(raw)
                if '/inference_zero_shot' not in schema.get('paths', {}):
                    raise ValueError('服务尚未提供参考音色合成接口')
            except (OSError, ValueError) as exc:
                raise ValueError('尚未连接到本地 CosyVoice 音色引擎：'+str(exc)[:100]) from exc
            return {'connected': True, 'detail': '本地音色引擎已连接，可以试听保存的参考音色。'}
        if route == '/api/asr':
            from .voice_input import recognize_upload
            text = recognize_upload(body, self.store.get(), self.store.root)
            return {'text': text}
        raise ValueError('没有找到这个操作')


def make_handler(application, web_root):
    web_root = Path(web_root)
    class Handler(BaseHTTPRequestHandler):
        protocol_version = 'HTTP/1.0'

        def log_message(self, *args):
            pass

        def allowed_host(self):
            try:
                host = urllib.parse.urlsplit('//'+self.headers.get('Host', '')).hostname
            except ValueError:
                return False
            return host in ('127.0.0.1', 'localhost', '::1')

        def send(self, status, payload, content_type='application/json; charset=utf-8'):
            if isinstance(payload, (dict, list)):
                payload = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode('utf-8')
            elif isinstance(payload, str):
                payload = payload.encode('utf-8')
            try:
                self.send_response(status)
                self.send_header('Content-Type', content_type)
                self.send_header('Content-Length', str(len(payload)))
                self.send_header('Cache-Control', 'no-store')
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.send_header('Content-Security-Policy', "default-src 'self'; img-src 'self' data:; media-src 'self' blob:; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'")
                self.end_headers()
                self.wfile.write(payload)
            except (ConnectionError, TimeoutError):
                # Navigation and cancelled image requests can close the socket mid-response.
                self.close_connection = True

        def do_GET(self):
            if not self.allowed_host():
                self.send(403, {'error': '仅支持本机访问'})
                return
            path = urllib.parse.urlsplit(self.path).path
            if path == '/api/state':
                self.send(200, application.snapshot())
            elif path == '/api/face.png':
                with application.state.lock:
                    value = application.state.face
                self.send(200, value, 'image/png')
            elif path == '/api/camera.png':
                with application.state.lock:
                    value = application.state.camera
                self.send(200, value, 'image/png')
            elif path.startswith('/api/reference/'):
                try:
                    identity = Path(path).name.removesuffix('.wav')
                    self.send(200, application.catalog.reference_path(identity).read_bytes(), 'audio/wav')
                except ValueError as exc:
                    self.send(404, {'error': str(exc)})
            elif path in ('/', '/app.js', '/styles.css'):
                file = web_root/({'/': 'index.html'}.get(path, path.lstrip('/')))
                try:
                    value = file.read_text(encoding='utf-8').replace('__YUYU_TOKEN__', application.token)
                    self.send(200, value, {'/': 'text/html; charset=utf-8', '/app.js': 'text/javascript; charset=utf-8',
                                           '/styles.css': 'text/css; charset=utf-8'}[path])
                except OSError:
                    self.send(404, {'error': '控制面板资源未安装，请重新编译项目'})
            else:
                self.send(404, {'error': '没有找到这个页面'})

        def do_POST(self):
            if not self.allowed_host() or not secrets.compare_digest(
                    self.headers.get('X-Yuyu-Token', ''), application.token):
                self.send(403, {'error': '页面验证已失效，请刷新后重试'})
                return
            origin = self.headers.get('Origin')
            if origin and origin != 'http://'+self.headers.get('Host'):
                self.send(403, {'error': '不支持跨站操作'})
                return
            try:
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 < length <= MAX_UPLOAD*4//3+8192:
                    self.send(413, {'error': '请求为空或文件过大'})
                    return
                if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                    raise ValueError('请使用JSON格式提交')
                self.connection.settimeout(10)
                body = json.loads(self.rfile.read(length))
                if not isinstance(body, dict):
                    raise ValueError('请求格式不正确')
                result = application.handle(urllib.parse.urlsplit(self.path).path, body)
                self.send(200, result)
            except (ValueError, TypeError, KeyError, OSError) as exc:
                self.send(400, {'error': str(exc)[:240]})
            except Exception:
                self.send(500, {'error': '操作未完成，请稍后重试并查看主程序状态'})
    return Handler


def start_server(application, web_root, port=8765):
    last = None
    for candidate in range(port, min(port+10, 65536)):
        try:
            server = ThreadingHTTPServer(('127.0.0.1', candidate), make_handler(application, web_root))
            server.daemon_threads = True
            threading.Thread(target=server.serve_forever, name='yuyu-panel-http', daemon=True).start()
            return server
        except OSError as exc:
            last = exc
    raise RuntimeError('控制面板端口不可用：'+str(last))
