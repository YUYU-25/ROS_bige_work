"""Render measured occupancy cells as rectangles, without indexed-texture GLSL."""
from PIL import Image
from .face_mesh import image_rectangles


def occupancy_rectangles(values, width, height):
    if width <= 0 or height <= 0 or width*height > 1000000 or len(values) != width*height:
        raise ValueError('在线地图尺寸无效或超出小桌面显示范围')
    image = Image.new('RGB', (width, height))
    image.putdata([(185,185,185) if v < 0 else (35,35,35) if v >= 65 else
                   (245,245,245) if v <= 25 else (135,135,135) for v in values])
    return image_rectangles(image)


def build_map_marker(grid):
    from geometry_msgs.msg import Point
    from std_msgs.msg import ColorRGBA
    from visualization_msgs.msg import Marker
    m = Marker()
    m.header.frame_id = grid.header.frame_id
    m.ns, m.id, m.type, m.action = 'online_slam_occupancy', 0, Marker.TRIANGLE_LIST, Marker.ADD
    m.pose = grid.info.origin
    m.scale.x = m.scale.y = m.scale.z = 1.0
    m.color = ColorRGBA(r=1.,g=1.,b=1.,a=1.)
    res = grid.info.resolution
    for left, bottom, right, top, rgb in occupancy_rectangles(grid.data,grid.info.width,grid.info.height):
        x0,y0,x1,y1 = left*res,bottom*res,right*res,top*res
        m.points.extend(Point(x=x,y=y,z=-.008) for x,y in
                        ((x0,y0),(x1,y0),(x1,y1),(x0,y0),(x1,y1),(x0,y1)))
        m.colors.extend([ColorRGBA(r=rgb[0]/255.,g=rgb[1]/255.,b=rgb[2]/255.,a=.85)]*6)
    return m
