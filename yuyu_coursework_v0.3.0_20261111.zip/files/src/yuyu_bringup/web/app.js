'use strict';
const $ = id => document.getElementById(id);
const token = document.querySelector('meta[name="csrf-token"]').content;
let snapshot = null, pending = null, renderedMessages = '', renderedVoices = '';
let manualTimer = null, recordSession = null, referenceFile = null, toastTimer = null;
const names = {IDLE:'陪伴中',NAVIGATING:'正在移动',REPOSITIONING:'正在换位置',PLANNING:'寻找空位',DANCING:'开心表演',FLEEING:'正在退让',INTERACTING:'在你身边',MOVING:'按距离行驶'};
function toast(text) { $('toast').textContent=text; $('toast').hidden=false; clearTimeout(toastTimer); toastTimer=setTimeout(()=>$('toast').hidden=true,4500); }
async function api(path, body={}) {
  const response=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-Yuyu-Token':token},body:JSON.stringify(body)});
  let value; try{value=await response.json();}catch{throw new Error('连接暂时中断，请稍后重试');}
  if(!response.ok)throw new Error(value.error||'这次操作没有完成'); return value;
}
async function command(text) {
  const request={id:crypto.randomUUID(),text}; pending={...request,at:Date.now(),retried:false};
  $('command-status').textContent='正在告诉禹禹……';
  try{await api('/api/command',request);}catch(error){pending=null;$('command-status').textContent=error.message;toast(error.message);}
}
function bubble(role,text) { const item=document.createElement('div');item.className='bubble '+role;item.textContent=text;return item; }
function voiceRow(voice) {
  const row=document.createElement('div');row.className='voice-row'+(voice.id===snapshot.settings.voice_id?' selected':'');
  const icon=document.createElement('span');icon.className='voice-dot';icon.textContent=voice.kind==='cosyvoice'?'♡':'♪';
  const info=document.createElement('div');info.className='voice-info';const title=document.createElement('b');title.textContent=voice.name;
  const note=document.createElement('small');note.textContent=voice.kind==='edge'?'联网自然音色':voice.kind==='offline'?'无需网络的备用合成':'本地参考录音 · 需连接音色引擎';info.append(title,note);row.append(icon,info);
  const preview=document.createElement('button');preview.textContent='试听';preview.addEventListener('click',()=>api('/api/preview',{voice_id:voice.id}).then(()=>toast('正在准备试听……')).catch(e=>toast(e.message)));
  const select=document.createElement('button');select.className='select-voice';select.textContent=voice.id===snapshot.settings.voice_id?'使用中':'选择';select.addEventListener('click',()=>settings({voice_id:voice.id}));row.append(preview,select);
  if(voice.kind==='cosyvoice'){
    const original=document.createElement('button');original.textContent='原录音';original.addEventListener('click',()=>{const audio=new Audio('/api/reference/'+encodeURIComponent(voice.id)+'.wav');audio.play().catch(e=>toast(e.message));});
    const remove=document.createElement('button');remove.textContent='删除';remove.addEventListener('click',async()=>{if(!confirm('删除本地音色“'+voice.name+'”？'))return;try{await api('/api/voices/delete',{voice_id:voice.id});renderedVoices='';await poll();toast('已删除');}catch(e){toast(e.message);}});row.append(original,remove);
  }return row;
}
function renderVoices(){
  const signature=JSON.stringify([snapshot.voices,snapshot.settings.voice_id]);if(signature===renderedVoices)return;renderedVoices=signature;
  $('builtin-voices').replaceChildren();$('custom-voices').replaceChildren();
  for(const voice of snapshot.voices)(voice.kind==='cosyvoice'?$('custom-voices'):$('builtin-voices')).append(voiceRow(voice));
  if(!$('custom-voices').children.length){const empty=document.createElement('p');empty.className='hint';empty.textContent='还没有保存参考音色，试着录一段喜欢的声音吧。';$('custom-voices').append(empty);}
}
function render(){
  const s=snapshot, ready=s.connected&&s.safety.ready;
  $('connection').textContent=s.connected?'已连接':'等待机器人';$('connection').classList.toggle('online',s.connected);
  $('behavior').textContent=names[s.behavior]||'准备中';$('task-detail').textContent=s.task.detail||(s.behavior==='IDLE'?'我在这里，随时叫我就好。':'正在认真完成你的心愿');
  $('safety-note').textContent=!s.connected?'正在等待机器人连接':!ready?'等待定位与传感器就绪':Object.values(s.safety.edges||{}).some(Boolean)?'靠近桌沿，正在优先停稳':'状态正常';
  const speech=s.speech||{}, speechNames={queued:'已收到，正在准备声音',generating:'正在生成声音……',playing:'正在说话',idle:'随时可以发指令',muted:'安静陪伴中',text_only:'文字陪伴中',error:'声音需要检查'};
  $('speech-detail').textContent=speech.detail||(speech.muted&&speech.state==='idle'?'安静陪伴中':speechNames[speech.state])||'声音准备中';$('mute-button').textContent=speech.muted?'恢复':'安静';
  for(const id of ['quick-volume','settings-volume'])if(document.activeElement!==$(id))$(id).value=s.settings.volume;
  $('volume-label').textContent=$('settings-volume-label').textContent=s.settings.volume+'%';
  if(document.activeElement!==$('speech-rate'))$('speech-rate').value=s.settings.speech_rate;$('rate-label').textContent=Number(s.settings.speech_rate).toFixed(2)+'×';
  for(const [id,key] of [['engine-url','local_voice_url'],['engine-rate','local_voice_sample_rate'],['asr-path','asr_model_path']])if(document.activeElement!==$(id))$(id).value=s.settings[key];
  document.querySelectorAll('[data-speed]').forEach(button=>button.classList.toggle('selected',Math.abs(Number(button.dataset.speed)-s.settings.motion_speed)<.001));
  $('asr-status').textContent=s.capabilities.asr_package&&s.capabilities.asr_model?'离线识别已准备好，可以使用主页面的语音按钮。':'需要安装离线识别模型；文字指令可以继续正常使用。';
  const signature=JSON.stringify(s.messages);if(signature!==renderedMessages){renderedMessages=signature;if(s.messages.length){$('messages').replaceChildren(...s.messages.map(m=>bubble(m.role,m.text)));$('messages').scrollTop=$('messages').scrollHeight;}}
  if(pending){const ack=s.acks[pending.id];if(ack){$('command-status').textContent=ack.detail||'禹禹已收到';pending=null;}else if(Date.now()-pending.at>2200&&!pending.retried){pending.retried=true;api('/api/command',{id:pending.id,text:pending.text}).catch(()=>{});}else if(Date.now()-pending.at>5000){$('command-status').textContent='暂未收到机器人确认，请检查连接后再试';pending=null;}}
  renderVoices();
  const vision=s.vision||{};if(document.activeElement!==$('vision-enabled'))$('vision-enabled').checked=!!vision.enabled;
  $('vision-status').textContent=vision.detail||'视觉停车未启用';
  const d=s.distance;if(d){const labels={moving:'正在行驶',finished:'已到达并停车',cancelled:'已中止，保持停车',rejected:'本次未启动'};$('distance-status').textContent=(labels[d.state]||d.state)+(Number.isFinite(d.travelled_m)?' · 已行驶 '+(Math.abs(d.travelled_m)*100).toFixed(1)+' 厘米':'')+(d.detail?' · '+d.detail:'');}
  const mapping=s.mapping;$('mapping-status').textContent=mapping?'在线地图已收到 '+mapping.updates+' 次更新，分辨率 '+(mapping.resolution*100).toFixed(1)+' 厘米':'';
}
let polling=false;async function poll(){if(polling)return;polling=true;try{const r=await fetch('/api/state',{cache:'no-store'});if(!r.ok)throw new Error();snapshot=await r.json();render();}catch{$('connection').textContent='连接暂时中断';$('connection').classList.remove('online');}finally{polling=false;}}
async function settings(change){try{await api('/api/settings',change);await poll();$('settings-status').textContent='已保存在本机';}catch(e){toast(e.message);$('settings-status').textContent=e.message;}}
let volumeTimer=null;function volume(value){value=Math.max(0,Math.min(100,Number(value)));$('volume-label').textContent=$('settings-volume-label').textContent=value+'%';$('quick-volume').value=$('settings-volume').value=value;clearTimeout(volumeTimer);volumeTimer=setTimeout(()=>settings({volume:value}),160);}
$('quick-volume').addEventListener('input',e=>volume(e.target.value));$('settings-volume').addEventListener('input',e=>volume(e.target.value));
$('volume-down').addEventListener('click',()=>volume(Number($('quick-volume').value)-10));$('volume-up').addEventListener('click',()=>volume(Number($('quick-volume').value)+10));
$('mute-button').addEventListener('click',()=>command(snapshot?.speech.muted?'恢复说话':'安静'));
$('speech-rate').addEventListener('change',e=>settings({speech_rate:Number(e.target.value)}));
document.querySelectorAll('[data-speed]').forEach(b=>b.addEventListener('click',()=>settings({motion_speed:Number(b.dataset.speed)})));
document.querySelectorAll('[data-command]').forEach(b=>b.addEventListener('click',()=>command(b.dataset.command)));
$('command-form').addEventListener('submit',e=>{e.preventDefault();const input=$('command');if(input.value.trim()){command(input.value.trim());input.value='';}});
$('open-settings').addEventListener('click',()=>$('settings-dialog').showModal());$('close-settings').addEventListener('click',()=>$('settings-dialog').close());
$('settings-dialog').addEventListener('close',()=>{if(recordSession?.kind==='reference'&&recordSession.recorder.state==='recording')recordSession.recorder.stop();});
window.addEventListener('pagehide',()=>{if(recordSession){if(recordSession.recorder.state==='recording')recordSession.recorder.stop();recordSession.stream.getTracks().forEach(track=>track.stop());}});
document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('[data-tab]').forEach(t=>t.classList.toggle('selected',t===b));for(const id of ['sound','voices','motion','input'])$('tab-'+id).hidden=id!==b.dataset.tab;}));
$('save-engine').addEventListener('click',()=>settings({local_voice_url:$('engine-url').value,local_voice_sample_rate:Number($('engine-rate').value)}));
$('check-engine').addEventListener('click',async()=>{try{const r=await api('/api/engine/check');$('engine-status').textContent=r.detail;}catch(e){$('engine-status').textContent=e.message;}});
$('save-asr').addEventListener('click',()=>settings({asr_model_path:$('asr-path').value}));
function stopManual(){clearInterval(manualTimer);manualTimer=null;api('/api/teleop',{v:0,w:0}).catch(()=>{});}
document.querySelectorAll('[data-v]').forEach(b=>{b.addEventListener('pointerdown',e=>{e.preventDefault();stopManual();b.setPointerCapture(e.pointerId);const send=()=>api('/api/teleop',{v:Number(b.dataset.v)*(snapshot?.settings.motion_speed||.05),w:Number(b.dataset.w)*.65}).catch(()=>stopManual());send();manualTimer=setInterval(send,100);});b.addEventListener('pointerup',stopManual);b.addEventListener('pointercancel',stopManual);b.addEventListener('lostpointercapture',stopManual);});
$('manual-stop').addEventListener('click',()=>{stopManual();command('停下');});window.addEventListener('blur',stopManual);document.addEventListener('visibilitychange',()=>{if(document.hidden)stopManual();});
async function distanceMove(sign){const cm=Number($('distance-cm').value);if(!Number.isFinite(cm)||cm<2||cm>30){toast('请输入2～30厘米');return;}stopManual();try{await api('/api/distance',{id:crypto.randomUUID(),distance_m:sign*cm/100});$('distance-status').textContent='已提交，等待机器人确认';}catch(e){toast(e.message);}}
$('distance-forward').addEventListener('click',()=>distanceMove(1));$('distance-backward').addEventListener('click',()=>distanceMove(-1));$('distance-stop').addEventListener('click',()=>command('停下'));
$('vision-enabled').addEventListener('change',async e=>{try{await api('/api/vision',{enabled:e.target.checked});}catch(error){toast(error.message);e.target.checked=!e.target.checked;}});
let cameraPending=false;for(const event of ['load','error'])$('camera-preview').addEventListener(event,()=>{cameraPending=false;});
setInterval(()=>{if(!document.hidden&&$('perception-details').open&&!cameraPending){cameraPending=true;$('camera-preview').src='/api/camera.png?t='+Date.now();}},600);
async function record(kind){
  if(recordSession){if(recordSession.kind!==kind){toast('请先结束当前录音');return;}recordSession.recorder.stop();return;}
  if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder){toast('当前浏览器不支持录音，请导入音频文件');return;}
  try{const stream=await navigator.mediaDevices.getUserMedia({audio:true});const mime=['audio/webm;codecs=opus','audio/ogg;codecs=opus','audio/webm'].find(t=>MediaRecorder.isTypeSupported(t));const recorder=new MediaRecorder(stream,mime?{mimeType:mime}:{});const chunks=[];const session={kind,recorder,stream,started:Date.now()};recordSession=session;
    recorder.addEventListener('dataavailable',e=>{if(e.data.size)chunks.push(e.data);});recorder.addEventListener('stop',async()=>{clearTimeout(session.timer);stream.getTracks().forEach(track=>track.stop());recordSession=null;$('listen-button').textContent='语音';$('listen-button').classList.remove('recording');$('record-reference').textContent='开始录音';const blob=new Blob(chunks,{type:recorder.mimeType});const ext=recorder.mimeType.includes('ogg')?'.ogg':'.webm';const file=new File([blob],'recording'+ext,{type:blob.type});if(kind==='reference'){referenceFile=file;showReference(file);$('record-status').textContent='录音完成，请填写对应文字并保存';}else{try{$('command-status').textContent='正在本机识别……';const r=await api('/api/asr',{audio:await toBase64(file),filename:file.name});$('command').value=r.text;$('command-status').textContent='已识别，请确认文字后发送';$('command').focus();}catch(e){$('command-status').textContent=e.message;toast(e.message);}}});
    recorder.start();session.timer=setTimeout(()=>{if(recorder.state==='recording')recorder.stop();},15000);if(kind==='reference'){$('record-reference').textContent='结束录音';$('record-status').textContent='录音中，最长15秒';}else{$('listen-button').textContent='结束';$('listen-button').classList.add('recording');$('command-status').textContent='正在听，说完点击“结束”';}
  }catch(e){toast('无法使用麦克风：'+e.message);}
}
function showReference(file){const audio=$('record-preview');if(audio.dataset.objectUrl)URL.revokeObjectURL(audio.dataset.objectUrl);const url=URL.createObjectURL(file);audio.src=url;audio.dataset.objectUrl=url;audio.hidden=false;}
function toBase64(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=reject;reader.readAsDataURL(file);});}
$('record-reference').addEventListener('click',()=>record('reference'));$('listen-button').addEventListener('click',()=>{if(!snapshot?.capabilities.asr_model||!snapshot?.capabilities.asr_package){toast('请先在设置→语音输入中准备离线识别模型');$('settings-dialog').showModal();document.querySelector('[data-tab="input"]').click();return;}record('command');});
$('voice-file').addEventListener('change',e=>{const file=e.target.files[0];if(!file)return;if(file.size>12*1024*1024){toast('录音不能超过12MB');return;}referenceFile=file;showReference(file);$('record-status').textContent=file.name;});
$('save-reference').addEventListener('click',async()=>{if(!referenceFile){toast('请先录音或选择音频文件');return;}const button=$('save-reference');button.disabled=true;try{const r=await api('/api/voices/import',{name:$('voice-name').value,prompt:$('voice-prompt').value,audio:await toBase64(referenceFile),filename:referenceFile.name});toast(r.detail);referenceFile=null;$('voice-name').value=$('voice-prompt').value='';$('record-preview').hidden=true;$('record-status').textContent='已保存，可以继续添加其他音色';renderedVoices='';await poll();}catch(e){toast(e.message);}finally{button.disabled=false;}});
// Let slow image responses finish instead of cancelling them on each timer tick.
let facePending=!$('face').complete;
for(const event of ['load','error'])$('face').addEventListener(event,()=>{facePending=false;});
function pollFace(){if(document.hidden||facePending)return;facePending=true;$('face').src='/api/face.png?t='+Date.now();}
poll();setInterval(poll,650);setInterval(pollFace,220);
