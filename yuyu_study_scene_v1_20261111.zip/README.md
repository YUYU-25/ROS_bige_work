# 木质书房场景 v1

机器人本体沿用现有版本，新增的是书房环境、桌面材质和物品外观。

## 场景内容

- 三列六层书架，共162本不同高度、厚度和书脊配色的书。
- 阅读台上的书堆、笔记本、笔筒和铅笔、眼镜、时钟、纸巾盒、盆栽。
- 木纹桌面、完整桌腿、抽屉、椅子、墙面、窗户、踢脚线和木地板。
- 带内壁、杯口和杯柄的茶杯，带织物和拉链细节的笔袋，以及有支架、关节和灯罩的台灯。
- 活动桌面上的纸张和便签为平面细节，机器人可以从上面经过。

新增网格与贴图均由项目脚本生成。运行时只读取本地资源，不访问Gazebo模型库，也不需要Blender。

## 保留的运动空间

活动桌面继续为1.0米×0.6米，顶面高度0.75米。桌沿、地板碰撞平面、杯子、笔盒和台灯的原有碰撞几何与位姿保持一致；地图、防跌落、轮速和机器人URDF均未修改。

新书架、阅读台、椅子和直立装饰物位于活动桌面以外，作为展示布景。背景布景不参与桌面导航碰撞；桌面物品继续使用原有保守碰撞包络。书脊细节不需要逐本建立物理碰撞体。

## 资源与负载

环境资源共6份COLLADA网格，合计16836个三角面，7张本地贴图，最大贴图1024×1024。书籍按材质合并在背景网格中，背景和纸张不额外投射阴影。

该数据是资源预算，不是虚拟机帧率保证。继续使用现有的服务器软件渲染、Gazebo客户端和RViz使用默认图形驱动的分开启动方式。

## 离线安装

先结束主程序并关闭Gazebo、RViz。将场景ZIP从Windows传入Ubuntu主目录后执行：

```bash
python3 -m zipfile -e ~/yuyu_study_scene_v1_20261111.zip ~/yuyu_study_update
python3 ~/yuyu_study_update/install_scene.py ~/yuyu_robot
cd ~/yuyu_robot
source tools/env.sh
colcon build --symlink-install
```

安装器先核对包内文件和原启动文件的版本，完整预检查通过后才写入工程。原文件自动备份到工程同级的`yuyu_backups/study_...`。原来已修改的启动文件会被保留，并明确停止安装；相同更新重复执行不会再次覆盖工程。

编译成功后，原有启动命令会默认使用`study.world`。SLAM试验参数仍使用原来的`desk_slam.world`。

临时切回原简洁桌面时，在原启动命令后加：

```bash
world:="$(ros2 pkg prefix yuyu_gazebo)/share/yuyu_gazebo/worlds/desk.world"
```

需要完整回退时，关闭程序，使用安装时打印的备份目录：

```bash
python3 ~/yuyu_study_update/install_scene.py --rollback ~/yuyu_backups/study_实际目录名
cd ~/yuyu_robot
source tools/env.sh
colcon build --symlink-install
```

## 预览和验证边界

`previews/study/room.png`和`previews/study/desk.png`由同一套环境几何在Blender Cycles中生成，机器人为静态预览。图片用于查看布局和材质；Gazebo的实时光照、表情与该渲染器有所不同。

场景检查覆盖原碰撞体保持一致、资源和贴图路径、网格索引、原生Assimp加载、活动区净空及面数预算；离线安装检查覆盖重复执行、损坏包、自改文件、写入失败恢复和回退。

本轮完整检查共52项，49项通过、3项跳过。跳过项是需要Humble消息环境的网格附着检查，以及2项需要真实音频进程依赖的检查。实际setuptools资源安装已核对14份网格、贴图和清单，以及`study.world`均被完整复制。

离线ZIP在“已发布0.2.0＋情绪/网页后续补丁”的临时工程上安装、重复安装和回退均通过，21份更新文件逐字节一致；其余原文件保持不变。人为制造版本不匹配、损坏文件和中途写入失败的检查均通过。

当前云端没有可运行的Humble/Gazebo11完整环境，本次没有重跑ROS物理运动，也没有测量用户VMware帧率。此前的运动验收结果不算本次场景的实机验证。

重新生成资源需要开发机器安装Blender和Pillow，在工程目录执行`python3 tools/build_study_scene.py`。用户安装离线包时不需要这些创作工具。
