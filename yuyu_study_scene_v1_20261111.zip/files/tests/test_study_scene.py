"""Deployment and physics contracts for the visual-only study-room upgrade."""
import ctypes
import ctypes.util
import json
import math
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT/'src/yuyu_description/meshes/study'
NS = {'c': 'http://www.collada.org/2005/11/COLLADASchema'}


def normalized(node):
    return node.tag, tuple(sorted(node.attrib.items())), (node.text or '').strip(), tuple(map(normalized, node))


def positions(name):
    tree = ET.parse(ASSETS/name)
    return [float(x) for x in tree.find('.//c:source[@id="positions"]/c:float_array', NS).text.split()]


class StudySceneTests(unittest.TestCase):
    def test_existing_physics_and_collision_geometry_are_preserved(self):
        plain = ET.parse(ROOT/'src/yuyu_gazebo/worlds/desk.world').find('world')
        study = ET.parse(ROOT/'src/yuyu_gazebo/worlds/study.world').find('world')
        for tag in ('gravity', 'physics', 'plugin'):
            self.assertEqual(normalized(plain.find(tag)), normalized(study.find(tag)))
        def collisions(world):
            result = {}
            for model in world.findall('model'):
                for link in model.findall('link'):
                    for collision in link.findall('collision'):
                        key = model.get('name'), link.get('name'), collision.get('name')
                        result[key] = ((model.findtext('pose') or '0 0 0 0 0 0').split(),
                                       (link.findtext('pose') or '0 0 0 0 0 0').split(), normalized(collision))
            return result
        self.assertEqual(collisions(plain), collisions(study))

    def test_resources_are_local_and_collada_indices_are_valid(self):
        world = ET.parse(ROOT/'src/yuyu_gazebo/worlds/study.world')
        prefix = 'model://yuyu_description/'
        for uri in world.findall('.//mesh/uri'):
            self.assertTrue(uri.text.startswith(prefix))
            self.assertTrue((ROOT/'src/yuyu_description'/uri.text[len(prefix):]).is_file())
        for path in ASSETS.glob('*.dae'):
            tree = ET.parse(path)
            self.assertEqual(tree.find('c:asset/c:up_axis', NS).text, 'Z_UP')
            arrays = {}
            for source in tree.findall('.//c:mesh/c:source', NS):
                a = source.find('c:float_array', NS)
                values = [float(x) for x in a.text.split()]
                self.assertEqual(len(values), int(a.get('count')))
                self.assertTrue(all(math.isfinite(v) for v in values))
                accessor = source.find('c:technique_common/c:accessor', NS)
                arrays[source.get('id')] = len(values)//int(accessor.get('stride'))
            for triangles in tree.findall('.//c:triangles', NS):
                values = [int(x) for x in triangles.find('c:p', NS).text.split()]
                self.assertEqual(len(values), int(triangles.get('count'))*9)
                for offset, name in enumerate(('positions', 'normals', 'uv')):
                    self.assertTrue(all(0 <= v < arrays[name] for v in values[offset::3]))
            for image in tree.findall('.//c:library_images/c:image/c:init_from', NS):
                self.assertEqual(Path(image.text).name, image.text)
                self.assertTrue((ASSETS/image.text).is_file())

    def test_new_upright_scenery_does_not_enter_robot_table(self):
        points = positions('room.dae')
        for x, y, z in zip(points[::3], points[1::3], points[2::3]):
            self.assertFalse(-.5 < x < .5 and -.3 < y < .3 and .75 < z < .98,
                             'new room geometry intrudes into the tested robot workspace')
        points = positions('desktop.dae')
        self.assertLessEqual(max(points[2::3]), .751)
        # The cup and pouch remain inside their existing conservative collision footprints.
        points = positions('mug.dae')
        self.assertLessEqual(max(math.hypot(x, y) for x, y in zip(points[::3], points[1::3])), .04)
        points = positions('pencil_case.dae')
        self.assertLessEqual(max(abs(x) for x in points[::3]), .075)
        self.assertLessEqual(max(abs(y) for y in points[1::3]), .025)
        manifest = json.loads((ASSETS/'manifest.json').read_text())
        self.assertLess(sum(m['triangles'] for m in manifest['meshes']), 25000)

    def test_meshes_load_with_native_assimp(self):
        library = ctypes.util.find_library('assimp')
        if not library:
            self.skipTest('native Assimp mesh importer is unavailable')
        lib = ctypes.CDLL(library)
        lib.aiImportFile.argtypes = [ctypes.c_char_p, ctypes.c_uint]
        lib.aiImportFile.restype = ctypes.c_void_p
        lib.aiReleaseImport.argtypes = [ctypes.c_void_p]
        lib.aiGetErrorString.restype = ctypes.c_char_p
        for path in ASSETS.glob('*.dae'):
            with self.subTest(file=path.name):
                scene = lib.aiImportFile(str(path).encode(), 0)
                self.assertTrue(scene, lib.aiGetErrorString())
                if scene:
                    lib.aiReleaseImport(scene)


if __name__ == '__main__':
    unittest.main()
