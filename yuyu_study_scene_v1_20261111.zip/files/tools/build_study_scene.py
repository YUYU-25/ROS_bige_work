#!/usr/bin/env python3
"""Author the original study-room assets. Users install the generated files; no Blender is needed."""
import argparse
import math
from pathlib import Path
import random
import runpy
import subprocess
import xml.etree.ElementTree as ET

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'src/yuyu_description/meshes/study'


def textures():
    ASSETS.mkdir(parents=True, exist_ok=True)
    rng = random.Random(1911)
    image = Image.new('RGB', (512, 512))
    pixels = image.load()
    for y in range(512):
        for x in range(512):
            warp = y + 5*math.sin(x/72) + 2*math.sin(x/23+y/41)
            grain = 4*math.sin(warp*1.7) + 2*math.sin(warp*5.3)
            grain += 5*math.sin(warp*.17) + rng.uniform(-2, 2)
            pixels[x, y] = tuple(max(0, min(255, int(c+grain))) for c in (139, 92, 58))
    image.save(ASSETS / 'walnut.png')
    floor = Image.new('RGB', (512, 512))
    p = floor.load()
    for y in range(512):
        row = y//43
        for x in range(512):
            groove = y % 43 < 2 or (x+(row % 2)*128) % 256 < 2
            grain = 5*math.sin(y*1.1+3*math.sin(x/70)) + rng.uniform(-2, 2)
            change = (-32 if groove else grain) + (row % 3-1)*4
            p[x, y] = tuple(int(max(0, min(255, c+change))) for c in (177, 143, 104))
    floor.save(ASSETS / 'floorboards.png')
    cloth = Image.new('RGB', (256, 256))
    p = cloth.load()
    for y in range(256):
        for x in range(256):
            d = (x % 3 == 0)*5 + (y % 3 == 0)*4 + rng.uniform(-2, 2)
            p[x, y] = (int(43+d), int(76+d), int(91+d))
    cloth.save(ASSETS / 'canvas.png')
    try:
        font = ImageFont.truetype('DejaVuSans.ttf', 15)
        small = ImageFont.truetype('DejaVuSans.ttf', 11)
    except OSError:
        font = small = ImageFont.load_default()
    atlas = Image.new('RGB', (1024, 1024))
    draw = ImageDraw.Draw(atlas)
    palette = [(45, 66, 61), (114, 58, 45), (189, 167, 126), (45, 59, 77),
               (136, 125, 102), (81, 91, 71), (158, 110, 65), (203, 191, 164)]
    titles = ['ROBOTICS', 'CONTROL', 'DESIGN', 'PHYSICS', 'NOTEBOOK', 'MATHEMATICS',
              'THE ART OF LIVING', 'COMPUTER SCIENCE', 'ESSAYS', 'FIELD NOTES',
              'ENGINEERING', 'A QUIET AFTERNOON', 'MECHANICS', 'HUMAN & ROBOT',
              'SYSTEMS', 'SELECTED POEMS']
    for i in range(32):
        x, y = (i % 8)*128, (i//8)*256
        color = palette[i % len(palette)]
        draw.rectangle((x, y, x+127, y+255), fill=color)
        edge = tuple(max(0, c-15) for c in color)
        draw.line((x+4, y, x+4, y+255), fill=edge, width=3)
        ink = (224, 210, 169) if sum(color) < 420 else (69, 58, 44)
        for line_y in (20, 25, 225, 230):
            draw.line((x+16, y+line_y, x+112, y+line_y), fill=ink, width=2)
        label = Image.new('RGBA', (200, 26))
        ImageDraw.Draw(label).text((3, 3), titles[i % len(titles)], font=font, fill=ink+(255,))
        label = label.rotate(90, expand=True)
        atlas.paste(label, (x+49, y+35), label)
        draw.text((x+40, y+237), '%02d' % (i+1), font=small, fill=ink)
    atlas.save(ASSETS / 'book_spines.png')
    paper = Image.new('RGB', (512, 512), (235, 226, 205))
    d = ImageDraw.Draw(paper)
    for y in range(512):
        if y % 5 == 0:
            d.line((0, y, 511, y), fill=(204, 194, 174))
    paper.save(ASSETS / 'page_edges.png')
    note = Image.new('RGB', (512, 512), (245, 239, 219))
    d = ImageDraw.Draw(note)
    for y in range(58, 490, 22):
        d.line((30, y, 485, y), fill=(182, 193, 191))
    d.line((63, 20, 63, 492), fill=(191, 135, 128))
    d.text((90, 28), 'TODAY / IDEAS & NOTES', font=font, fill=(65, 70, 67))
    for i, text in enumerate(('Read. Learn. Build.', 'A small robot, a little company.',
                              '01  Observations', '02  New ideas', '03  Keep exploring')):
        d.text((90, 75+i*44), text, font=font, fill=(81, 87, 84))
    note.save(ASSETS / 'notebook.png')
    sky = Image.new('RGB', (256, 256))
    d = ImageDraw.Draw(sky)
    for y in range(256):
        t = y/255
        d.line((0, y, 255, y), fill=(int(151+66*t), int(184+42*t), int(199+28*t)))
    for i in range(15):
        x = rng.randrange(256)
        h = rng.randrange(35, 95)
        d.rectangle((x, 256-h, x+18, 255), fill=(126+h//5, 154+h//5, 143+h//6))
    sky.save(ASSETS / 'window_view.png')


def element(parent, tag, text=None, **attributes):
    item = ET.SubElement(parent, tag, attributes)
    if text is not None:
        item.text = str(text)
    return item


def mesh_visual(link, name, filename, shadows=False):
    visual = element(link, 'visual', name=name)
    element(element(element(visual, 'geometry'), 'mesh'), 'uri',
            'model://yuyu_description/meshes/study/'+filename)
    element(visual, 'cast_shadows', 'true' if shadows else 'false')
    return visual


def world():
    source = ROOT / 'src/yuyu_gazebo/worlds/desk.world'
    tree = ET.parse(source)
    root = tree.getroot()
    w = root.find('world')
    w.set('name', 'yuyu_study')
    scene = w.find('scene')
    scene.find('ambient').text = '.52 .49 .44 1'
    scene.find('background').text = '.79 .81 .79 1'
    light = w.find("light[@name='desk_light']")
    light.find('diffuse').text = '.90 .85 .75 1'
    light.find('specular').text = '.16 .15 .13 1'
    light.find('direction').text = '-.35 -.65 -1'
    w.find('gui/camera/pose').text = '1.15 -1.2 1.35 0 .247 2.335'
    # Only replace visuals. The tested table, rim and three obstacle collisions are identical.
    for name, filename in [('desk', 'tabletop.dae'), ('red_cup', 'mug.dae'),
                           ('blue_pencil_box', 'pencil_case.dae'), ('white_lamp', 'lamp.dae')]:
        link = w.find("model[@name='%s']/link" % name)
        for v in list(link.findall('visual')):
            link.remove(v)
        mesh_visual(link, name+'_detailed', filename, shadows=True)
    floor = w.find("model[@name='floor']/link")
    for v in list(floor.findall('visual')):
        floor.remove(v)
    for name, filename in [('study_furniture', 'room.dae'), ('desk_paper', 'desktop.dae')]:
        model = element(w, 'model', name=name)
        element(model, 'static', 'true')
        element(model, 'pose', '0 0 0 0 0 0')
        mesh_visual(element(model, 'link', name='visuals'), name, filename)
    tree = ET.ElementTree(root)
    ET.indent(tree, space='  ')
    target = ROOT / 'src/yuyu_gazebo/worlds/study.world'
    tree.write(target, encoding='utf-8', xml_declaration=True)
    return target


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--no-render', action='store_true')
    args = parser.parse_args()
    textures()
    preview = ROOT/'docs/previews/study'
    preview.mkdir(parents=True, exist_ok=True)
    face = runpy.run_path(str(ROOT/'src/yuyu_bringup/yuyu_bringup/face.py'))
    face['render']('happy').save(preview/'face.png')
    command = ['blender', '--background', '--factory-startup', '--python-exit-code', '1', '--python',
               str(ROOT/'tools/study_scene_blender.py'), '--', str(ROOT)]
    if args.no_render:
        command.append('--no-render')
    subprocess.run(command, check=True)
    target = world()
    print('Generated:', target)
    print('Robot URDF and navigation/safety configuration were not modified.')


if __name__ == '__main__':
    main()
