"""Blender authoring helper. Exports lightweight COLLADA files and renders the same scene geometry."""
import json
import math
from pathlib import Path
import random
import sys
import xml.etree.ElementTree as ET

import bpy
from mathutils import Vector

ROOT = Path(sys.argv[sys.argv.index('--')+1]).resolve()
ASSETS = ROOT/'src/yuyu_description/meshes/study'
RENDER = '--no-render' not in sys.argv
RNG = random.Random(1911)
GROUPS = {}
MATS = {}


def material(name, rgb, rough=.65, image=None, metal=0, emission=0):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*rgb, 1)
    m.use_nodes = True
    node = m.node_tree.nodes.get('Principled BSDF')
    node.inputs['Base Color'].default_value = (*rgb, 1)
    node.inputs['Roughness'].default_value = rough
    node.inputs['Metallic'].default_value = metal
    if image:
        tex = m.node_tree.nodes.new('ShaderNodeTexImage')
        tex.image = bpy.data.images.load(str(ASSETS/image))
        m.node_tree.links.new(tex.outputs['Color'], node.inputs['Base Color'])
    if emission:
        node.inputs['Emission Color'].default_value = (*rgb, 1)
        node.inputs['Emission Strength'].default_value = emission
    MATS[name] = m
    return m


def register(obj, name, mat, group, bevel=0):
    obj.name = name
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    obj.data.materials.append(MATS[mat])
    if bevel:
        mod = obj.modifiers.new('Small manufactured edge', 'BEVEL')
        mod.width, mod.segments = bevel, 2
        mod = obj.modifiers.new('Weighted corner normals', 'WEIGHTED_NORMAL')
    GROUPS.setdefault(group, []).append(obj)
    return obj


def box(name, pos, size, mat, group='room', bevel=0, yaw=0):
    bpy.ops.mesh.primitive_cube_add(size=1, location=pos, rotation=(0, 0, yaw))
    obj = bpy.context.object
    obj.dimensions = size
    return register(obj, name, mat, group, bevel)


def cyl(name, pos, radius, depth, mat, group='room', vertices=24):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=pos)
    obj = register(bpy.context.object, name, mat, group)
    for face in obj.data.polygons:
        face.use_smooth = len(face.vertices) == 4
    return obj


def segment(name, a, b, radius, mat, group='room', vertices=12):
    a, b = Vector(a), Vector(b)
    obj = cyl(name, (a+b)/2, radius, (b-a).length, mat, group, vertices)
    obj.rotation_euler = (b-a).to_track_quat('Z', 'Y').to_euler()
    return obj


def torus(name, pos, major, minor, mat, group='room', rotation=(0, 0, 0), stretch=(1, 1, 1)):
    bpy.ops.mesh.primitive_torus_add(major_radius=major, minor_radius=minor,
        major_segments=24, minor_segments=8, location=pos, rotation=rotation)
    obj = bpy.context.object
    obj.scale = stretch
    register(obj, name, mat, group)
    for face in obj.data.polygons:
        face.use_smooth = True
    return obj


def uv_cell(obj, index):
    """Map each spine face to one portrait cell of the shared book atlas."""
    mesh = obj.data
    uv = mesh.uv_layers.active
    vertices = mesh.vertices
    lo = [min(v.co[k] for v in vertices) for k in range(3)]
    hi = [max(v.co[k] for v in vertices) for k in range(3)]
    for face in mesh.polygons:
        axes = [k for k in range(3) if abs(face.normal[k]) < .5]
        if len(axes) != 2:
            axes = [1, 2]
        for loop_index in face.loop_indices:
            v = vertices[mesh.loops[loop_index].vertex_index].co
            u = (v[axes[0]]-lo[axes[0]]) / max(hi[axes[0]]-lo[axes[0]], 1e-8)
            t = (v[axes[1]]-lo[axes[1]]) / max(hi[axes[1]]-lo[axes[1]], 1e-8)
            uv.data[loop_index].uv = ((index % 8+u)/8, (3-index//8+t)/4)


def book(name, center, depth, width, height, index, group='room'):
    x, y, z = center
    pages = box(name+'_pages', (x-.002, y, z+height/2),
                (depth-.007, width-.004, height-.006), 'paper', group)
    for sign in (-1, 1):
        cover = box(name+'_cover', (x, y+sign*(width/2-.0008), z+height/2),
                    (depth, .0016, height), 'books', group)
        uv_cell(cover, index)
    spine = box(name+'_spine', (x+depth/2-.0015, y, z+height/2),
                (.003, width, height), 'books', group)
    uv_cell(spine, index)


def flat_book(name, pos, size, index):
    x, y, z = pos
    dx, dy, dz = size
    box(name+'_pages', pos, (dx-.004, dy-.003, dz-.003), 'paper')
    for sign in (-1, 1):
        obj = box(name+'_cover', (x, y, z+sign*(dz/2-.0007)),
                  (dx, dy, .0014), 'books')
        uv_cell(obj, index)
    obj = box(name+'_binding', (x-dx/2+.001, y, z), (.002, dy, dz), 'books')
    uv_cell(obj, index)


def leaf(name, center, length, width, angle, tilt):
    x, y, z = center
    a = Vector((math.cos(angle), math.sin(angle), tilt)).normalized()
    b = Vector((-math.sin(angle), math.cos(angle), 0))
    p = Vector((x, y, z))
    verts = [p, p+a*length*.45+b*width/2, p+a*length,
             p+a*length*.45-b*width/2, p+a*length*.47+Vector((0, 0, width*.15))]
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], [(0, 1, 4), (1, 2, 4), (2, 3, 4), (3, 0, 4),
                               (4, 1, 0), (4, 2, 1), (4, 3, 2), (4, 0, 3)])
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    register(obj, name, 'leaf', 'room')


def furniture():
    box('floorboards', (0, 0, -.012), (4.2, 3.6, .024), 'floor')
    box('back plaster wall', (-1.14, 0, 1.22), (.035, 2.6, 2.44), 'plaster')
    box('side wall below window', (.05, 1.14, .43), (2.4, .035, .86), 'plaster')
    box('side wall above window', (.05, 1.14, 2.29), (2.4, .035, .30), 'plaster')
    for x, width in [(-.99, .30), (.90, .70)]:
        box('side window reveal', (x, 1.14, 1.50), (width, .035, 1.28), 'plaster')
    box('view beyond window', (-.13, 1.162, 1.50), (1.42, .008, 1.28), 'sky')
    for x in (-.85, -.13, .59):
        box('window upright', (x, 1.112, 1.50), (.025, .045, 1.31), 'window_frame', bevel=.002)
    for z in (.85, 1.50, 2.15):
        box('window crossbar', (-.13, 1.112, z), (1.47, .045, .025), 'window_frame', bevel=.002)
    box('window sill', (-.13, 1.07, .85), (1.54, .13, .025), 'window_frame', bevel=.003)
    box('back skirting', (-1.105, 0, .035), (.018, 2.6, .07), 'trim')
    box('side skirting', (.1, 1.105, .035), (2.4, .018, .07), 'trim')
    for x in (-.43, .43):
        for y in (-.23, .23):
            box('walnut desk leg', (x, y, .35), (.047, .047, .70), 'walnut', bevel=.004)
    for y in (-.255, .255):
        box('desk side apron', (0, y, .66), (.91, .026, .10), 'walnut', bevel=.002)
    box('back apron', (-.435, 0, .66), (.025, .51, .10), 'walnut', bevel=.002)
    box('pencil drawer', (.40, .12, .68), (.13, .28, .07), 'walnut', bevel=.002)
    box('drawer pull', (.473, .12, .68), (.009, .07, .009), 'brass', bevel=.002)
    # The book wall and all upright new props lie beyond the tested tabletop footprint.
    box('bookcase back', (-1.065, 0, 1.10), (.022, 1.86, 2.18), 'shelf_back')
    for y in (-.93, -.31, .31, .93):
        box('bookcase upright', (-.94, y, 1.10), (.27, .025, 2.20), 'walnut', bevel=.002)
    bases = (.12, .45, .78, 1.11, 1.44, 1.77)
    number = 0
    for row, z in enumerate(bases):
        box('book shelf', (-.94, 0, z), (.28, 1.88, .022), 'walnut', bevel=.001)
        for col, left in enumerate((-.90, -.28, .34)):
            y = left+.025
            for i in range(9):
                width = RNG.uniform(.034, .052)
                height = RNG.uniform(.20, .286)
                depth = RNG.uniform(.165, .215)
                if y+width > left+.55:
                    break
                book('shelf book %03d' % number, (-.951, y+width/2, z+.012),
                     depth, width, height, number % 32)
                number += 1
                y += width+.003
    box('bookcase top', (-.94, 0, 2.20), (.30, 1.91, .03), 'walnut', bevel=.002)
    # A separate narrow reading console leaves a 10 cm gap behind the robot's desk.
    box('reading ledge', (-.82, 0, .752), (.44, 1.88, .035), 'walnut', bevel=.003)
    for y in (-.86, .86):
        box('console support', (-.82, y, .36), (.35, .03, .72), 'walnut')
    for i, h in enumerate((.022, .029, .018)):
        flat_book('reading stack %d' % i, (-.73, -.65, .78+sum((.022, .029, .018)[:i])+h/2),
                  (.18-i*.008, .135+i*.003, h), 5+i)
    box('reading notebook', (-.72, -.08, .78), (.15, .19, .010), 'notebook', bevel=.001)
    box('notebook binding', (-.72, -.08, .787), (.15, .002, .002), 'thread')
    # Pen pot, stationery, tissue box, small clock and a plant make the room lived in.
    cyl('pen cup', (-.73, -.37, .825), .029, .10, 'ceramic')
    cyl('pen cup interior', (-.73, -.37, .877), .022, .001, 'soil')
    for i in range(7):
        a = RNG.random()*2*math.pi
        x, y = -.73+.017*math.cos(a), -.37+.017*math.sin(a)
        segment('pencil', (x, y, .79), (x+.006*math.cos(a), y+.006*math.sin(a), .94),
                .0025, 'pencil' if i % 2 else 'thread', vertices=6)
    box('linen tissue box', (-.72, .27, .817), (.13, .085, .075), 'linen', bevel=.004)
    box('tissue opening', (-.72, .27, .856), (.085, .007, .001), 'soil', bevel=.001)
    obj = box('folded tissue', (-.72, .27, .875), (.07, .0015, .043), 'ivory')
    obj.rotation_euler[1] = -.18
    cyl('terracotta planter', (-.78, .69, .832), .051, .11, 'terracotta')
    cyl('pot soil', (-.78, .69, .89), .044, .002, 'soil')
    for i in range(16):
        a = i*2.4
        stem = Vector((-.78, .69, .89))
        top = stem+Vector((.036*math.cos(a), .036*math.sin(a), .07+(i % 4)*.019))
        segment('plant stem', stem, top, .0014, 'leaf', vertices=6)
        leaf('plant leaf', top, .067, .031, a, -.13)
    # Round alarm clock facing the room (+X), with visible hands.
    obj = cyl('clock case', (-.72, .47, .842), .047, .028, 'brass')
    obj.rotation_euler[1] = math.pi/2
    obj = cyl('clock dial', (-.704, .47, .842), .042, .0015, 'ivory')
    obj.rotation_euler[1] = math.pi/2
    segment('clock long hand', (-.701, .47, .842), (-.701, .447, .859), .0013, 'thread')
    segment('clock short hand', (-.700, .47, .842), (-.700, .484, .854), .0017, 'thread')
    for y in (-.017, .017):
        torus('reading glasses', (-.70, -.20+y, .786), .014, .0012, 'brass', stretch=(1.3, 1, 1))
    segment('glasses bridge', (-.70, -.203, .786), (-.70, -.197, .786), .001, 'brass')
    for y in (-.234, -.166):
        segment('glasses temple', (-.70, y, .786), (-.76, y, .788), .001, 'brass')
    # Chair is kept to one side so presentation cameras can see the robot.
    box('chair seat', (.89, .28, .44), (.36, .34, .045), 'walnut', bevel=.016)
    box('chair cushion', (.88, .28, .467), (.29, .29, .025), 'linen', bevel=.012)
    for x in (.75, 1.03):
        for y in (.15, .41):
            segment('chair leg', (x, y, .02), (x, y, .43), .016, 'walnut')
    for y in (.14, .42):
        segment('chair back post', (1.04, y, .42), (1.10, y, .87), .014, 'walnut')
    obj = box('chair back', (1.09, .28, .79), (.032, .35, .19), 'walnut', bevel=.018)
    obj.rotation_euler[1] = -.13
    box('tabletop', (0, 0, .73), (1, .6, .04), 'walnut', 'table', bevel=.006)
    return number


def props():
    x, y, z = .2, .1, .81
    # A genuinely hollow mug, including inner walls, bottom and rim.
    verts, faces = [], []
    rings = [(.029, -.059), (.031, -.052), (.032, .052), (.0285, .052), (.0275, -.050)]
    for radius, height in rings:
        verts.extend((x+radius*math.cos(i*math.tau/32), y+radius*math.sin(i*math.tau/32), z+height)
                     for i in range(32))
    for ring in range(len(rings)-1):
        for i in range(32):
            a, b = ring*32+i, ring*32+(i+1) % 32
            faces.append((a, b, b+32, a+32))
    faces.append(tuple(reversed(range(32))))
    faces.append(tuple(range(128, 160)))
    mesh = bpy.data.meshes.new('hollow mug')
    mesh.from_pydata(verts, [], faces)
    obj = bpy.data.objects.new('glazed mug', mesh)
    bpy.context.collection.objects.link(obj)
    register(obj, 'glazed mug', 'mug', 'cup')
    for f in mesh.polygons:
        f.use_smooth = len(f.vertices) == 4
    torus('mug handle', (x+.026, y, z+.003), .017, .003, 'mug', 'cup',
          rotation=(math.pi/2, 0, 0), stretch=(.65, 1, 1.5))
    cyl('tea', (x, y, z+.028), .0278, .001, 'tea', 'cup', vertices=32)
    cyl('cork coaster', (x, y, .751), .039, .002, 'cork', 'cup', vertices=32)
    box('canvas pencil pouch', (-.2, -.15, .765), (.148, .049, .028), 'canvas', 'case', bevel=.006)
    box('zipper fabric', (-.2, -.15, .780), (.124, .005, .001), 'thread', 'case', bevel=.001)
    for i in range(29):
        box('zipper tooth', (-.257+i*.004, -.15, .781), (.002, .004, .001), 'brass', 'case')
    torus('zipper pull', (-.263, -.15, .781), .004, .0007, 'brass', 'case', stretch=(1.5, .7, 1))
    # Retain the exact lamp base and stem collision volumes from desk.world.
    x, y, z = .35, -.2, .75
    cyl('lamp base', (x, y, z+.009), .043, .018, 'cream', 'lamp', vertices=32)
    segment('lamp stem', (x, y, z+.017), (x, y, z+.215), .004, 'thread', 'lamp')
    segment('lamp arm', (x, y, z+.215), (x-.065, y+.013, z+.285), .004, 'cream', 'lamp')
    for pos in ((x, y, z+.215), (x-.065, y+.013, z+.285)):
        obj = cyl('lamp brass joint', pos, .009, .012, 'brass', 'lamp')
        obj.rotation_euler[0] = math.pi/2
    cx, cy, cz = x-.067, y+.013, z+.268
    bpy.ops.mesh.primitive_cone_add(vertices=32, radius1=.041, radius2=.013,
                                   depth=.041, location=(cx, cy, cz))
    register(bpy.context.object, 'metal lampshade', 'cream', 'lamp')
    cyl('warm shade interior', (cx, cy, cz-.021), .036, .001, 'light', 'lamp', vertices=32)
    # Flat paper is a nonblocking surface detail, not a new navigation obstacle.
    box('loose ruled paper', (-.33, .175, .75025), (.18, .13, .0004), 'notebook', 'desktop')
    box('sticky note', (.41, .24, .75045), (.045, .038, .0005), 'note', 'desktop', yaw=.08)
    box('small paper reminder', (-.40, -.24, .75045), (.055, .028, .0005), 'ivory', 'desktop', yaw=-.07)


def collada(obj, path):
    """Write portable COLLADA 1.4.1; recent Blender builds omit the old exporter."""
    def child(parent, tag, value=None, **attributes):
        e = ET.SubElement(parent, tag, {k: str(v) for k, v in attributes.items()})
        if value is not None:
            e.text = str(value)
        return e
    def numbers(values):
        return ' '.join(format(float(v), '.9g') for v in values)
    root = ET.Element('COLLADA', xmlns='http://www.collada.org/2005/11/COLLADASchema', version='1.4.1')
    asset = child(root, 'asset')
    child(asset, 'unit', name='meter', meter='1')
    child(asset, 'up_axis', 'Z_UP')
    images = child(root, 'library_images')
    effects = child(root, 'library_effects')
    materials = child(root, 'library_materials')
    for i, mat in enumerate(obj.data.materials):
        color = tuple(mat.diffuse_color)
        node = mat.node_tree.nodes.get('Principled BSDF')
        texture = next((n for n in mat.node_tree.nodes if n.type == 'TEX_IMAGE'), None)
        profile = child(child(effects, 'effect', id='effect_%d' % i), 'profile_COMMON')
        if texture:
            name = Path(texture.image.filepath).name
            assert (ASSETS/name).is_file(), name
            child(child(images, 'image', id='image_%d' % i), 'init_from', name)
            surface = child(child(profile, 'newparam', sid='surface_%d' % i), 'surface', type='2D')
            child(surface, 'init_from', 'image_%d' % i)
            sampler = child(child(profile, 'newparam', sid='sampler_%d' % i), 'sampler2D')
            child(sampler, 'source', 'surface_%d' % i)
        phong = child(child(profile, 'technique', sid='common'), 'phong')
        child(child(phong, 'emission'), 'color', '0 0 0 1')
        child(child(phong, 'ambient'), 'color', numbers([c*.42 for c in color[:3]]+[1]))
        diffuse = child(phong, 'diffuse')
        if texture:
            child(diffuse, 'texture', texture='sampler_%d' % i, texcoord='UVMap')
        else:
            child(diffuse, 'color', numbers(color))
        roughness = float(node.inputs['Roughness'].default_value)
        specular = .05+(1-roughness)*.18
        child(child(phong, 'specular'), 'color', numbers([specular]*3+[1]))
        child(child(phong, 'shininess'), 'float', 3+(1-roughness)*45)
        child(child(materials, 'material', id='material_%d' % i, name=mat.name),
              'instance_effect', url='#effect_%d' % i)
    mesh = obj.data
    mesh.calc_loop_triangles()
    corner_normals = mesh.corner_normals
    positions, normals, uvs, triangles = [], [], [], {}
    for triangle in mesh.loop_triangles:
        indices = []
        for loop_index in triangle.loops:
            indices.append(len(positions)//3)
            positions.extend(mesh.vertices[mesh.loops[loop_index].vertex_index].co)
            normals.extend(corner_normals[loop_index].vector)
            uvs.extend(mesh.uv_layers.active.data[loop_index].uv if mesh.uv_layers.active else (0, 0))
        triangles.setdefault(triangle.material_index, []).append(indices)
    geometry = child(child(root, 'library_geometries'), 'geometry', id='geometry')
    geometry_mesh = child(geometry, 'mesh')
    for name, values, stride, axes in [('positions', positions, 3, 'XYZ'),
                                       ('normals', normals, 3, 'XYZ'), ('uv', uvs, 2, 'ST')]:
        source = child(geometry_mesh, 'source', id=name)
        child(source, 'float_array', numbers(values), id=name+'_array', count=len(values))
        accessor = child(child(source, 'technique_common'), 'accessor',
                         source='#'+name+'_array', count=len(values)//stride, stride=stride)
        for axis in axes:
            child(accessor, 'param', name=axis, type='float')
    child(child(geometry_mesh, 'vertices', id='vertices'), 'input', semantic='POSITION', source='#positions')
    for index, faces in triangles.items():
        part = child(geometry_mesh, 'triangles', material='symbol_%d' % index, count=len(faces))
        child(part, 'input', semantic='VERTEX', source='#vertices', offset=0)
        child(part, 'input', semantic='NORMAL', source='#normals', offset=1)
        child(part, 'input', semantic='TEXCOORD', source='#uv', offset=2, set=0)
        child(part, 'p', ' '.join(str(v) for face in faces for index in face for v in (index, index, index)))
    scene = child(child(root, 'library_visual_scenes'), 'visual_scene', id='Scene')
    geometry_instance = child(child(scene, 'node', id='Geometry'), 'instance_geometry', url='#geometry')
    bindings = child(child(geometry_instance, 'bind_material'), 'technique_common')
    for index in triangles:
        binding = child(bindings, 'instance_material', symbol='symbol_%d' % index,
                        target='#material_%d' % index)
        child(binding, 'bind_vertex_input', semantic='UVMap', input_semantic='TEXCOORD', input_set=0)
    child(child(root, 'scene'), 'instance_visual_scene', url='#Scene')
    ET.indent(root, space='  ')
    ET.ElementTree(root).write(path, encoding='utf-8', xml_declaration=True)


def export_group(group, filename, origin):
    bpy.ops.object.select_all(action='DESELECT')
    for obj in GROUPS[group]:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = GROUPS[group][0]
    # Bake bevels before joining so every source part keeps its own edge radius.
    for obj in GROUPS[group]:
        bpy.context.view_layer.objects.active = obj
        for modifier in list(obj.modifiers):
            bpy.ops.object.modifier_apply(modifier=modifier.name)
    bpy.context.view_layer.objects.active = GROUPS[group][0]
    if len(GROUPS[group]) > 1:
        bpy.ops.object.join()
    obj = bpy.context.object
    obj.name = group
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
    obj.location -= Vector(origin)
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
    path = ASSETS/filename
    collada(obj, path)
    obj.location = origin
    obj.data.calc_loop_triangles()
    return {'file': filename, 'triangles': len(obj.data.loop_triangles),
            'materials': len(obj.data.materials)}


def robot_preview():
    """Static preview only: reuse the existing mesh/dimensions; never export or alter the robot."""
    material('robot_graphite', (.075, .095, .12), .45)
    material('robot_black', (.018, .024, .03), .65)
    material('robot_ice', (.1, .72, .9), .45)
    material('screen', (.04, .31, .43), .5,
             image=str(ROOT/'docs/previews/study/face.png'), emission=.15)
    world_z = .752
    def rounded(name, pos, size, mat):
        bpy.ops.wm.stl_import(filepath=str(ROOT/'src/yuyu_description/meshes/rounded_box.stl'))
        obj = bpy.context.object
        obj.location, obj.scale = pos, size
        register(obj, name, mat, 'preview_robot')
        for face in obj.data.polygons:
            face.use_smooth = True
    rounded('existing robot body', (0, 0, world_z+.09), (.16, .16, .10), 'robot_graphite')
    for sign in (-1, 1):
        rounded('existing headphone', (0, sign*.085, world_z+.105), (.045, .014, .06), 'robot_black')
        rounded('existing short leg', (.04, sign*.044, world_z+.024), (.04, .03, .04), 'robot_black')
        rounded('existing wheel cover', (0, sign*.06, world_z+.025), (.06, .036, .046), 'robot_black')
        obj = cyl('existing wheel', (0, sign*.06, world_z+.025), .025, .02, 'robot_black', 'preview_robot')
        obj.rotation_euler[0] = math.pi/2
    cyl('existing lidar', (0, 0, world_z+.15), .016, .012, 'robot_ice', 'preview_robot')
    rounded('existing antenna', (-.03, 0, world_z+.166), (.009, .009, .028), 'robot_ice')
    screen = box('screen face', (.0806, 0, world_z+.092), (.001, .10, .06), 'screen', 'preview_robot')
    for index, loop in enumerate(screen.data.loops):
        point = screen.data.vertices[loop.vertex_index].co
        screen.data.uv_layers.active.data[index].uv = (.5-point.y/.10, .5+point.z/.06)


def camera(name, pos, target, lens):
    bpy.ops.object.camera_add(location=pos)
    obj = bpy.context.object
    obj.name = name
    obj.rotation_euler = (Vector(target)-obj.location).to_track_quat('-Z', 'Y').to_euler()
    obj.data.lens = lens
    obj.data.clip_start, obj.data.clip_end = .015, 100
    return obj


def previews():
    robot_preview()
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'
    scene.cycles.samples = 64
    scene.cycles.use_denoising = False
    scene.render.resolution_x, scene.render.resolution_y = 1440, 1000
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = 'PNG'
    scene.world.color = (.32, .32, .32)
    scene.view_settings.view_transform = 'AgX'
    bpy.ops.object.light_add(type='AREA', location=(.4, .7, 2.0))
    light = bpy.context.object
    light.data.energy, light.data.shape, light.data.size = 100, 'DISK', 1.6
    light.rotation_euler = (Vector((-.2, 0, .8))-light.location).to_track_quat('-Z', 'Y').to_euler()
    bpy.ops.object.light_add(type='AREA', location=(1.1, -1.6, 1.8))
    light = bpy.context.object
    light.data.energy, light.data.size = 45, 2.0
    light.rotation_euler = (Vector((-.2, 0, .9))-light.location).to_track_quat('-Z', 'Y').to_euler()
    out = ROOT/'docs/previews/study'
    out.mkdir(parents=True, exist_ok=True)
    scene.camera = camera('room overview', (2.35, -2.65, 2.0), (-.25, .04, 1.03), 44)
    scene.render.filepath = str(out/'room.png')
    bpy.ops.render.render(write_still=True)
    scene.camera = camera('robot desk detail', (1.02, -1.05, 1.24), (-.11, 0, .90), 48)
    scene.render.filepath = str(out/'desk.png')
    bpy.ops.render.render(write_still=True)


bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
for name, color, rough, image, metal, emission in [
    ('walnut', (.42, .25, .13), .62, 'walnut.png', 0, 0),
    ('floor', (.55, .42, .27), .78, 'floorboards.png', 0, 0),
    ('books', (.4, .3, .2), .8, 'book_spines.png', 0, 0),
    ('paper', (.80, .75, .65), .9, 'page_edges.png', 0, 0),
    ('canvas', (.10, .20, .25), .95, 'canvas.png', 0, 0),
    ('notebook', (.88, .86, .78), .85, 'notebook.png', 0, 0),
    ('sky', (.65, .77, .83), .9, 'window_view.png', 0, 0),
    ('plaster', (.76, .73, .65), .95, None, 0, 0),
    ('window_frame', (.78, .76, .69), .7, None, 0, 0),
    ('trim', (.46, .39, .29), .75, None, 0, 0),
    ('shelf_back', (.29, .21, .14), .8, None, 0, 0),
    ('brass', (.37, .24, .09), .4, None, .65, 0),
    ('thread', (.055, .065, .06), .65, None, 0, 0),
    ('ivory', (.85, .84, .78), .8, None, 0, 0),
    ('ceramic', (.65, .69, .62), .35, None, 0, 0),
    ('pencil', (.60, .33, .12), .7, None, 0, 0),
    ('soil', (.055, .038, .022), 1, None, 0, 0),
    ('linen', (.43, .42, .34), .95, None, 0, 0),
    ('terracotta', (.43, .20, .12), .8, None, 0, 0),
    ('leaf', (.10, .22, .095), .8, None, 0, 0),
    ('mug', (.38, .105, .065), .25, None, 0, 0),
    ('tea', (.13, .064, .017), .17, None, 0, 0),
    ('cork', (.32, .23, .13), .95, None, 0, 0),
    ('cream', (.73, .71, .61), .4, None, .12, 0),
    ('light', (.95, .72, .35), .5, None, 0, .4),
    ('note', (.81, .68, .35), .9, None, 0, 0),
]:
    material(name, color, rough, image, metal, emission)
book_count = furniture()
props()
stats = []
for group, filename, origin in [('table', 'tabletop.dae', (0, 0, .73)),
    ('cup', 'mug.dae', (.2, .1, .81)), ('case', 'pencil_case.dae', (-.2, -.15, .765)),
    ('lamp', 'lamp.dae', (.35, -.2, .75)), ('room', 'room.dae', (0, 0, 0)),
    ('desktop', 'desktop.dae', (0, 0, 0))]:
    stats.append(export_group(group, filename, origin))
(ASSETS/'manifest.json').write_text(json.dumps({'book_count': book_count, 'meshes': stats,
    'preview_renderer': 'Blender Cycles; same environment geometry, static robot preview only'}, indent=2)+'\n')
if RENDER:
    previews()
print('STUDY ASSETS READY', json.dumps(stats), flush=True)
