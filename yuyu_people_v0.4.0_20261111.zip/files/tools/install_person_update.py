#!/usr/bin/env python3
"""Apply the verified offline person-interaction bundle without Git or network access."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relative(name):
    p = Path(name)
    if p.is_absolute() or '..' in p.parts or not p.parts:
        raise ValueError('不安全的文件路径：'+name)
    return p


def install(bundle, project):
    manifest = json.loads((bundle/'manifest.json').read_text(encoding='utf-8'))
    entries = manifest['files']
    for name in manifest.get('required_files', []):
        if not (project/relative(name)).is_file():
            raise ValueError('请先安装书房场景资源：'+name)
    if not (project/'src/yuyu_gazebo/package.xml').is_file():
        raise ValueError('这里不是禹禹工程目录：'+str(project))
    changes = []
    for entry in entries:
        rel = relative(entry['path'])
        src, dst = bundle/'files'/rel, project/rel
        if not src.is_file() or digest(src) != entry['sha256']:
            raise ValueError('更新包校验失败：'+str(rel))
        if not dst.resolve().is_relative_to(project.resolve()):
            raise ValueError('目标文件通过符号链接指向工程外部：'+str(rel))
        if dst.exists() and digest(dst) == entry['sha256']:
            continue
        if dst.exists() and (entry['before_sha256'] is None or digest(dst) != entry['before_sha256']):
            raise ValueError('文件版本不匹配，未修改工程：'+str(rel))
        if not dst.exists() and entry['before_sha256'] is not None:
            raise ValueError('工程缺少原文件，未修改工程：'+str(rel))
        changes.append((entry, src, dst))
    if not changes:
        print('这份人物互动功能已经安装，下一步编译即可。')
        return
    parent = project.parent/'yuyu_backups'
    parent.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    backup = Path(tempfile.mkdtemp(prefix='people_'+stamp+'_', dir=parent))
    journal = {'project': str(project.resolve()), 'files': []}
    # Stage the complete update and back up originals before the first project mutation.
    with tempfile.TemporaryDirectory(prefix='people-stage-', dir=project.parent) as staging:
        staged = Path(staging)
        for entry, src, dst in changes:
            rel = relative(entry['path'])
            candidate = staged/rel
            candidate.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, candidate)
            existed = dst.exists()
            if existed:
                original = backup/'original'/rel
                original.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dst, original)
            journal['files'].append({'path': str(rel), 'existed': existed,
                                      'before_sha256': digest(dst) if existed else None,
                                      'installed_sha256': entry['sha256']})
        (backup/'restore.json').write_text(json.dumps(journal, indent=2), encoding='utf-8')
        applied = []
        try:
            for entry, src, dst in changes:
                rel = relative(entry['path'])
                dst.parent.mkdir(parents=True, exist_ok=True)
                os.replace(staged/rel, dst)
                applied.append((rel, dst))
        except Exception:
            for rel, dst in reversed(applied):
                original = backup/'original'/rel
                if original.exists():
                    shutil.copy2(original, dst)
                elif dst.exists():
                    dst.unlink()
            raise
    print('人物互动资源安装完成；原文件备份：'+str(backup))
    print('接下来在工程目录执行：source tools/env.sh && colcon build --symlink-install')


def rollback(backup):
    journal = json.loads((backup/'restore.json').read_text(encoding='utf-8'))
    project = Path(journal['project'])
    for entry in journal['files']:
        rel = relative(entry['path'])
        dst = project/rel
        original = backup/'original'/rel
        if entry['existed'] and (not original.is_file() or digest(original) != entry['before_sha256']):
            raise ValueError('备份文件缺失或被修改，停止回退：'+str(original))
        if dst.exists() and digest(dst) != entry['installed_sha256']:
            raise ValueError('安装后文件又被修改，保留你的改动并停止回退：'+str(dst))
        if not dst.resolve().is_relative_to(project.resolve()):
            raise ValueError('目标位于工程之外：'+str(dst))
    for entry in reversed(journal['files']):
        rel = relative(entry['path'])
        dst = project/rel
        if entry['existed']:
            shutil.copy2(backup/'original'/rel, dst)
        elif dst.exists():
            dst.unlink()
    print('已恢复更新前的资源和启动文件；请重新编译后启动。')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('project', nargs='?', type=Path, default=Path.home()/'yuyu_robot')
    parser.add_argument('--rollback', type=Path)
    args = parser.parse_args()
    try:
        if args.rollback:
            rollback(args.rollback.resolve())
        else:
            install(Path(__file__).resolve().parent, args.project.resolve())
    except (OSError, ValueError, KeyError) as error:
        print('安装停止：'+str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
