#!/usr/bin/env python3
"""Author a seated 3D visitor with a public-domain NASA face texture (no robot changes)."""
import ast
import math
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import bpy
from mathutils import Vector

ROOT=Path(sys.argv[sys.argv.index('--')+1]).resolve()
ASSETS=ROOT/'src/yuyu_description/meshes/person'
# Reuse only the mesh-authoring functions, without executing the study generator's main body.
source=ast.parse((ROOT/'tools/study_scene_blender.py').read_text())
names={'material','register','box','cyl','segment','collada','export_group'}
ns={'bpy':bpy,'Vector':Vector,'math':math,'ET':ET,'Path':Path,'ASSETS':ASSETS,'GROUPS':{},'MATS':{}}
exec(compile(ast.Module(body=[n for n in source.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),'<shared-mesh-authoring>','exec'),ns)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
material,box,cyl,segment,register=[ns[n] for n in ['material','box','cyl','segment','register']]
material('shirt',(.13,.27,.33));material('trousers',(.12,.15,.20));material('skin',(.68,.47,.34));material('shoes',(.045,.05,.06));material('hair',(.13,.09,.065));material('face',(1,1,1),image='astronaut.png')
# Local +X is the visitor's forward direction; world pose turns them toward the desk.
box('seated torso',(-.01,0,.79),(.22,.31,.38),'shirt','person',bevel=.035)
box('waist',(.015,0,.565),(.24,.29,.11),'trousers','person',bevel=.02)
for sign in [-1,1]:
 segment('upper arm',(-.015,sign*.18,.925),(.055,sign*.19,.77),.045,'shirt','person',vertices=16)
 segment('forearm',(.055,sign*.19,.77),(.255,sign*.15,.77),.031,'skin','person',vertices=16)
 bpy.ops.mesh.primitive_uv_sphere_add(segments=16,ring_count=8,location=(.26,sign*.15,.77));o=bpy.context.object;o.scale=(.045,.027,.023);register(o,'hand','skin','person')
 segment('thigh',(.02,sign*.075,.53),(.22,sign*.075,.465),.065,'trousers','person',vertices=16)
 segment('lower leg',(.22,sign*.075,.465),(.22,sign*.075,.09),.047,'trousers','person',vertices=16)
 box('shoe',(.255,sign*.075,.04),(.16,.10,.075),'shoes','person',bevel=.016)
cyl('neck',(0,0,1.005),.039,.09,'skin','person',vertices=20)
bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=16,location=(0,0,1.105));o=bpy.context.object;o.scale=(.08,.078,.107);register(o,'head','skin','person')
bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,location=(-.015,0,1.12));o=bpy.context.object;o.scale=(.075,.083,.10);register(o,'back hair','hair','person')
# Front oval maps a face region from the unmodified source image. No bitmap is edited.
vertices=[(.083,0,1.105)];uvs=[(224/512,1-112/512)]
for i in range(32):
 a=2*math.pi*i/32
 vertices.append((.083,.071*math.cos(a),1.105+.095*math.sin(a)))
 uvs.append(((224-59*math.cos(a))/512,1-(112-76*math.sin(a))/512))
mesh=bpy.data.meshes.new('face oval');mesh.from_pydata(vertices,[],[(0,i+1,(i+1)%32+1) for i in range(32)]);mesh.update()
obj=bpy.data.objects.new('visitor face',mesh);bpy.context.collection.objects.link(obj);register(obj,'visitor face','face','person')
uv=mesh.uv_layers.new(name='UVMap')
for poly in mesh.polygons:
 for loop in poly.loop_indices:uv.data[loop].uv=uvs[mesh.loops[loop].vertex_index]
result=ns['export_group']('person','seated_visitor.dae',(0,0,0));print(result,flush=True)
world=ET.parse(ROOT/'src/yuyu_gazebo/worlds/study_slam.world');w=world.find('world');w.set('name','yuyu_study_people')
m=ET.SubElement(w,'model',name='study_visitor');ET.SubElement(m,'static').text='true';ET.SubElement(m,'pose').text='.91 .28 0 0 0 3.14159265359'
l=ET.SubElement(m,'link',name='visitor');v=ET.SubElement(l,'visual',name='seated_person');g=ET.SubElement(ET.SubElement(v,'geometry'),'mesh');ET.SubElement(g,'uri').text='model://yuyu_description/meshes/person/seated_visitor.dae'
c=ET.SubElement(l,'collision',name='body_envelope');ET.SubElement(c,'pose').text='.04 0 .61 0 0 0';ET.SubElement(ET.SubElement(ET.SubElement(c,'geometry'),'box'),'size').text='.33 .43 1.2'
ET.indent(world,space='  ');world.write(ROOT/'src/yuyu_gazebo/worlds/study_people.world',encoding='utf-8',xml_declaration=True)
