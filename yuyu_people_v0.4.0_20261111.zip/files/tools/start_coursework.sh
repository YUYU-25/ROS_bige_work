#!/usr/bin/env bash
# Same singleton lock and environment as the stable companion mode.
set -eo pipefail
project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$project_dir/tools/env.sh"
exec bash "$project_dir/tools/start.sh" use_slam:=true \
  world:="$(ros2 pkg prefix yuyu_gazebo)/share/yuyu_gazebo/worlds/study_people.world" \
  nav2_params:="$(ros2 pkg prefix yuyu_bringup)/share/yuyu_bringup/config/nav2_slam.yaml" \
  rviz_config:="$(ros2 pkg prefix yuyu_description)/share/yuyu_description/rviz/yuyu_coursework.rviz" "$@"
