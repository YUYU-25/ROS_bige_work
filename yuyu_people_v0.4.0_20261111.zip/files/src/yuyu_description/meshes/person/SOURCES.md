# Visitor mesh and texture

`seated_visitor.dae` is original procedural mesh geometry authored by `tools/build_person_scene.py` for this project. It depicts a seated visitor and is used only as a simulated visual target, not a source of ground-truth coordinates for the product controller.

`astronaut.png` is the unchanged public-domain NASA photograph of astronaut Eileen Collins distributed by scikit-image. Source: https://github.com/scikit-image/scikit-image/blob/v0.19.3/skimage/data/astronaut.png . Credit: NASA. Reference: https://scikit-image.org/docs/stable/api/skimage.data.html#skimage.data.astronaut . UV coordinates select its face region for the simulated visitor; the detector does not know or identify the depicted person's name.

The OpenCV Haar cascade in `yuyu_bringup/config/person/` is from OpenCV 4.5.4. Its original notices are retained in the XML; the accompanying OpenCV license is included. This is face detection, not biometric identity recognition.
