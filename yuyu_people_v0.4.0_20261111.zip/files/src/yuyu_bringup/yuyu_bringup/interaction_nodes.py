"""ROS adapters for atomic commands, speech, task coordination and the short dance."""
from collections import OrderedDict
import json
import math
from pathlib import Path
import random
import time
import uuid
import yaml
from ament_index_python.packages import get_package_share_directory
from rclpy.node import Node
from rclpy.action import ActionClient
from rclpy.qos import qos_profile_sensor_data
from geometry_msgs.msg import PoseStamped, Twist
from nav_msgs.msg import Odometry, Path as NavPath
from nav2_msgs.action import NavigateToPose, ComputePathToPose
from std_msgs.msg import Bool, Float64, String
from tf2_ros import Buffer, TransformListener, TransformException
from .behavior import TaskCoordinator
from .core import interpret, dance_space
from .dance import beat_at, DURATION, displacement, final_yaw_velocity
from .ros_utils import LATCH, string, twist, pose_of, pose_in_map, wall_timer
from .settings import SettingsStore, validated_settings
from .speech import SpeechWorker
from .attention_speech import AttentionSpeech


class VoiceEmotion(Node):
    def __init__(self):
        super().__init__('voice_emotion')
        path = Path(get_package_share_directory('yuyu_bringup'))/'config/quotes.yaml'
        self.library = yaml.safe_load(path.read_text(encoding='utf-8'))
        self.behavior = self.create_publisher(String, '/behavior_cmd', 20)
        self.emotion = self.create_publisher(String, '/emotion_tag', LATCH)
        self.speech = self.create_publisher(String, '/speech_request', 20)
        self.ack = self.create_publisher(String, '/command_ack', 20)
        self.seen = OrderedDict()
        self.create_subscription(String, '/command_text', self.on_text, 20)
        self.create_subscription(String, '/command_request', self.on_request, 20)

    def on_text(self, msg):
        self.process(uuid.uuid4().hex, msg.data)

    def on_request(self, msg):
        try:
            request = json.loads(msg.data)
            if not isinstance(request['text'], str) or not isinstance(request['id'], str):
                return
            self.process(request['id'][:80], request['text'])
        except (ValueError, KeyError, TypeError):
            return

    def process(self, identity, text):
        if identity in self.seen:
            self.ack.publish(string(json.dumps(self.seen[identity], ensure_ascii=False)))
            return
        text = text.strip()[:160]
        command, emotion = interpret(text)
        value = {'id': identity, 'text': text, 'command': command, 'emotion': emotion,
                 'accepted': bool(command or emotion), 'detail': '禹禹已收到'}
        if not text:
            return
        if emotion:
            self.emotion.publish(string(emotion))
            quote = random.choice(self.library.get(emotion, self.library['none']))
            action = {'silent': 'mute', 'none': 'resume'}.get(emotion, 'speak')
            self.speech.publish(string(json.dumps({'id': identity, 'action': action, 'text': quote},
                                                  ensure_ascii=False)))
        elif command == 'stop':
            self.speech.publish(string(json.dumps({'id': identity, 'action': 'cancel',
                                                   'text': '好，我先停在这里。'}, ensure_ascii=False)))
        elif not command:
            reply = ('我在呢，今天想让我陪你做点什么？' if any(x in text for x in ('你好', '早上好', '晚上好'))
                     else '这句我还没听懂，可以叫我过来、回去、跳舞，或说说你的心情。')
            value['detail'] = '已收到问候' if '还没听懂' not in reply else '这句暂时没有匹配到动作'
            self.speech.publish(string(json.dumps({'id': identity, 'action': 'speak', 'text': reply},
                                                  ensure_ascii=False)))
        if command:
            self.behavior.publish(string(command))
        self.seen[identity] = value
        while len(self.seen) > 256:
            self.seen.popitem(last=False)
        self.ack.publish(string(json.dumps(value, ensure_ascii=False)))
        self.get_logger().info('已收到：%s → %s' % (text, command or emotion or '文字回应'))


class TTS(Node):
    def __init__(self):
        super().__init__('tts')
        self.declare_parameter('audio', True)
        self.text = self.create_publisher(String, '/face_text', 20)
        self.done = self.create_publisher(Bool, '/speak_done', 10)
        self.status = self.create_publisher(String, '/speech_status', LATCH)
        self.worker = SpeechWorker(self.event, audio=bool(self.get_parameter('audio').value))
        self.attention_request=self.create_publisher(String,'/attention_speech_request',20)
        self.attention=AttentionSpeech(self.worker,lambda value:self.attention_request.publish(string(json.dumps(value,ensure_ascii=False))))
        self.create_subscription(String, '/speech_request', self.on_request, 20)
        self.create_subscription(String, '/speak_text', lambda m: self.attention.submit('speak', m.data), 20)
        self.create_subscription(String, '/user_settings', self.on_settings, LATCH)
        self.create_subscription(String,'/person_status',self.on_person,LATCH)
        self.create_subscription(String,'/attention_speech_ready',self.on_attention_ready,20)
        wall_timer(self,.1,self.attention.tick)
        self.worker.status('idle')

    def on_person(self,msg):
        try:self.attention.person=json.loads(msg.data)
        except (ValueError,TypeError):pass

    def on_attention_ready(self,msg):
        try:self.attention.ready(json.loads(msg.data))
        except (ValueError,TypeError):pass

    def on_settings(self, msg):
        try:
            self.worker.set_settings(json.loads(msg.data))
        except (ValueError, TypeError):
            pass

    def on_request(self, msg):
        try:
            value = json.loads(msg.data)
            action = value.get('action', 'speak')
            if action not in ('mute', 'resume', 'cancel', 'speak', 'preview'):
                return
            self.attention.submit(action, value.get('text', ''), value.get('voice_id'), value.get('id'))
        except (ValueError, TypeError):
            pass

    def event(self, kind, value):
        if not self.context.ok():
            return
        if kind == 'text':
            self.text.publish(string(value))
        elif kind == 'done':
            self.done.publish(Bool(data=bool(value)))
        else:
            self.status.publish(string(json.dumps(value, ensure_ascii=False)))
            if value.get('state') == 'error' or value.get('fallback'):
                self.text.publish(string(value.get('detail', '这次声音没能播出来，请检查声音设置。')))

    def destroy_node(self):
        self.worker.close()
        return super().destroy_node()


class BehaviorManager(Node):
    def __init__(self):
        super().__init__('behavior_manager')
        self.pubs = {name: self.create_publisher(String, topic, qos) for name, topic, qos in (
            ('speech', '/speak_text', 20), ('face', '/face_expr', 10), ('caption', '/face_text', 10),
            ('state', '/behavior_state', LATCH), ('mode', '/motion_mode', LATCH),
            ('status', '/task_status', LATCH), ('dance_request', '/dance_request', 10),
            ('distance_status', '/distance_status', LATCH),
            ('speech_ready','/attention_speech_ready',20),('attention_status','/attention_status',LATCH))}
        self.velocity = self.create_publisher(Twist, '/behavior_cmd_vel', 10)
        self.gate = self.create_publisher(String, '/motion_gate', LATCH)
        self.goal_pub = self.create_publisher(PoseStamped, '/nav_goal', 10)
        self.client = ActionClient(self, NavigateToPose, '/navigate_to_pose')
        self.planner = ActionClient(self, ComputePathToPose, '/compute_path_to_pose')
        self.nav_handle = self.plan_handle = None
        self.nav_serial = self.plan_serial = 0
        self.gate_mode, self.gate_hold = 'idle', True
        self.last_state, self.last_status = None, None
        self.tasks = TaskCoordinator(self.effect)
        self.tasks.speed = SettingsStore().get()['motion_speed']
        self.create_subscription(String, '/behavior_cmd', lambda m: self.tasks.request(m.data), 20)
        self.create_subscription(String, '/emotion_tag', lambda m: self.tasks.set_emotion(m.data), LATCH)
        self.create_subscription(String, '/safety_status', self.on_safety, 5)
        self.create_subscription(Odometry, '/odom', self.on_odom, qos_profile_sensor_data)
        self.create_subscription(Bool, '/manual_override', lambda m: self.tasks.manual_override() if m.data else None, 10)
        self.create_subscription(String, '/dance_status', self.on_dance, LATCH)
        self.create_subscription(String, '/user_settings', self.on_settings, LATCH)
        self.create_subscription(String, '/vision_status', self.on_vision, LATCH)
        self.create_subscription(String, '/distance_request', self.on_distance, 10)
        self.create_subscription(String,'/person_status',self.on_person,LATCH)
        self.create_subscription(String,'/face_person_request',lambda m:self.tasks.face_person(search=True),10)
        self.create_subscription(String,'/attention_speech_request',self.on_attention_speech,20)
        wall_timer(self, 0.05, self.tasks.tick)
        wall_timer(self, 1.0, self.heartbeat)

    def on_vision(self, msg):
        try: self.tasks.set_vision(json.loads(msg.data))
        except (ValueError, TypeError, KeyError): pass

    def on_person(self,msg):
        try:self.tasks.set_person(json.loads(msg.data))
        except (ValueError,TypeError,KeyError):pass

    def on_attention_speech(self,msg):
        try:
            value=json.loads(msg.data)
            if isinstance(value.get('id'),str) and isinstance(value.get('text'),str):self.tasks.face_speech(value)
        except (ValueError,TypeError,KeyError):pass

    def on_distance(self, msg):
        try:
            value = json.loads(msg.data)
            self.tasks.move_distance(float(value['distance_m']), str(value['id']))
        except (ValueError, TypeError, KeyError):
            self.get_logger().warning('忽略无效定距运动请求')

    def on_safety(self, msg):
        try:
            value = json.loads(msg.data)
            self.tasks.set_safety(value)
        except (ValueError, TypeError, KeyError):
            pass

    def on_odom(self, msg):
        self.tasks.odom, self.tasks.odom_at = pose_of(msg), time.monotonic()

    def on_settings(self, msg):
        try:
            self.tasks.speed = validated_settings(json.loads(msg.data))['motion_speed']
        except (ValueError, TypeError):
            pass

    def on_dance(self, msg):
        try:
            value = json.loads(msg.data)
            if value['state'] == 'finished':
                self.tasks.dance_result(value['id'], value['success'], value.get('reason', ''))
        except (ValueError, TypeError, KeyError):
            pass

    def publish_gate(self):
        tasks = getattr(self, 'tasks', None)
        generation = tasks.generation if tasks else 0
        self.gate.publish(string(json.dumps({'mode': self.gate_mode, 'hold': self.gate_hold,
                                             'generation': generation})))

    def effect(self, kind, value):
        if kind == 'velocity':
            self.velocity.publish(twist(*value))
        elif kind == 'hold':
            self.gate_hold = bool(value)
            self.publish_gate()
        elif kind == 'cancel_navigation':
            self.nav_serial += 1
            if self.nav_handle:
                self.nav_handle.cancel_goal_async()
            self.nav_handle = None
        elif kind == 'cancel_plan':
            self.plan_serial += 1
            if self.plan_handle:
                self.plan_handle.cancel_goal_async()
            self.plan_handle = None
        elif kind == 'navigation':
            self.navigate(value)
        elif kind == 'path_request':
            self.plan(value)
        else:
            if kind == 'mode':
                self.gate_mode = value
                self.publish_gate()
            if kind == 'state' and value != self.last_state:
                self.last_state = value
                self.get_logger().info('状态：'+value)
            payload = json.dumps(value, ensure_ascii=False) if isinstance(value, dict) else value
            self.pubs[kind].publish(string(payload))
            if kind == 'status':
                self.last_status = payload

    def pose_message(self, target):
        msg = PoseStamped()
        msg.header.frame_id = 'map'
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.pose.position.x, msg.pose.position.y = float(target[0]), float(target[1])
        yaw = target[2] if len(target) == 3 else self.tasks.pose[2]
        msg.pose.orientation.z, msg.pose.orientation.w = math.sin(yaw/2), math.cos(yaw/2)
        return msg

    def navigate(self, request):
        token = request['token']
        if not self.client.server_is_ready():
            self.tasks.navigation_result(token, False)
            return
        self.nav_serial += 1
        serial = self.nav_serial
        goal = NavigateToPose.Goal()
        goal.pose = self.pose_message(request['target'])
        self.goal_pub.publish(goal.pose)
        future = self.client.send_goal_async(goal)
        def accepted(done):
            try:
                handle = done.result()
                if serial != self.nav_serial or token != self.tasks.generation:
                    if handle.accepted:
                        handle.cancel_goal_async()
                    return
                if not handle.accepted:
                    self.tasks.navigation_result(token, False)
                    return
                self.nav_handle = handle
                handle.get_result_async().add_done_callback(finished)
            except Exception:
                if serial == self.nav_serial:
                    self.tasks.navigation_result(token, False)
        def finished(done):
            if serial != self.nav_serial:
                return
            self.nav_handle = None
            try:
                success = done.result().status == 4
            except Exception:
                success = False
            self.tasks.navigation_result(token, success)
        future.add_done_callback(accepted)

    def plan(self, request):
        token, target = request['token'], request['target']
        if not self.planner.server_is_ready():
            # No blind direct-motion fallback: remain stopped while navigation initializes.
            self.tasks.pending_spots.clear()
            self.tasks.path_result(token, target, [])
            return
        self.plan_serial += 1
        serial = self.plan_serial
        goal = ComputePathToPose.Goal()
        goal.goal, goal.use_start = self.pose_message(target), False
        future = self.planner.send_goal_async(goal)
        def accepted(done):
            try:
                handle = done.result()
                if serial != self.plan_serial or token != self.tasks.generation:
                    if handle.accepted:
                        handle.cancel_goal_async()
                    return
                if not handle.accepted:
                    self.tasks.path_result(token, target, [])
                    return
                self.plan_handle = handle
                handle.get_result_async().add_done_callback(finished)
            except Exception:
                if serial == self.plan_serial:
                    self.tasks.path_result(token, target, [])
        def finished(done):
            if serial != self.plan_serial:
                return
            self.plan_handle = None
            try:
                result = done.result()
                points = [(p.pose.position.x, p.pose.position.y) for p in result.result.path.poses] if result.status == 4 else []
            except Exception:
                points = []
            self.tasks.path_result(token, target, points)
        future.add_done_callback(accepted)

    def heartbeat(self):
        self.publish_gate()
        self.pubs['state'].publish(string(self.tasks.state))
        if self.last_status:
            self.pubs['status'].publish(string(self.last_status))


class Dance(Node):
    def __init__(self):
        super().__init__('dance')
        self.identity, self.active, self.started = '', False, 0.0
        self.safety, self.safety_at, self.odom_at = {}, 0.0, 0.0
        self.origin, self.last_caption = (0.0, 0.0, 0.0), ''
        self.points, self.last_point = [], 0.0
        self.tf = Buffer()
        self.listener = TransformListener(self.tf, self)
        self.pub = self.create_publisher(Twist, '/dance_cmd_vel', 10)
        self.done = self.create_publisher(Bool, '/dance_done', 10)
        self.active_pub = self.create_publisher(Bool, '/dance_active', LATCH)
        self.status = self.create_publisher(String, '/dance_status', LATCH)
        self.note = self.create_publisher(String, '/face_text', 10)
        self.path = self.create_publisher(NavPath, '/dance_path', LATCH)
        self.legacy_command = self.create_publisher(String, '/behavior_cmd', 10)
        self.error = self.create_publisher(Float64, '/dance_error', 10)
        self.create_subscription(Odometry, '/odom', lambda m: setattr(self, 'odom_at', time.monotonic()), qos_profile_sensor_data)
        self.create_subscription(String, '/safety_status', self.on_safety, 5)
        self.create_subscription(String, '/dance_request', self.on_request, 10)
        self.create_subscription(Bool, '/dance_start', self.on_legacy_start, 10)
        wall_timer(self, 0.05, self.tick)

    def on_safety(self, msg):
        try:
            self.safety, self.safety_at = json.loads(msg.data), time.monotonic()
        except (ValueError, TypeError):
            pass

    def finish(self, success=False, reason=''):
        was_active = self.active
        self.active = False
        self.pub.publish(Twist())
        self.active_pub.publish(Bool(data=False))
        self.status.publish(string(json.dumps({'id': self.identity, 'state': 'finished',
            'success': success, 'reason': reason}, ensure_ascii=False)))
        if was_active:
            self.done.publish(Bool(data=True))

    def on_legacy_start(self, msg):
        # Compatibility commands enter the same planner, gate and cancellation path.
        self.legacy_command.publish(string('dance' if msg.data else 'stop'))

    def on_request(self, msg):
        try:
            request = json.loads(msg.data)
            if request['action'] == 'stop':
                self.finish()
                return
            if request['action'] != 'start':
                return
            identity = str(request['id'])
        except (ValueError, TypeError, KeyError):
            return
        if self.active and identity == self.identity:
            return
        if self.active:
            self.finish()
        self.identity = identity
        if (not self.safety.get('ready') or any(self.safety.get('edges', {}).values())
                or time.monotonic()-self.safety_at > 0.7):
            self.finish(False, '状态还没准备好，我先停稳。')
            return
        try:
            pose = pose_in_map(self.tf, self.get_clock().now())
        except TransformException:
            self.finish(False, '定位还在准备，我先停稳。')
            return
        if not dance_space(pose):
            self.finish(False, 'space_changed')
            return
        self.origin, self.points = pose, []
        self.active, self.started, self.last_caption = True, time.monotonic(), ''
        self.active_pub.publish(Bool(data=True))
        self.status.publish(string(json.dumps({'id': self.identity, 'state': 'active'})))

    def tick(self):
        if not self.active:
            return
        now = time.monotonic()
        if (not self.safety.get('ready') or any(self.safety.get('edges', {}).values())
                or now-self.safety_at > 0.7 or now-self.odom_at > 0.7):
            self.finish(False, '状态有变化，我先停止表演。')
            return
        try:
            pose = pose_in_map(self.tf, self.get_clock().now())
        except TransformException:
            self.finish(False, '定位暂时不稳定，我先停稳。')
            return
        elapsed, error = now-self.started, displacement(pose, self.origin)
        self.error.publish(Float64(data=error))
        if error > 0.045:
            self.finish(False, '动作偏离有点大，我先停稳。')
            return
        if elapsed >= DURATION:
            w = final_yaw_velocity(pose, self.origin)
            if not w:
                self.finish(True, '小心心送到啦，开心一点点。')
            elif elapsed > DURATION+3:
                self.finish(False, '朝向没有顺利恢复，我先停稳，留待下次再表演。')
            else:
                self.pub.publish(twist(0, w))
            return
        v, w, caption = beat_at(elapsed)
        self.pub.publish(twist(v, w))
        if caption != self.last_caption:
            self.note.publish(string(caption))
            self.last_caption = caption
        if now-self.last_point > 0.15:
            item = PoseStamped()
            item.header.frame_id = 'map'
            item.header.stamp = self.get_clock().now().to_msg()
            item.pose.position.x, item.pose.position.y = pose[:2]
            item.pose.orientation.z, item.pose.orientation.w = math.sin(pose[2]/2), math.cos(pose[2]/2)
            self.points.append(item)
            path = NavPath()
            path.header = item.header
            path.poses = self.points[-200:]
            self.path.publish(path)
            self.last_point = now
