"""ROS adapter for the local control panel. HTTP requests never block ROS callbacks."""
from collections import deque
import io
import json
import threading
import time
import webbrowser

from ament_index_python.packages import get_package_share_directory
from PIL import Image as PILImage
import rclpy
from rclpy.clock import Clock, ClockType
from rclpy.node import Node
from rclpy.qos import QoSProfile, DurabilityPolicy, qos_profile_sensor_data
from sensor_msgs.msg import Image
from nav_msgs.msg import OccupancyGrid
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from .panel import PanelApplication, start_server

LATCH = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL)


class ControlPanel(Node):
    def __init__(self):
        super().__init__('yuyu_control_panel')
        self.declare_parameter('port', 8765)
        self.declare_parameter('open_browser', True)
        self.pending, self.lock = deque(), threading.RLock()
        self.teleop, self.teleop_until = (0.0, 0.0), 0.0
        self.last_robot_event, self.last_image = 0.0, 0.0
        self.command = self.create_publisher(String, '/command_request', 20)
        self.distance = self.create_publisher(String, '/distance_request', 10)
        self.vision = self.create_publisher(String, '/vision_request', 10)
        self.person_config=self.create_publisher(String,'/person_config_request',10)
        self.face_person=self.create_publisher(String,'/face_person_request',10)
        self.operator_camera=self.create_publisher(Image,'/operator_camera/image_raw',qos_profile_sensor_data)
        self.operator_frame=None
        self.camera_at, self.map_updates = 0.0, 0
        self.speech = self.create_publisher(String, '/speech_request', 20)
        self.settings = self.create_publisher(String, '/user_settings', LATCH)
        self.manual = self.create_publisher(Twist, '/panel_cmd_vel', 10)
        self.app = PanelApplication(self.dispatch)
        self.create_subscription(String, '/behavior_state',
            lambda m: self.robot_update('behavior', m.data), LATCH)
        self.create_subscription(String, '/task_status',
            lambda m: self.json_update('task', m.data), LATCH)
        self.create_subscription(String, '/safety_status',
            lambda m: self.json_update('safety', m.data), 5)
        self.create_subscription(String, '/motion_status',
            lambda m: self.robot_update('motion', m.data), 10)
        self.create_subscription(String, '/speech_status',
            lambda m: self.json_update('speech', m.data), LATCH)
        self.create_subscription(String, '/face_text',
            lambda m: self.app.state.message('robot', m.data), 10)
        self.create_subscription(String, '/command_ack', self.acknowledgement, 20)
        self.create_subscription(Image, '/face_image', self.image, qos_profile_sensor_data)
        self.create_subscription(Image, '/camera/image_raw', self.camera_image, qos_profile_sensor_data)
        self.create_subscription(String, '/vision_status', lambda m: self.json_update('vision', m.data), LATCH)
        self.create_subscription(String, '/distance_status', lambda m: self.json_update('distance', m.data), LATCH)
        self.create_subscription(OccupancyGrid, '/map', self.map_update, LATCH)
        self.create_subscription(String,'/person_status',lambda m:self.json_update('person',m.data),LATCH)
        self.create_subscription(String,'/attention_status',lambda m:self.json_update('attention',m.data),LATCH)
        self.wall = Clock(clock_type=ClockType.STEADY_TIME)
        self.create_timer(0.05, self.tick, clock=self.wall)
        self.create_timer(1.0, self.heartbeat, clock=self.wall)
        self.settings.publish(String(data=json.dumps(self.app.store.get(), ensure_ascii=False)))
        web = get_package_share_directory('yuyu_bringup')+'/web'
        self.server = start_server(self.app, web, int(self.get_parameter('port').value))
        self.url = 'http://127.0.0.1:%d' % self.server.server_port
        self.get_logger().info('禹禹控制面板：'+self.url)
        if self.get_parameter('open_browser').value:
            threading.Thread(target=lambda: webbrowser.open(self.url), daemon=True).start()

    def robot_update(self, key, value):
        self.last_robot_event = time.monotonic()
        self.app.state.update(key, value)

    def json_update(self, key, payload):
        try:
            self.robot_update(key, json.loads(payload))
        except (ValueError, TypeError):
            pass

    def acknowledgement(self, msg):
        try:
            value = json.loads(msg.data)
            with self.app.state.lock:
                acks = self.app.state.value['acks']
                acks[value['id']] = value
                while len(acks) > 80:
                    acks.pop(next(iter(acks)))
        except (ValueError, TypeError, KeyError):
            pass

    def image(self, msg):
        if time.monotonic()-self.last_image < 0.20 or msg.encoding != 'rgb8':
            return
        if not 0 < msg.width <= 1920 or not 0 < msg.height <= 1080:
            return
        try:
            frame = PILImage.frombytes('RGB', (msg.width, msg.height), bytes(msg.data),
                                       'raw', 'RGB', msg.step)
            output = io.BytesIO()
            frame.save(output, format='PNG', compress_level=1)
            with self.app.state.lock:
                self.app.state.face = output.getvalue()
            self.last_image = time.monotonic()
        except (ValueError, OSError):
            pass

    def dispatch(self, kind, value):
        with self.lock:
            if kind=='person_frame':
                self.operator_frame=(value,time.monotonic());return
            if kind=='person_config':self.operator_frame=None
            if kind == 'teleop':
                self.teleop = (value['v'], value['w'])
                self.teleop_until = time.monotonic()+0.3
                return
            if kind == 'command' and value['text'] in ('停下', '停止', '安静', '不想说'):
                self.pending.clear()
                self.teleop, self.teleop_until = (0.0, 0.0), 0.0
            if len(self.pending) >= 64:
                raise ValueError('指令较多，请稍等一下再试')
            self.pending.append((kind, value))

    def camera_image(self, msg):
        if time.monotonic()-self.camera_at < 0.5: return
        if msg.encoding not in ('rgb8', 'bgr8') or not 0 < msg.width <= 1920 or not 0 < msg.height <= 1080: return
        try:
            image = PILImage.frombytes('RGB', (msg.width, msg.height), bytes(msg.data),
                                      'raw', msg.encoding[:-1].upper(), msg.step)
            image.thumbnail((320, 240))
            out = io.BytesIO(); image.save(out, format='PNG', compress_level=1)
            with self.app.state.lock: self.app.state.camera = out.getvalue()
            self.camera_at = time.monotonic()
        except (ValueError, OSError): pass

    def map_update(self, msg):
        self.map_updates += 1
        self.app.state.update('mapping', {'updates': self.map_updates, 'width': msg.info.width,
            'height': msg.info.height, 'resolution': msg.info.resolution,
            'known_cells': sum(v >= 0 for v in msg.data), 'occupied_cells': sum(v >= 65 for v in msg.data)})

    def tick(self):
        with self.lock:
            entries = [self.pending.popleft() for _ in range(min(16, len(self.pending)))]
            v, w = self.teleop if time.monotonic() < self.teleop_until else (0.0, 0.0)
            frame,self.operator_frame=self.operator_frame,None
        for kind, value in entries:
            publisher = {'command': self.command, 'speech': self.speech, 'settings': self.settings,
                         'distance': self.distance, 'vision': self.vision,
                         'person_config':self.person_config,'face_person':self.face_person}[kind]
            publisher.publish(String(data=json.dumps(value, ensure_ascii=False)))
        if frame and time.monotonic()-frame[1]<.7:
            value=frame[0];image=Image();image.header.stamp=self.get_clock().now().to_msg()
            image.header.frame_id='browser_'+value['session'];image.width=value['width'];image.height=value['height']
            image.encoding='rgb8';image.step=image.width*3;image.data=value['data'];self.operator_camera.publish(image)
        msg = Twist()
        msg.linear.x, msg.angular.z = float(v), float(w)
        self.manual.publish(msg)

    def heartbeat(self):
        self.app.state.update('connected', time.monotonic()-self.last_robot_event < 2)
        self.settings.publish(String(data=json.dumps(self.app.store.get(), ensure_ascii=False)))

    def destroy_node(self):
        if self.context.ok():
            self.manual.publish(Twist())
        self.server.shutdown()
        self.server.server_close()
        return super().destroy_node()


def main():
    rclpy.init()
    node = ControlPanel()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
