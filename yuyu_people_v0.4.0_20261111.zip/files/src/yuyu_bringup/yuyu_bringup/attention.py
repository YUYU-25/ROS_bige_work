"""Bounded visual facing; rotation uses image bearing, never a person's world pose."""
import math
from .core import wrap_angle


class FacingController:
    def __init__(self,now,yaw,search=False,prior_heading=None):
        self.started,self.origin=now,yaw
        self.search=search;self.prior_heading=prior_heading
        self.last_yaw,self.swept=yaw,0.
        self.seen=False;self.last_seen=now;self.last_sequence=-1;self.centered=0

    def step(self,person,age,now,yaw):
        def output(w=0.,done=False,reason=''):
            return {'velocity':(0.,w),'done':done,'reason':reason}
        if person.get('source')!='robot':return output(done=True,reason='external_camera')
        if not person.get('enabled') or not person.get('turn_allowed') or age>1.2 or not person.get('fresh'):
            return output(done=True,reason='camera_unavailable')
        if now-self.started>(18. if self.search else 10.):return output(done=True,reason='timeout')
        self.swept+=abs(wrap_angle(yaw-self.last_yaw));self.last_yaw=yaw
        if person.get('detected'):
            self.seen=True;self.last_seen=now
            error=float(person.get('bearing',0.))
            if not math.isfinite(error) or abs(error)>.7:return output(done=True,reason='invalid_bearing')
            seq=person.get('frame_sequence')
            if seq!=self.last_sequence:
                self.last_sequence=seq;self.centered=self.centered+1 if abs(error)<.035 else 0
            if self.centered>=2:return output(done=True,reason='centered')
            if abs(error)<.035:return output()
            return output(math.copysign(min(.32,max(.06,abs(error)*1.4)),error))
        self.centered=0
        if self.seen:return output(done=now-self.last_seen>.8,reason='target_lost')
        if self.prior_heading is not None:
            error=wrap_angle(self.prior_heading-yaw)
            if abs(error)>.08:return output(math.copysign(min(.45,max(.08,abs(error))),error))
            self.prior_heading=None
            if not self.search:return output(done=True,reason='not_found')
        if not self.search:return output(done=True,reason='not_found')
        if self.swept>=2*math.pi:return output(done=True,reason='not_found')
        return output(.45)
