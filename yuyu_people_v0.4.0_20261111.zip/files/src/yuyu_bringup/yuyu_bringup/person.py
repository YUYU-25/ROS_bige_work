"""Face presence and bearing from pixels. No identity templates or world model lookup."""
import math
from pathlib import Path
from PIL import Image


def rgb_frame(data,width,height,step,encoding='rgb8'):
    if encoding not in ('rgb8','bgr8','rgba8','bgra8'):raise ValueError('图像编码不支持')
    channels=4 if 'a8' in encoding else 3
    if not (0<width<=1280 and 0<height<=960 and width*channels<=step<=width*channels+4096 and len(data)>=height*step):
        raise ValueError('人物图像尺寸无效')
    return Image.frombytes('RGB' if channels==3 else 'RGBA',(width,height),bytes(data),
                           'raw',encoding[:-1].upper(),step).convert('RGB')


class FaceDetector:
    def __init__(self,model):
        import cv2
        self.cv=cv2
        cv2.setNumThreads(1)
        self.classifier=cv2.CascadeClassifier(str(model))
        if self.classifier.empty():raise ValueError('人脸检测模型未安装')

    def detect(self,image):
        import numpy as np
        image=image.copy();image.thumbnail((400,300))
        gray=self.cv.cvtColor(np.asarray(image),self.cv.COLOR_RGB2GRAY)
        # Local contrast avoids washing out a small backlit face against bright walls.
        gray=self.cv.createCLAHE(clipLimit=2.,tileGridSize=(8,8)).apply(gray)
        boxes,_,scores=self.classifier.detectMultiScale3(gray,scaleFactor=1.08,minNeighbors=4,minSize=(18,18),outputRejectLevels=True)
        width,height=image.size
        candidates=[(float(score),[x/width,y/height,w/width,h/height]) for (x,y,w,h),score in zip(boxes,scores) if score>=2.]
        return [box for score,box in sorted(candidates,key=lambda row:row[0],reverse=True)[:6]]


class PersonObservation:
    def __init__(self):
        self.enabled,self.source,self.auto_face=False,'robot',True
        self.session=''
        self.frame_at=-math.inf;self.sequence=0;self.streak=0;self.boxes=[]
        self.error=''

    def configure(self,enabled,source,auto_face=True,session=''):
        if not isinstance(enabled,bool) or not isinstance(auto_face,bool) or source not in ('robot','browser'):
            raise ValueError('人物互动设置无效')
        if not isinstance(session,str) or len(session)>64:raise ValueError('摄像头会话无效')
        self.enabled,self.source,self.auto_face,self.session=enabled,source,auto_face,session
        self.frame_at=-math.inf;self.streak=0;self.boxes=[];self.error=''

    def observe(self,boxes,now):
        if now-self.frame_at>1.2:self.streak=0
        self.frame_at=now;self.sequence+=1;self.boxes=boxes
        self.streak=self.streak+1 if boxes else 0

    def status(self,now):
        fresh=self.enabled and 0<=now-self.frame_at<=1.2
        detected=bool(fresh and self.streak>=2 and self.boxes)
        bearing=0.
        if detected:
            x,y,w,h=self.boxes[0]
            bearing=math.atan((.5-x-w/2)*2*math.tan(1.15/2))
        detail=('人物互动未开启' if not self.enabled else self.error if self.error else
                '等待摄像头画面' if not fresh else
                '已检测到人脸，可识别并回应；电脑摄像头模式不控制机身转向' if detected and self.source=='browser' else
                '已检测到场景人脸' if detected else '画面中暂未检测到人脸')
        return {'enabled':self.enabled,'source':self.source,'auto_face':self.auto_face,
                'session':self.session,'fresh':bool(fresh),'detected':detected,
                'frame_sequence':self.sequence,'boxes':self.boxes if fresh else [],
                'bearing':bearing,'turn_allowed':bool(self.source=='robot' and fresh and not self.error),
                'available':not bool(self.error),'detail':detail}
