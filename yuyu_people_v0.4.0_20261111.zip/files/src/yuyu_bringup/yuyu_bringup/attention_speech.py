"""Delay ordinary speech briefly for facing; mute/stop/resume remain immediate."""
from collections import OrderedDict
import time
import uuid


class AttentionSpeech:
    def __init__(self,worker,request,now=time.monotonic):
        self.worker,self.request,self.now=worker,request,now
        self.person={};self.pending=OrderedDict()

    def submit(self,action,text='',voice_id=None,identity=None):
        identity=identity or uuid.uuid4().hex
        if identity in self.pending or identity in self.worker.seen:return
        if action in ('mute','cancel','resume'):
            self.pending.clear()
        eligible=(self.person.get('enabled') and self.person.get('source')=='robot' and self.person.get('auto_face')
                  and action in ('speak','resume') and bool(text) and (not self.worker.silent or action=='resume'))
        if not eligible:
            self.worker.submit(action,text,voice_id,identity);return
        if action=='resume':self.worker.submit('resume','',voice_id,identity+':unmute')
        while len(self.pending)>=8:self.pending.popitem(last=False)
        job={'id':identity,'text':text,'voice_id':voice_id,'action':'speak'}
        self.pending[identity]=(job,self.now()+12.)
        self.request(job)

    def ready(self,value):
        row=self.pending.pop(value.get('id'),None)
        if row and not value.get('cancelled'):
            job=row[0];self.worker.submit('speak',job['text'],job.get('voice_id'),job['id'])

    def tick(self):
        for identity,(job,until) in list(self.pending.items()):
            if self.now()>=until:self.ready(job)
