"""Optional local detector: on-robot simulated RGB or explicitly shared browser video."""
import json
import time
from pathlib import Path
from ament_index_python.packages import get_package_share_directory
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image
from std_msgs.msg import String
from .person import FaceDetector,PersonObservation,rgb_frame
from .ros_utils import LATCH,string,wall_timer


class PersonControl(Node):
    def __init__(self):
        super().__init__('person_control')
        self.observation=PersonObservation();self.detector=None;self.last_processed=-1.
        self.pub=self.create_publisher(String,'/person_status',LATCH)
        try:
            model=Path(get_package_share_directory('yuyu_bringup'))/'config/person/haarcascade_frontalface_default.xml'
            self.detector=FaceDetector(model)
        except (ImportError,ValueError,OSError) as error:
            self.observation.error='人脸检测暂不可用：'+str(error)[:140]
        self.create_subscription(String,'/person_config_request',self.configure,10)
        self.create_subscription(Image,'/camera/image_raw',lambda m:self.image(m,'robot'),qos_profile_sensor_data)
        self.create_subscription(Image,'/operator_camera/image_raw',lambda m:self.image(m,'browser'),qos_profile_sensor_data)
        wall_timer(self,.2,self.tick)

    def configure(self,msg):
        try:
            value=json.loads(msg.data)
            error=self.observation.error
            self.observation.configure(value['enabled'],value['source'],value.get('auto_face',True),value.get('session',''))
            if self.detector is None:self.observation.error=error or '人脸检测引擎不可用'
            self.last_processed=-1.;self.tick()
        except (ValueError,TypeError,KeyError):pass

    def image(self,msg,source):
        obs=self.observation;now=time.monotonic()
        if not obs.enabled or obs.source!=source or self.detector is None or now-self.last_processed<.3:return
        if source=='browser' and msg.header.frame_id!='browser_'+obs.session:return
        stamp=msg.header.stamp;age=(self.get_clock().now().nanoseconds-stamp.sec*10**9-stamp.nanosec)/1e9
        if not -.1<=age<=1.:return
        try:
            frame=rgb_frame(msg.data,msg.width,msg.height,msg.step,msg.encoding)
            obs.observe(self.detector.detect(frame),now)
            self.last_processed=now;self.tick()
        except (ValueError,OSError):pass

    def tick(self):self.pub.publish(string(json.dumps(self.observation.status(time.monotonic()),ensure_ascii=False)))
