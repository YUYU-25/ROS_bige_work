#!/usr/bin/env python3
"""Physical visual-facing and HTTP-to-ROS browser-frame validation with a public fixture.

Person/entity truth is read only by this test, never the product detector/controller.
Requires the people coursework scene and control panel already running.
"""
import base64
import io
import json
import math
from pathlib import Path
import re
import time
import urllib.request
import urllib.error
import uuid
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from geometry_msgs.msg import Twist
from gazebo_msgs.srv import GetEntityState,SetEntityState
from sensor_msgs.msg import Image
from std_msgs.msg import String
from yuyu_bringup.person import rgb_frame
from yuyu_bringup.ros_utils import LATCH
from yuyu_bringup.core import wrap_angle
from PIL import Image as PILImage

ROOT=Path(__file__).resolve().parents[1]


def main():
    rclpy.init();node=Node('person_physical_check');values={};states=[];captions=[];commands=[]
    for key,topic in [('person','/person_status'),('attention','/attention_status'),('safety','/safety_status')]:
        node.create_subscription(String,topic,lambda m,k=key:values.update({k:json.loads(m.data)}),LATCH if key!='safety' else 10)
    node.create_subscription(String,'/behavior_state',lambda m:(values.update(state=m.data),states.append((time.monotonic(),m.data))),LATCH)
    node.create_subscription(String,'/face_text',lambda m:captions.append((time.monotonic(),m.data)),20)
    node.create_subscription(Twist,'/cmd_vel',lambda m:commands.append((time.monotonic(),m.linear.x,m.angular.z)),10)
    node.create_subscription(Image,'/camera/image_raw',lambda m:values.update(camera=m),qos_profile_sensor_data)
    get=node.create_client(GetEntityState,'/gazebo/get_entity_state');setstate=node.create_client(SetEntityState,'/gazebo/set_entity_state')
    speech=node.create_publisher(String,'/speech_request',20)
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    root_url='http://127.0.0.1:8765'
    token=re.search(r'name="csrf-token" content="([^"]+)"',opener.open(root_url,timeout=10).read().decode()).group(1)
    report={'checks':[],'browser_camera':'public NASA still-image fixture through real HTTP/ROS; no human webcam hardware claim'}
    original_visitor=None

    def pump(seconds):
        until=time.monotonic()+seconds
        while time.monotonic()<until:rclpy.spin_once(node,timeout_sec=.025)
    def wait(test,seconds,description):
        until=time.monotonic()+seconds
        while time.monotonic()<until:
            pump(.05)
            if test():return
        raise AssertionError(description+' '+str({k:v for k,v in values.items() if k not in ('camera',)}))
    def post(path,body):
        request=urllib.request.Request(root_url+path,data=json.dumps(body).encode(),headers={'Content-Type':'application/json','X-Yuyu-Token':token})
        with opener.open(request,timeout=5) as response:return json.load(response)
    def state():
        with opener.open(root_url+'/api/state',timeout=5) as response:return json.load(response)
    def service(client,request):
        assert client.wait_for_service(timeout_sec=10)
        future=client.call_async(request);wait(future.done,12,'service timeout');result=future.result();assert result.success,repr(result);return result
    def truth(name='yuyu'):
        request=GetEntityState.Request();request.name=name
        result=service(get,request).state
        # gazebo_ros_state returns an empty name even after a successful lookup.
        result.name=name
        return result
    def yaw(pose):
        q=pose.orientation;return math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))
    def configure(source='robot',auto=True,session=''):
        post('/api/person/config',{'enabled':True,'source':source,'auto_face':auto,'session':session})
        wait(lambda:values.get('person',{}).get('enabled') and values['person']['source']==source and values['person'].get('session','')==session,5,'person mode did not apply')
    def turn_by(amount):
        origin=yaw(truth().pose);target=wrap_angle(origin+amount);deadline=time.monotonic()+20
        while time.monotonic()<deadline:
            error=wrap_angle(target-yaw(truth().pose))
            if abs(error)<.06:break
            post('/api/teleop',{'v':0.,'w':math.copysign(min(.45,max(.08,abs(error))),error)});pump(.08)
        else:raise AssertionError('manual turn timeout')
        post('/api/teleop',{'v':0.,'w':0.});pump(.5)
    def save_camera(name):
        m=values['camera'];rgb_frame(m.data,m.width,m.height,m.step,m.encoding).save(str(ROOT/'docs/previews'/name))
    try:
        wait(lambda:values.get('safety',{}).get('ready') and values.get('person',{}).get('available'),100,'startup not ready')
        original_visitor=truth('study_visitor')
        configure(auto=False)
        # Make reruns independent of the heading left by a prior stop/loss test.
        turn_by(wrap_angle(-yaw(truth().pose)))
        wait(lambda:values.get('person',{}).get('detected'),6,'actual scene face not detected')
        initial_bearing=values['person']['bearing'];before=truth().pose
        states.clear();post('/api/person/face',{})
        wait(lambda:any(s=='FACING' for _,s in states),4,'manual facing did not start')
        wait(lambda:values.get('attention',{}).get('state')=='centered' and values.get('state')=='IDLE',18,'manual facing incomplete')
        after=truth().pose;visitor=truth('study_visitor').pose;vyaw=yaw(visitor)
        fx,fy=visitor.position.x+.083*math.cos(vyaw),visitor.position.y+.083*math.sin(vyaw)
        heading_error=abs(wrap_angle(yaw(after)-math.atan2(fy-after.position.y,fx-after.position.x)))
        translation=math.hypot(after.position.x-before.position.x,after.position.y-before.position.y)
        assert heading_error<.10 and translation<.02,(heading_error,translation)
        save_camera('person-camera-centered.png')
        report['checks'].append({'scene_face_initial_bearing_rad':initial_bearing,'centered_bearing_rad':values['person']['bearing'],
                                'truth_heading_error_rad':heading_error,'translation_m':translation})
        print('PASS scene facing',report['checks'][-1],flush=True)

        configure(auto=True);wait(lambda:values['person'].get('fresh'),5,'camera not fresh')
        # Keep the target in the actual field of view for the closed-loop assertion.
        # Large blind turns may legitimately hit the bounded search deadline.
        turn_by(.25);pump(.8)
        states.clear();text='你好，我正在面向你说话。';started=time.monotonic()
        speech.publish(String(data=json.dumps({'id':uuid.uuid4().hex,'action':'speak','text':text},ensure_ascii=False)))
        wait(lambda:any(s=='FACING' for _,s in states),4,'speech did not trigger facing')
        wait(lambda:any(t>=started and text in s for t,s in captions),15,'speech not released after facing')
        centered_times=[t for t,s in states if s=='IDLE' and t>=started]
        spoken=next(t for t,s in captions if t>=started and text in s)
        assert centered_times and spoken>=centered_times[0]-.08 and values['attention']['state']=='centered', (states, values['attention'], values['person'])
        report['checks'].append({'speech_waited_for_visual_alignment':True,'elapsed_s':spoken-started})
        print('PASS speech order',report['checks'][-1],flush=True)

        turn_by(.25);pump(.4);states.clear();text='这句被停下取消后不应该播报。';started=time.monotonic()
        speech.publish(String(data=json.dumps({'id':uuid.uuid4().hex,'action':'speak','text':text},ensure_ascii=False)))
        wait(lambda:values.get('state')=='FACING',4,'cancel facing did not start')
        post('/api/command',{'id':uuid.uuid4().hex,'text':'停下'})
        wait(lambda:values.get('state')=='IDLE',3,'stop did not cancel facing');pump(1.5)
        assert not any(t>=started and text in s for t,s in captions)
        assert all(abs(v)<.002 and abs(w)<.002 for _,v,w in commands[-5:])
        report['checks'].append({'stop_cancelled_turn_and_deferred_speech':True})

        # Acquire then remove the visible 3D visitor; the product sees only changed pixels.
        turn_by(-.12)
        wait(lambda:values['person'].get('detected'),5,'target not reacquired for loss test')
        if abs(values['person']['bearing'])<.12:
            turn_by(.22)
            wait(lambda:values['person'].get('detected'),5,'offset target not detected')
        post('/api/person/face',{});wait(lambda:values.get('state')=='FACING',4,'loss test did not turn');pump(.2)
        request=SetEntityState.Request();request.state=truth('study_visitor');request.state.pose.position.y+=3.
        service(setstate,request);lost_at=time.monotonic()
        wait(lambda:values.get('state')=='IDLE',4,'lost target did not stop')
        pump(.4);assert all(abs(v)<.002 and abs(w)<.002 for _,v,w in commands[-5:])
        report['checks'].append({'target_loss_stopped_turn_in_s':time.monotonic()-lost_at})
        request=SetEntityState.Request();request.state=original_visitor;service(setstate,request)

        session=uuid.uuid4().hex;configure('browser',session=session)
        buf=io.BytesIO();PILImage.open(ROOT/'src/yuyu_description/meshes/person/astronaut.png').resize((300,300)).save(buf,format='JPEG')
        image=base64.b64encode(buf.getvalue()).decode();started=time.monotonic();states.clear()
        for _ in range(4):post('/api/person/frame',{'session':session,'image':image});pump(.55)
        wait(lambda:values['person'].get('detected'),4,'browser fixture did not reach detector')
        pump(.3);assert not any(s=='FACING' for t,s in states)
        assert all(abs(v)<.002 and abs(w)<.002 for t,v,w in commands if t>started+.3)
        assert any(t>=started and '看到你啦' in s for t,s in captions)
        assert image not in json.dumps(state(),ensure_ascii=False)
        report['checks'].append({'browser_fixture_face_detected_and_greeted':True,'fixed_browser_camera_caused_no_robot_turn':True})
        post('/api/person/config',{'enabled':False,'source':'browser','session':'','auto_face':True})
        wait(lambda:not values['person'].get('enabled'),3,'browser camera did not disable')
        try:post('/api/person/frame',{'session':session,'image':image})
        except urllib.error.HTTPError as error:assert error.code==400
        else:raise AssertionError('closed session accepted frame')
        (ROOT/'docs/person-physical-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
        print('PASS ALL',json.dumps(report,ensure_ascii=False),flush=True)
    finally:
        try:
            post('/api/person/config',{'enabled':False,'source':'robot','session':'','auto_face':True})
            post('/api/command',{'id':uuid.uuid4().hex,'text':'停下'})
            if original_visitor:
                req=SetEntityState.Request();req.state=original_visitor;service(setstate,req)
            pump(.4)
        finally:node.destroy_node();rclpy.shutdown()


if __name__=='__main__':main()
