"""Facing safety, local frame transport, speech ordering, and optional real OpenCV."""
import base64
from collections import deque
import importlib.util
import io
import math
from pathlib import Path
import sys
import tempfile
import unittest
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src/yuyu_bringup'))
from yuyu_bringup.person import PersonObservation,FaceDetector
from yuyu_bringup.attention import FacingController
from yuyu_bringup.attention_speech import AttentionSpeech
from yuyu_bringup.behavior import TaskCoordinator
from yuyu_bringup.core import CLIFF_NAMES
from yuyu_bringup.panel import PanelApplication


def person(bearing=.2,seq=1,detected=True,source='robot'):
    return {'enabled':True,'source':source,'fresh':True,'detected':detected,'bearing':bearing,
            'frame_sequence':seq,'turn_allowed':source=='robot','auto_face':True}


class ObservationTests(unittest.TestCase):
    def test_presence_bearing_freshness_and_source(self):
        p=PersonObservation();p.configure(True,'robot')
        p.observe([[.15,.2,.2,.3]],1.);self.assertFalse(p.status(1.)['detected'])
        p.observe([[.15,.2,.2,.3]],1.4);self.assertTrue(p.status(1.4)['detected'])
        self.assertGreater(p.status(1.4)['bearing'],0)
        self.assertFalse(p.status(2.7)['fresh'])
        p.configure(True,'browser',session='test');p.observe([[.7,.2,.2,.3]],3);p.observe([[.7,.2,.2,.3]],3.5)
        self.assertTrue(p.status(3.5)['detected']);self.assertFalse(p.status(3.5)['turn_allowed'])


class FacingTests(unittest.TestCase):
    def test_rotation_direction_and_distinct_centered_frames(self):
        f=FacingController(1.,0.)
        self.assertGreater(f.step(person(.2),0.,1.,0.)['velocity'][1],0)
        self.assertLess(f.step(person(-.2,seq=2),0.,1.1,0.)['velocity'][1],0)
        self.assertFalse(f.step(person(0.,seq=3),0.,1.2,0.)['done'])
        self.assertFalse(f.step(person(0.,seq=3),0.,1.3,0.)['done'])
        result=f.step(person(0.,seq=4),0.,1.4,0.)
        self.assertTrue(result['done']);self.assertEqual(result['reason'],'centered')

    def test_external_camera_stale_lost_and_search_deadline_stop(self):
        for value,age in [(person(source='browser'),0),(person(),1.3)]:
            result=FacingController(1.,0.).step(value,age,1.1,0.)
            self.assertEqual(result['velocity'],(0.,0.));self.assertTrue(result['done'])
        f=FacingController(1.,0.);f.step(person(),0.,1.,0.)
        self.assertEqual(f.step(person(detected=False),0.,1.2,0.)['velocity'],(0.,0.))
        self.assertTrue(f.step(person(detected=False),0.,2.,0.)['done'])
        f=FacingController(1.,0.,search=True)
        self.assertNotEqual(f.step(person(detected=False),0.,1.1,0.)['velocity'][1],0)
        self.assertTrue(f.step(person(detected=False),0.,19.1,0.)['done'])

    def test_search_is_one_revolution_and_prior_only_predicts_direction(self):
        f=FacingController(1.,0.,search=True)
        for i in range(1,14):
            yaw=math.atan2(math.sin(i*.5),math.cos(i*.5))
            result=f.step(person(detected=False),0.,1.+i*.3,yaw)
        self.assertTrue(result['done']);self.assertEqual(result['velocity'],(0.,0.))
        f=FacingController(1.,2.8,prior_heading=.3)
        self.assertLess(f.step(person(detected=False),0.,1.1,2.8)['velocity'][1],0)
        # An old bearing is only a search hint; it cannot claim successful visual alignment.
        result=f.step(person(detected=False),0.,3.,.3)
        self.assertTrue(result['done']);self.assertEqual(result['reason'],'not_found')


class SpeechTests(unittest.TestCase):
    class Worker:
        def __init__(self):self.silent=False;self.seen=deque(maxlen=80);self.jobs=[]
        def submit(self,action,text='',voice_id=None,identity=None):
            self.seen.append(identity);self.jobs.append((action,text,identity))
            if action=='mute':self.silent=True
            if action=='resume':self.silent=False

    def test_speech_waits_for_facing_and_cancel_drops_deferred(self):
        w=self.Worker();requests=[];now=[1.];gate=AttentionSpeech(w,requests.append,now=lambda:now[0]);gate.person=person()
        gate.submit('speak','你好',identity='a');self.assertFalse(w.jobs);self.assertEqual(len(requests),1)
        gate.submit('speak','你好',identity='a');self.assertEqual(len(requests),1)
        gate.ready({'id':'a'});self.assertEqual(w.jobs[-1][1],'你好')
        gate.submit('speak','这句应取消',identity='b');gate.submit('mute',identity='mute')
        gate.ready({'id':'b'});self.assertFalse(any(t=='这句应取消' for _,t,_ in w.jobs))

    def test_resume_unmutes_once_before_facing_and_external_camera_does_not_wait(self):
        w=self.Worker();w.silent=True;requests=[];gate=AttentionSpeech(w,requests.append);gate.person=person()
        gate.submit('resume','我回来啦',identity='resume');self.assertFalse(w.silent)
        self.assertEqual(len(w.jobs),1);self.assertEqual(w.jobs[0][1],'')
        gate.submit('resume','我回来啦',identity='resume');self.assertEqual(len(requests),1)
        gate.ready({'id':'resume'});self.assertEqual(w.jobs[-1][1],'我回来啦')
        gate.person=person(source='browser');gate.submit('speak','真人你好',identity='web')
        self.assertEqual(w.jobs[-1][1],'真人你好')


class TaskSafetyTests(unittest.TestCase):
    def setUp(self):
        self.now,self.events=10.,[]
        self.t=TaskCoordinator(lambda k,v:self.events.append((k,v)),now=lambda:self.now)
        self.t.odom,self.t.odom_at=(0.,0.,0.),self.now
        self.t.set_safety({'ready':True,'pose':(0.,0.,0.),'edges':dict.fromkeys(CLIFF_NAMES,False)})
        self.t.quiet=True;self.t.set_person(person());self.t.quiet=False

    def test_manual_stop_and_red_guard_cancel_facing_and_speech(self):
        job={'id':'a','text':'你好','action':'speak'};self.t.face_speech(job)
        self.assertEqual(self.t.state,'FACING');self.t.tick()
        self.assertTrue(self.t.facing is not None)
        self.t.manual_override();self.assertEqual(self.t.state,'IDLE')
        self.assertTrue(any(k=='speech_ready' and v.get('cancelled') for k,v in self.events))
        self.t.face_speech({'id':'b','text':'你好'});self.t.set_vision({'enabled':True,'ready':False,'blocked':True})
        self.assertEqual(self.t.state,'IDLE');self.assertIsNone(self.t.facing)

    def test_navigation_not_interrupted_and_browser_never_rotates(self):
        self.t.request('return');state=self.t.state
        self.t.face_speech({'id':'nav','text':'正在回去'});self.assertEqual(self.t.state,state)
        self.t.stop();self.t.quiet=True;self.t.set_person(person(source='browser'));self.t.quiet=False
        self.assertFalse(self.t.face_person());self.assertEqual(self.t.state,'IDLE')


class BrowserFrameTests(unittest.TestCase):
    def test_session_size_and_frame_data_are_transient(self):
        with tempfile.TemporaryDirectory() as folder:
            calls=[];app=PanelApplication(lambda *args:calls.append(args),folder)
            app.state.update('person',{'enabled':True,'source':'browser','session':'s1'})
            out=io.BytesIO();Image.new('RGB',(32,24),'white').save(out,format='JPEG');encoded=base64.b64encode(out.getvalue()).decode()
            with self.assertRaises(ValueError):app.handle('/api/person/frame',{'session':'old','image':encoded})
            app.handle('/api/person/frame',{'session':'s1','image':encoded})
            self.assertEqual(calls[-1][0],'person_frame');self.assertEqual(len(calls[-1][1]['data']),32*24*3)
            self.assertNotIn(encoded,str(app.snapshot()));self.assertFalse(list(Path(folder).rglob('*.jpg')))
            with self.assertRaises(ValueError):app.handle('/api/person/config',{'enabled':True,'source':'browser','session':'../bad'})


@unittest.skipUnless(importlib.util.find_spec('cv2'),'OpenCV is provided by native Humble/Gazebo environment')
class NativeDetectorTests(unittest.TestCase):
    def test_public_photo_and_actual_gazebo_frame_are_detected_not_blank(self):
        d=FaceDetector(ROOT/'src/yuyu_bringup/config/person/haarcascade_frontalface_default.xml')
        self.assertTrue(d.detect(Image.open(ROOT/'src/yuyu_description/meshes/person/astronaut.png')))
        self.assertFalse(d.detect(Image.new('RGB',(320,240),'white')))
        image=ROOT/'docs/previews/person-camera-initial.png'
        if image.exists():self.assertTrue(d.detect(Image.open(image)))


if __name__=='__main__':unittest.main()
