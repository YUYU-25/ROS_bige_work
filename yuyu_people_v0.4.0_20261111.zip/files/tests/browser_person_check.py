#!/usr/bin/env python3
"""Playwright fixture test with a synthetic camera; does not access human video."""
import sys,tempfile,time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src/yuyu_bringup'))
from yuyu_bringup.panel import PanelApplication,start_server
calls=[];app=None
with tempfile.TemporaryDirectory() as root:
 def dispatch(kind,value):
  if kind=='person_config':app.state.update('person',{**value,'available':True,'detail':'人物模式已设置'})
  calls.append((kind,value))
 app=PanelApplication(dispatch,root);app.state.update('connected',True);app.state.update('safety',{'ready':True,'edges':{}})
 server=start_server(app,str(ROOT/'src/yuyu_bringup/web'),port=19635)
 try:
  with sync_playwright() as p:
   b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream'])
   context=b.new_context(permissions=['camera'],viewport={'width':1280,'height':900});page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   page.goto('http://127.0.0.1:19635');page.locator('#person-details summary').click();page.locator('#enable-scene-person').click();page.wait_for_timeout(800)
   assert any(k=='person_config' and v['source']=='robot' and v['enabled'] for k,v in calls)
   page.locator('#face-person').click();page.wait_for_timeout(150);assert any(k=='face_person' for k,v in calls)
   page.locator('#start-person-camera').click();page.wait_for_timeout(2300)
   assert any(k=='person_frame' and isinstance(v['data'],bytes) for k,v in calls),[(k,list(v) if isinstance(v,dict) else '') for k,v in calls]
   tracks=page.evaluate('document.getElementById("person-video").srcObject.getTracks().map(t=>t.readyState)');assert 'live' in tracks
   page.locator('#stop-person-camera').click();page.wait_for_timeout(200)
   assert page.evaluate('document.getElementById("person-video").srcObject===null')
   count=sum(k=='person_frame' for k,v in calls);page.wait_for_timeout(1100);assert sum(k=='person_frame' for k,v in calls)==count
   # A permission request may resolve after the user has already clicked close.
   page.evaluate('''() => {const original=navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);navigator.mediaDevices.getUserMedia=async c=>{const stream=await original(c);window.delayedCamera=stream;await new Promise(resolve=>window.releaseCamera=resolve);return stream;};}''')
   page.locator('#start-person-camera').click();page.wait_for_function('window.releaseCamera !== undefined')
   page.locator('#stop-person-camera').click();page.evaluate('window.releaseCamera()');page.wait_for_timeout(700)
   assert page.evaluate('window.delayedCamera.getTracks().every(t=>t.readyState==="ended")')
   assert page.evaluate('document.getElementById("person-video").srcObject===null')
   assert not app.snapshot()['person']['enabled']
   page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(200);assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
   assert not errors,errors;b.close();print('PASS: scene mode, facing request, synthetic browser camera frames, stop releases camera and stops uploads, delayed permission cancellation, mobile width; fixture only')
 finally:server.shutdown();server.server_close()
